# 🏢 **OKTA SANDBOX SETUP FOR AIG**
**User**: Manjunath Sampangi (Manjunath.Sampangi@aig.com)

## 📋 **STEP-BY-STEP OKTA CONFIGURATION**

### **Step 1: OKTA Account Creation (5 minutes)**
```
🌐 URL: https://developer.okta.com/signup/
📧 Email: Manjunath.Sampangi@aig.com
🏢 Company: AIG (American International Group)
👤 Name: Manjunath Sampangi
📦 Plan: Okta Integrator Free Plan (FREE)
```

**Process:**
1. Visit: https://developer.okta.com/signup/
2. Fill in your details:
   - First Name: `Manjunath`
   - Last Name: `Sampangi` 
   - Work Email: `Manjunath.Sampangi@aig.com`
   - Country: `United States` (or your location)
3. Choose: `Okta Integrator Free Plan`
4. Verify email (check AIG email inbox)
5. Complete profile setup
6. **Note your OKTA domain**: e.g., `dev-12345.okta.com`

---

### **Step 2: Create OAuth2 Application (3 minutes)**
```
🔗 Login: https://{your-domain}.okta.com/admin
📝 App Name: AIG Google Authenticator POC
🔐 Type: Web Application (OIDC)
```

**Configuration:**
1. Login to OKTA Admin Console
2. Navigate: `Applications` → `Applications` → `Create App Integration`
3. Select:
   - **Sign-in method**: `OIDC - OpenID Connect`
   - **Application type**: `Web Application`
4. Configure Application:
   ```
   App integration name: AIG Google Authenticator POC
   Grant types: ✅ Authorization Code
   Sign-in redirect URIs: http://localhost:8084/login/oauth2/code/okta
   Sign-out redirect URIs: http://localhost:8084/logout
   Controlled access: Allow everyone in your organization to access
   ```
5. **Save** and copy credentials:
   - Client ID: `{will be generated}`
   - Client Secret: `{will be generated}`

---

### **Step 3: Create Test Users (2 minutes)**
```
👥 Navigate: Directory → People → Add Person
📧 Test User: manjunath.test@aig.com (or use your actual email)
```

**User Details:**
```
Username: manjunath.test@aig.com
First Name: Manjunath
Last Name: Test
Primary Email: manjunath.test@aig.com
Password: Set by admin (create a test password)
```

---

### **Step 4: Expected OKTA Credentials**
After setup, you'll have:
```
OKTA_DOMAIN: dev-xxxxx.okta.com (your actual domain)
OKTA_CLIENT_ID: 0oa... (from app configuration)
OKTA_CLIENT_SECRET: ... (from app configuration)
```

---

## 🔧 **AUTOMATED SETUP SCRIPT**

After getting your OKTA credentials, run:
```bash
# Make setup script executable
chmod +x setup-okta-env.sh

# Run setup with your credentials
./setup-okta-env.sh
```

When prompted, enter:
1. **OKTA Domain**: `dev-xxxxx.okta.com` (from your account)
2. **Client ID**: From your OAuth2 app
3. **Client Secret**: From your OAuth2 app
4. **API Token**: (Optional - press Enter to skip)

---

## 🚀 **LAUNCH APPLICATION**

After configuration:
```bash
# Build application
mvn clean package -DskipTests

# Run with OKTA integration
./run-with-okta.sh
```

**Access URLs:**
- OKTA Integration: `http://localhost:8084/okta-info`
- OKTA Login: `http://localhost:8084/okta-login`
- Mock Demo: `http://localhost:8084/okta-registration`

---

## 🎯 **DEMO SCENARIOS FOR AIG**

### **Scenario 1: Real OKTA Authentication**
1. **Navigate**: `http://localhost:8084/okta-login`
2. **Login**: With your OKTA test user credentials
3. **Authenticate**: Real OKTA OAuth2 flow
4. **Access**: Claims portal with enterprise authentication

### **Scenario 2: Mock Authentication (Backup)**
1. **Navigate**: `http://localhost:8084/okta-registration`
2. **Register**: Use Policy Number: `AIG-POL-123456`
3. **Email**: Use `Manjunath.Sampangi@aig.com`
4. **Demo**: Complete mock flow for presentation

---

## 📞 **SUPPORT & TROUBLESHOOTING**

### **Common Issues:**
- **Email verification**: Check AIG spam folder
- **Domain access**: Ensure OKTA domain is correct
- **Corporate firewall**: May need IT approval for external OAuth

### **AIG-Specific Notes:**
- Use corporate email for professional demo
- OKTA sandbox is free and safe for POC
- No corporate data involved - only test scenarios
- Can demonstrate enterprise SSO capabilities

---

## ✅ **NEXT STEPS**

1. **Create OKTA Account**: Use link above with AIG email
2. **Configure OAuth2 App**: Follow step 2 instructions  
3. **Run Setup Script**: `./setup-okta-env.sh`
4. **Test Integration**: Verify both OKTA and mock flows
5. **Demo Ready**: Professional presentation with AIG branding

**🎉 Ready to showcase enterprise-grade OKTA integration for AIG!** 