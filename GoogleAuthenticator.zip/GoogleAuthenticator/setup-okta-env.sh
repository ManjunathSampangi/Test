#!/bin/bash

# OKTA Sandbox Environment Setup Script
# Run this script to configure your OKTA integration credentials

BLUE="\033[0;34m"
GREEN="\033[0;32m"
YELLOW="\033[0;33m"
RED="\033[0;31m"
NC="\033[0m" # No Color

echo -e "${BLUE}🔐 OKTA Sandbox Environment Setup${NC}"
echo "======================================="
echo

# Function to validate OKTA domain format
validate_domain() {
    local domain=$1
    if [[ $domain =~ ^[a-zA-Z0-9-]+\.okta\.com$ ]]; then
        return 0
    else
        return 1
    fi
}

# Check if .env file exists
if [ -f ".env" ]; then
    echo -e "${YELLOW}⚠️  Existing .env file found. Backing up to .env.backup${NC}"
    cp .env .env.backup
fi

echo -e "${BLUE}Please provide your OKTA sandbox credentials:${NC}"
echo

# Get OKTA Domain
while true; do
    echo -e "${BLUE}1. OKTA Domain (e.g., yourorg.okta.com):${NC}"
    read -p "   Enter your OKTA domain: " OKTA_DOMAIN
    
    if validate_domain "$OKTA_DOMAIN"; then
        echo -e "   ${GREEN}✅ Valid OKTA domain format${NC}"
        break
    else
        echo -e "   ${RED}❌ Invalid format. Please enter in format: yourorg.okta.com${NC}"
    fi
done

# Get Client ID
echo
echo -e "${BLUE}2. Client ID from your OKTA application:${NC}"
read -p "   Enter Client ID: " OKTA_CLIENT_ID

# Get Client Secret
echo
echo -e "${BLUE}3. Client Secret from your OKTA application:${NC}"
read -s -p "   Enter Client Secret: " OKTA_CLIENT_SECRET
echo

# Get API Token (optional)
echo
echo -e "${BLUE}4. API Token (optional - for user management):${NC}"
read -s -p "   Enter API Token (press Enter to skip): " OKTA_API_TOKEN
echo

# Create .env file
echo -e "\n${YELLOW}📝 Creating environment configuration...${NC}"

cat > .env << EOF
# OKTA Sandbox Integration Configuration
# Generated on $(date)

# OKTA OAuth2 Settings
OKTA_DOMAIN=$OKTA_DOMAIN
OKTA_CLIENT_ID=$OKTA_CLIENT_ID
OKTA_CLIENT_SECRET=$OKTA_CLIENT_SECRET

# OKTA API Settings (optional)
OKTA_API_TOKEN=$OKTA_API_TOKEN

# Application Settings
SPRING_PROFILES_ACTIVE=okta
JAVA_OPTS=-Dspring.profiles.active=okta

# URLs for reference
# OKTA Org URL: https://$OKTA_DOMAIN
# OAuth2 Issuer: https://$OKTA_DOMAIN/oauth2/default
# Redirect URI: http://localhost:8084/login/oauth2/code/okta
EOF

# Set permissions
chmod 600 .env

echo -e "${GREEN}✅ Environment configuration created successfully!${NC}"
echo

# Display configuration summary
echo -e "${BLUE}📋 Configuration Summary:${NC}"
echo "========================="
echo -e "OKTA Domain:    ${GREEN}$OKTA_DOMAIN${NC}"
echo -e "Client ID:      ${GREEN}${OKTA_CLIENT_ID:0:8}...${NC}"
echo -e "Client Secret:  ${GREEN}[Hidden]${NC}"
if [ -n "$OKTA_API_TOKEN" ]; then
    echo -e "API Token:      ${GREEN}[Configured]${NC}"
else
    echo -e "API Token:      ${YELLOW}[Not configured]${NC}"
fi
echo

# Export variables for current session
echo -e "${BLUE}🔄 Setting up current session...${NC}"
export OKTA_DOMAIN=$OKTA_DOMAIN
export OKTA_CLIENT_ID=$OKTA_CLIENT_ID
export OKTA_CLIENT_SECRET=$OKTA_CLIENT_SECRET
export OKTA_API_TOKEN=$OKTA_API_TOKEN
export SPRING_PROFILES_ACTIVE=okta

echo -e "${GREEN}✅ Environment variables set for current session${NC}"
echo

# Instructions for running the application
echo -e "${BLUE}🚀 Next Steps:${NC}"
echo "=============="
echo "1. Build the application:"
echo -e "   ${YELLOW}mvn clean package -DskipTests${NC}"
echo
echo "2. Run with OKTA integration:"
echo -e "   ${YELLOW}source .env && java -jar target/googleauth-demo-1.0-SNAPSHOT.jar${NC}"
echo
echo "3. Access the application:"
echo -e "   ${YELLOW}http://localhost:8084/okta-info${NC}"
echo
echo "4. Test OKTA login:"
echo -e "   ${YELLOW}http://localhost:8084/okta-login${NC}"
echo

# Create a run script
echo -e "${BLUE}📝 Creating run script...${NC}"

cat > run-with-okta.sh << 'EOF'
#!/bin/bash

# Load environment variables
if [ -f ".env" ]; then
    source .env
    echo "🔐 Loaded OKTA environment configuration"
else
    echo "❌ .env file not found. Run setup-okta-env.sh first"
    exit 1
fi

# Set Java 17 if available
if [ -d "/opt/homebrew/Cellar/openjdk@17" ]; then
    export JAVA_HOME=/opt/homebrew/Cellar/openjdk@17/17.0.15/libexec/openjdk.jdk/Contents/Home
    echo "☕ Using Java 17"
fi

echo "🚀 Starting application with OKTA integration..."
echo "   OKTA Domain: $OKTA_DOMAIN"
echo "   Access at: http://localhost:8084/okta-info"
echo

java -jar target/googleauth-demo-1.0-SNAPSHOT.jar
EOF

chmod +x run-with-okta.sh

echo -e "${GREEN}✅ Created run-with-okta.sh script${NC}"
echo

# Warning about security
echo -e "${RED}⚠️  SECURITY NOTICE:${NC}"
echo "- .env file contains sensitive credentials"
echo "- File permissions set to 600 (owner read/write only)"
echo "- Do NOT commit .env file to version control"
echo "- .env is included in .gitignore"
echo

# Check if .gitignore exists and add .env if needed
if [ -f ".gitignore" ]; then
    if ! grep -q "^\.env$" .gitignore; then
        echo ".env" >> .gitignore
        echo -e "${GREEN}✅ Added .env to .gitignore${NC}"
    fi
else
    echo ".env" > .gitignore
    echo -e "${GREEN}✅ Created .gitignore with .env${NC}"
fi

echo
echo -e "${GREEN}🎉 OKTA sandbox setup complete!${NC}"
echo -e "Run ${YELLOW}./run-with-okta.sh${NC} to start the application with OKTA integration." 