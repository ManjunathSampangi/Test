# Google Authenticator Integration with MuleSoft

This project demonstrates the integration of Google Authenticator with MuleSoft for implementing secure two-factor authentication (2FA).

## Features

- Secure user authentication with 2FA
- Google Authenticator TOTP implementation (RFC 6238)
- QR code generation for mobile app setup
- Recovery codes for backup access
- User-friendly web interface

## Mock Authenticator for POC

This project includes a **Mock Authenticator** for demonstration purposes. This allows you to showcase the entire end-to-end flow without requiring users to install the Google Authenticator app on their mobile devices.

### Using the Mock Authenticator

1. Register a new user account
2. Log in with your credentials
3. Enable 2FA from the dashboard
4. When the QR code appears, it's automatically configured in the mock authenticator
5. Click the "Show Mock Authenticator" button in the dashboard
6. Use the generated 6-digit code to verify and complete 2FA setup
7. For future logins, use the mock authenticator to generate valid codes

## Getting Started

1. Ensure you have Maven and Java 11+ installed
2. Clone this repository
3. Build the project:
   ```
   mvn clean package
   ```
4. Run the application:
   ```
   mvn mule:run
   ```
5. Access the web interface at http://localhost:8081

## E2E Flow Demonstration

For POC and demonstration purposes, follow this sequence:

1. **User Registration**: Create a new account
2. **Login**: Enter your credentials
3. **2FA Setup**: Enable and configure Google Authenticator
4. **Verify Setup**: Use the mock authenticator to complete setup
5. **Logout & Login Again**: Demonstrate the full authentication flow
6. **2FA Verification**: Use the mock authenticator to generate a valid code
7. **Recovery**: Demonstrate recovery code usage if needed
8. **2FA Management**: Show how to disable/enable 2FA

## Security Considerations

This implementation follows security best practices:
- Time-based one-time passwords (TOTP)
- 30-second code expiration
- 6-digit codes using HMAC-SHA1
- Recovery codes for account backup
- Secure secret key storage

## Note

This is a proof-of-concept implementation. For production use, consider:
- Secure database storage for TOTP secrets
- Rate limiting on verification attempts
- Audit logging for security events
- Session management improvements
