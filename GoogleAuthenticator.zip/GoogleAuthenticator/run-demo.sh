#!/bin/bash

CYAN="\033[0;36m"
GREEN="\033[0;32m"
YELLOW="\033[0;33m"
RED="\033[0;31m"
NC="\033[0m" # No Color

echo -e "${CYAN}=========================================================${NC}"
echo -e "${CYAN}   Google Authenticator POC with Mock Authenticator${NC}"
echo -e "${CYAN}=========================================================${NC}"
echo ""

# Check Java version
echo -e "${YELLOW}Checking Java version...${NC}"
java -version
if [ $? -ne 0 ]; then
  echo -e "${RED}Error: Java is not installed or not in PATH${NC}"
  echo "Please install Java 11 or higher and try again."
  exit 1
fi

# Check Maven
echo -e "\n${YELLOW}Checking Maven...${NC}"
mvn -v | head -n 1
if [ $? -ne 0 ]; then
  echo -e "${RED}Error: Maven is not installed or not in PATH${NC}"
  echo "Please install Maven and try again."
  exit 1
fi

# Clean and build the project
echo -e "\n${YELLOW}Building Google Authenticator POC with Mock Authenticator...${NC}"
mvn clean package -DskipTests

if [ $? -eq 0 ]; then
  echo -e "\n${GREEN}Build successful!${NC}"
  
  # Find the JAR file
  JAR_FILE=$(find target -name "*.jar" -not -name "*-sources.jar" -not -name "*-javadoc.jar" | head -n 1)
  
  if [ -z "$JAR_FILE" ]; then
    echo -e "${RED}Error: Could not find JAR file in target directory${NC}"
    exit 1
  fi
  
  echo -e "${GREEN}Starting the application...${NC}"
  echo -e "${CYAN}==================================================${NC}"
  echo -e "${CYAN}  Web interface: ${GREEN}http://localhost:8081${NC}"
  echo -e "${CYAN}  Mock credentials: ${GREEN}admin / admin${NC}"
  echo -e "${CYAN}==================================================${NC}"
  echo ""
  echo -e "${YELLOW}Press Ctrl+C to stop the application${NC}"
  echo ""
  
  # Run the application
  java -jar "$JAR_FILE"
else
  echo -e "\n${RED}Build failed. Please check the errors above.${NC}"
  
  # Provide troubleshooting steps
  echo -e "\n${YELLOW}Troubleshooting steps:${NC}"
  echo "1. Ensure all required dependencies are available in your Maven repository"
  echo "2. Check Java version compatibility (Java 11+ recommended)"
  echo "3. Verify that Spring Boot dependencies are correctly configured in pom.xml"
  echo "4. Run 'mvn clean' to clear any cached artifacts"
  
  exit 1
fi
