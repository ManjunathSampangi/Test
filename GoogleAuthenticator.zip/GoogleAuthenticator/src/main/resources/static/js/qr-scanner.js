/**
 * QR Code Scanning Helper for Mock Authenticator
 * Automatically detects when a QR code is displayed and extracts the secret
 * Uses direct-connect API for reliable integration
 */
document.addEventListener('DOMContentLoaded', function() {
    // Observer for QR code container
    const observer = new MutationObserver(function(mutations) {
        mutations.forEach(function(mutation) {
            if (mutation.type === 'childList' && mutation.addedNodes.length > 0) {
                // Check if QR code was added
                setTimeout(handleQRCodeDisplay, 500);
            }
        });
    });
    
    // Start observing QR code container
    const qrContainer = document.getElementById('qrcode-container');
    if (qrContainer) {
        observer.observe(qrContainer, { childList: true, subtree: true });
    }
    
    // Handle when QR code is displayed
    function handleQRCodeDisplay() {
        // Check if QR image exists
        const qrImage = document.querySelector('#qrcode-container img');
        const userId = document.getElementById('setup-user-id')?.value;
        
        if (qrImage && userId) {
            console.log('Detected QR code, connecting mock authenticator directly');
            
            // Use direct connect API to reliably connect mock authenticator
            fetch(`/api/direct-connect/connect-mock/${userId}`, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' }
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    console.log('Mock authenticator connected successfully');
                    // Show notification with the current code
                    const code = data.data.code;
                    showNotification(`Mock authenticator connected! Current code: ${code}`, 'success', 8000);
                    
                    // Create a button to show mock authenticator
                    addMockAuthenticatorButton();
                } else {
                    console.error('Failed to connect mock authenticator:', data.message);
                    showNotification('Failed to connect mock authenticator. Try again.', 'error', 5000);
                }
            })
            .catch(error => {
                console.error('Error connecting mock authenticator:', error);
                showNotification('Error connecting mock authenticator. See console for details.', 'error', 5000);
            });
        }
    }
    
    // Helper function to show notifications
    function showNotification(message, type = 'info', duration = 3000) {
        const notification = document.getElementById('notification');
        if (!notification) return;
        
        notification.textContent = message;
        notification.className = 'notification ' + type;
        
        // Show notification
        notification.classList.remove('hidden');
        
        // Hide after duration
        setTimeout(() => {
            notification.classList.add('hidden');
        }, duration);
    }
    
    // Add a button to show mock authenticator near the QR code
    setTimeout(() => {
        const qrCodeContainer = document.getElementById('qrcode-container');
        if (qrCodeContainer && !document.getElementById('show-mock-btn')) {
            const showMockBtn = document.createElement('button');
            showMockBtn.id = 'show-mock-btn';
            showMockBtn.className = 'secondary-button';
            showMockBtn.style.marginTop = '10px';
            showMockBtn.textContent = 'Show Mock Authenticator';
            showMockBtn.onclick = function() {
                if (typeof MockAuth !== 'undefined') {
                    MockAuth.showAuthenticator();
                }
            };
            
            qrCodeContainer.parentNode.insertBefore(showMockBtn, qrCodeContainer.nextSibling);
        }
    }, 1000);
});
