/**
 * Dashboard Module
 * Handles user dashboard and security settings
 */
const Dashboard = (function() {
    // DOM Elements
    const dashboardContainer = document.getElementById('dashboard-container');
    const userNameElement = document.getElementById('user-name');
    const twoFaStatusElement = document.getElementById('twofa-status');
    const enable2FAButton = document.getElementById('enable-2fa');
    const disable2FAButton = document.getElementById('disable-2fa');
    const viewRecoveryCodesButton = document.getElementById('view-recovery-codes');
    const generateNewCodesButton = document.getElementById('generate-new-codes');
    const logoutButton = document.getElementById('logout-button');
    const showMockAuthButton = document.getElementById('show-mock-auth');
    
    /**
     * Initialize the dashboard module
     */
    function init() {
        // Attach event listeners
        enable2FAButton.addEventListener('click', handleEnable2FA);
        disable2FAButton.addEventListener('click', handleDisable2FA);
        viewRecoveryCodesButton.addEventListener('click', handleViewRecoveryCodes);
        generateNewCodesButton.addEventListener('click', handleGenerateNewCodes);
        logoutButton.addEventListener('click', handleLogout);
        showMockAuthButton.addEventListener('click', handleShowMockAuth);
        
        // Initialize mock authenticator
        MockAuth.init();
    }
    
    /**
     * Load and display the dashboard
     */
    function loadDashboard() {
        // Display username
        const username = sessionStorage.getItem(Auth.STORAGE_KEYS.USERNAME);
        userNameElement.textContent = username || 'User';
        
        // Update security status
        updateSecurityStatus();
    }
    
    /**
     * Update the security status display
     */
    function updateSecurityStatus() {
        const is2FAEnabled = sessionStorage.getItem(Auth.STORAGE_KEYS.IS_2FA_ENABLED) === 'true';
        
        if (is2FAEnabled) {
            twoFaStatusElement.textContent = '2FA is currently enabled for your account.';
            twoFaStatusElement.className = 'status-enabled';
            enable2FAButton.classList.add('hidden');
            disable2FAButton.classList.remove('hidden');
            viewRecoveryCodesButton.disabled = false;
            generateNewCodesButton.disabled = false;
        } else {
            twoFaStatusElement.textContent = '2FA is currently disabled. Enable it to improve your account security.';
            twoFaStatusElement.className = 'status-disabled';
            enable2FAButton.classList.remove('hidden');
            disable2FAButton.classList.add('hidden');
            viewRecoveryCodesButton.disabled = true;
            generateNewCodesButton.disabled = true;
        }
    }
    
    /**
     * Handle enable 2FA button click
     */
    function handleEnable2FA() {
        TwoFA.startSetup();
    }
    
    /**
     * Handle disable 2FA button click
     */
    function handleDisable2FA() {
        TwoFA.disable2FA();
    }
    
    /**
     * Handle view recovery codes button click
     */
    function handleViewRecoveryCodes() {
        // This would typically make an API call to fetch recovery codes
        // For simplicity, we'll show a placeholder message
        App.showNotification('This feature would display your recovery codes.', 'info');
    }
    
    /**
     * Handle generate new codes button click
     */
    function handleGenerateNewCodes() {
        // This would typically make an API call to generate new recovery codes
        // For simplicity, we'll show a placeholder message
        App.showNotification('This feature would generate new recovery codes.', 'info');
    }
    
    /**
     * Handle logout button click
     */
    function handleLogout() {
        Auth.logout();
    }
    
    /**
     * Handle show mock authenticator button click
     */
    function handleShowMockAuth() {
        MockAuth.showAuthenticator();
    }
    
    // Public API
    return {
        init,
        loadDashboard,
        updateSecurityStatus
    };
})();
