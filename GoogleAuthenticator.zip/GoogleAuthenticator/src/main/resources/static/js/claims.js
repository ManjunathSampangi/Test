/**
 * Claims Module
 * Handles claim lookup, authentication, and claim details display
 */
const Claims = (function() {
    // API Endpoints
    const API_BASE = '/api/claims';
    const ENDPOINTS = {
        LOOKUP: `${API_BASE}/lookup`,
        DETAILS: `${API_BASE}/details`
    };
    
    // DOM Elements
    let claimLookupForm;
    let claimVerificationForm;
    let claimDetailsContainer;
    let claimLookupContainer;
    let claimVerificationContainer;
    
    /**
     * Initialize the claims module
     */
    function init() {
        // Get DOM elements
        claimLookupForm = document.getElementById('claim-lookup-form');
        claimVerificationForm = document.getElementById('claim-verification-form');
        claimDetailsContainer = document.getElementById('claim-details-container');
        claimLookupContainer = document.getElementById('claim-lookup-container');
        claimVerificationContainer = document.getElementById('claim-verification-container');
        
        // Attach event listeners
        claimLookupForm.addEventListener('submit', handleClaimLookup);
        claimVerificationForm.addEventListener('submit', handleClaimVerification);
        
        // Back buttons
        document.getElementById('back-to-lookup').addEventListener('click', function() {
            showClaimLookup();
        });
        document.getElementById('back-to-login').addEventListener('click', function() {
            hideAllClaimContainers();
            Auth.showLoginForm();
        });
    }
    
    /**
     * Handle claim lookup form submission
     * @param {Event} e - Form submit event
     */
    async function handleClaimLookup(e) {
        e.preventDefault();
        
        const claimNumber = document.getElementById('claim-number').value;
        
        try {
            const response = await fetch(`${ENDPOINTS.LOOKUP}/${claimNumber}`, {
                method: 'GET',
                headers: {
                    'Content-Type': 'application/json'
                }
            });
            
            const result = await response.json();
            
            if (result.success && result.data.exists) {
                // Claim exists, check if user is authenticated
                const userId = sessionStorage.getItem(Auth.STORAGE_KEYS.USER_ID);
                
                if (userId) {
                    // User is logged in, get claim details
                    getClaimDetails(claimNumber, userId);
                } else {
                    // User is not logged in, show message to login
                    App.showNotification('Please login to view claim details', 'info');
                    hideAllClaimContainers();
                    Auth.showLoginForm();
                    // Store claim number in session for after login
                    sessionStorage.setItem('pending_claim_number', claimNumber);
                }
            } else {
                App.showNotification('Claim not found. Please check the claim number and try again.', 'error');
            }
        } catch (error) {
            console.error('Claim lookup error:', error);
            App.showNotification('An error occurred during claim lookup. Please try again.', 'error');
        }
    }
    
    /**
     * Get claim details with user authentication
     * @param {string} claimNumber - The claim number
     * @param {string} userId - The user ID
     * @param {string} code - Optional verification code for 2FA
     */
    async function getClaimDetails(claimNumber, userId, code = null) {
        try {
            const requestBody = {
                claimNumber,
                userId
            };
            
            // Add code if provided
            if (code) {
                requestBody.code = code;
            }
            
            const response = await fetch(ENDPOINTS.DETAILS, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify(requestBody)
            });
            
            const result = await response.json();
            
            if (result.success) {
                if (result.data.requires2FA) {
                    // 2FA is required, show verification form
                    document.getElementById('verification-claim-number').value = claimNumber;
                    document.getElementById('verification-user-id').value = userId;
                    showClaimVerification();
                    App.showNotification('Please enter your authenticator code to view claim details', 'info');
                } else {
                    // Show claim details
                    displayClaimDetails(result.data);
                    showClaimDetails();
                }
            } else {
                App.showNotification(result.message || 'Failed to retrieve claim details', 'error');
            }
        } catch (error) {
            console.error('Get claim details error:', error);
            App.showNotification('An error occurred retrieving claim details. Please try again.', 'error');
        }
    }
    
    /**
     * Handle claim verification form submission
     * @param {Event} e - Form submit event
     */
    async function handleClaimVerification(e) {
        e.preventDefault();
        
        const claimNumber = document.getElementById('verification-claim-number').value;
        const userId = document.getElementById('verification-user-id').value;
        const code = document.getElementById('verification-code').value;
        
        // Get claim details with verification code
        getClaimDetails(claimNumber, userId, code);
    }
    
    /**
     * Display claim details in the UI
     * @param {Object} claimData - The claim data
     */
    function displayClaimDetails(claimData) {
        // Format date
        const filingDate = new Date(claimData.filingDate);
        const formattedDate = filingDate.toLocaleDateString('en-US', {
            year: 'numeric', 
            month: 'long', 
            day: 'numeric'
        });
        
        // Format currency
        const formattedAmount = new Intl.NumberFormat('en-US', {
            style: 'currency',
            currency: 'USD'
        }).format(claimData.amount);
        
        // Set values in the UI
        document.getElementById('claim-detail-number').textContent = claimData.claimNumber;
        document.getElementById('claim-detail-description').textContent = claimData.description;
        document.getElementById('claim-detail-date').textContent = formattedDate;
        document.getElementById('claim-detail-status').textContent = claimData.status;
        document.getElementById('claim-detail-amount').textContent = formattedAmount;
        document.getElementById('claim-detail-claimant').textContent = claimData.claimantName;
        document.getElementById('claim-detail-policy').textContent = claimData.policyNumber;
        
        // Apply status-specific styling
        const statusElement = document.getElementById('claim-detail-status');
        statusElement.className = 'claim-status'; // Reset classes
        
        // Add status-specific class
        if (claimData.status === 'Approved') {
            statusElement.classList.add('status-approved');
        } else if (claimData.status === 'Under Review') {
            statusElement.classList.add('status-review');
        } else if (claimData.status === 'Pending Documentation') {
            statusElement.classList.add('status-pending');
        } else if (claimData.status === 'Denied') {
            statusElement.classList.add('status-denied');
        }
    }
    
    /**
     * Show the claim lookup form
     */
    function showClaimLookup() {
        hideAllClaimContainers();
        claimLookupContainer.classList.remove('hidden');
    }
    
    /**
     * Show the claim verification form
     */
    function showClaimVerification() {
        hideAllClaimContainers();
        claimVerificationContainer.classList.remove('hidden');
    }
    
    /**
     * Show the claim details container
     */
    function showClaimDetails() {
        hideAllClaimContainers();
        claimDetailsContainer.classList.remove('hidden');
    }
    
    /**
     * Hide all claim-related containers
     */
    function hideAllClaimContainers() {
        claimLookupContainer.classList.add('hidden');
        claimVerificationContainer.classList.add('hidden');
        claimDetailsContainer.classList.add('hidden');
    }
    
    /**
     * Check if there's a pending claim from before login
     */
    function checkPendingClaim() {
        const pendingClaimNumber = sessionStorage.getItem('pending_claim_number');
        const userId = sessionStorage.getItem(Auth.STORAGE_KEYS.USER_ID);
        
        if (pendingClaimNumber && userId) {
            // Clear the pending claim
            sessionStorage.removeItem('pending_claim_number');
            
            // Get the claim details
            getClaimDetails(pendingClaimNumber, userId);
            return true;
        }
        
        return false;
    }
    
    // Public API
    return {
        init,
        showClaimLookup,
        hideAllClaimContainers,
        checkPendingClaim
    };
})();
