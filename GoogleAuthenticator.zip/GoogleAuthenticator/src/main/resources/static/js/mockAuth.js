/**
 * Mock Authenticator Module
 * Simulates Google Authenticator for POC and demo purposes
 * Allows testing the full E2E flow without requiring a mobile device
 */
const MockAuth = (function() {
    // API Endpoints
    const API_BASE = '/api/mock';
    const ENDPOINTS = {
        STORE_SECRET: `${API_BASE}/store-secret`,
        GENERATE_CODE: `${API_BASE}/generate-code`,
        TIME_REMAINING: `${API_BASE}/time-remaining`
    };
    
    // DOM Elements - we'll create these dynamically
    let mockContainer = null;
    let codeDisplay = null;
    let timerProgress = null;
    let timerDisplay = null;
    
    // Timer variables
    let timerInterval = null;
    let secondsRemaining = 30;
    
    /**
     * Initialize the mock authenticator
     */
    function init() {
        // Create mock authenticator UI if it doesn't exist
        if (!document.getElementById('mock-authenticator')) {
            createMockAuthenticatorUI();
        }
        
        // Start with hidden state
        hideAuthenticator();
    }
    
    /**
     * Create the mock authenticator UI
     */
    function createMockAuthenticatorUI() {
        // Create container
        mockContainer = document.createElement('div');
        mockContainer.id = 'mock-authenticator';
        mockContainer.className = 'mock-authenticator';
        
        // Create header with title and close button
        const header = document.createElement('div');
        header.className = 'mock-header';
        
        const title = document.createElement('h3');
        title.textContent = 'Mock Google Authenticator';
        
        const closeButton = document.createElement('button');
        closeButton.className = 'mock-close';
        closeButton.textContent = '×';
        closeButton.addEventListener('click', hideAuthenticator);
        
        header.appendChild(title);
        header.appendChild(closeButton);
        
        // Create code display
        const codeSection = document.createElement('div');
        codeSection.className = 'mock-code-section';
        
        codeDisplay = document.createElement('div');
        codeDisplay.className = 'mock-code-display';
        codeDisplay.textContent = '------';
        
        codeSection.appendChild(codeDisplay);
        
        // Create timer display
        const timerSection = document.createElement('div');
        timerSection.className = 'mock-timer-section';
        
        timerProgress = document.createElement('div');
        timerProgress.className = 'mock-timer-progress';
        
        timerDisplay = document.createElement('div');
        timerDisplay.className = 'mock-timer-display';
        timerDisplay.textContent = '30s';
        
        timerSection.appendChild(timerProgress);
        timerSection.appendChild(timerDisplay);
        
        // Create actions section
        const actionsSection = document.createElement('div');
        actionsSection.className = 'mock-actions-section';
        
        const refreshButton = document.createElement('button');
        refreshButton.className = 'mock-refresh';
        refreshButton.textContent = 'Refresh';
        refreshButton.addEventListener('click', refreshCode);
        
        const copyButton = document.createElement('button');
        copyButton.className = 'mock-copy';
        copyButton.textContent = 'Copy Code';
        copyButton.addEventListener('click', copyCodeToClipboard);
        
        actionsSection.appendChild(refreshButton);
        actionsSection.appendChild(copyButton);
        
        // Assemble everything
        mockContainer.appendChild(header);
        mockContainer.appendChild(codeSection);
        mockContainer.appendChild(timerSection);
        mockContainer.appendChild(actionsSection);
        
        // Add to page
        document.body.appendChild(mockContainer);
        
        // Add CSS styles for mock authenticator
        addMockAuthenticatorStyles();
    }
    
    /**
     * Add CSS styles for mock authenticator
     */
    function addMockAuthenticatorStyles() {
        const style = document.createElement('style');
        style.textContent = `
            .mock-authenticator {
                position: fixed;
                bottom: 20px;
                left: 20px;
                width: 300px;
                background-color: #fff;
                border-radius: 8px;
                box-shadow: 0 2px 10px rgba(0, 0, 0, 0.2);
                overflow: hidden;
                z-index: 1000;
                font-family: 'Roboto', sans-serif;
            }
            
            .mock-header {
                display: flex;
                justify-content: space-between;
                align-items: center;
                background-color: #4285F4;
                color: white;
                padding: 10px 15px;
            }
            
            .mock-header h3 {
                margin: 0;
                font-size: 16px;
            }
            
            .mock-close {
                background: none;
                border: none;
                color: white;
                font-size: 20px;
                cursor: pointer;
                padding: 0;
                line-height: 1;
            }
            
            .mock-code-section {
                padding: 20px;
                text-align: center;
            }
            
            .mock-code-display {
                font-family: 'Courier New', monospace;
                font-size: 32px;
                font-weight: bold;
                letter-spacing: 2px;
                color: #333;
            }
            
            .mock-timer-section {
                padding: 0 20px 20px;
                position: relative;
            }
            
            .mock-timer-progress {
                height: 4px;
                background-color: #ddd;
                border-radius: 2px;
                overflow: hidden;
                position: relative;
            }
            
            .mock-timer-progress::before {
                content: '';
                position: absolute;
                left: 0;
                top: 0;
                height: 100%;
                background-color: #4285F4;
                width: 100%;
                transition: width 1s linear;
            }
            
            .mock-timer-display {
                text-align: center;
                font-size: 12px;
                margin-top: 5px;
                color: #666;
            }
            
            .mock-actions-section {
                display: flex;
                padding: 0 20px 20px;
                gap: 10px;
            }
            
            .mock-refresh, .mock-copy {
                flex: 1;
                background-color: #f5f5f5;
                border: none;
                border-radius: 4px;
                padding: 8px 0;
                cursor: pointer;
                color: #555;
                font-size: 14px;
                transition: background-color 0.3s ease;
            }
            
            .mock-refresh:hover, .mock-copy:hover {
                background-color: #e0e0e0;
            }
        `;
        document.head.appendChild(style);
    }
    
    /**
     * Store the user's secret when 2FA is set up
     * @param {string} userId - The user ID
     * @param {string} secretKey - The secret key
     */
    async function storeSecret(userId, secretKey) {
        try {
            const response = await fetch(ENDPOINTS.STORE_SECRET, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({ userId, secretKey })
            });
            
            const result = await response.json();
            return result.success;
        } catch (error) {
            console.error('Failed to store secret:', error);
            return false;
        }
    }
    
    /**
     * Generate and display a new TOTP code
     */
    async function refreshCode() {
        const userId = sessionStorage.getItem(Auth.STORAGE_KEYS.USER_ID);
        
        if (!userId) {
            codeDisplay.textContent = 'ERROR';
            return;
        }
        
        try {
            const response = await fetch(ENDPOINTS.GENERATE_CODE, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({ userId })
            });
            
            const result = await response.json();
            
            if (result.success) {
                codeDisplay.textContent = result.data.code;
                updateTimer(result.data.secondsRemaining);
            } else {
                codeDisplay.textContent = 'ERROR';
            }
        } catch (error) {
            console.error('Failed to generate code:', error);
            codeDisplay.textContent = 'ERROR';
        }
    }
    
    /**
     * Update timer display and progress
     * @param {number} seconds - Seconds remaining
     */
    function updateTimer(seconds) {
        // Clear existing timer
        if (timerInterval) {
            clearInterval(timerInterval);
        }
        
        secondsRemaining = seconds;
        timerDisplay.textContent = `${secondsRemaining}s`;
        
        // Update progress bar
        const progress = (secondsRemaining / 30) * 100;
        timerProgress.style.setProperty('--progress', `${progress}%`);
        timerProgress.querySelector('::before').style.width = `${progress}%`;
        
        // Start timer
        timerInterval = setInterval(() => {
            secondsRemaining--;
            timerDisplay.textContent = `${secondsRemaining}s`;
            
            // Update progress bar
            const progress = (secondsRemaining / 30) * 100;
            timerProgress.style.setProperty('--progress', `${progress}%`);
            
            if (secondsRemaining <= 0) {
                clearInterval(timerInterval);
                refreshCode();
            }
        }, 1000);
    }
    
    /**
     * Copy the current code to clipboard
     */
    function copyCodeToClipboard() {
        const code = codeDisplay.textContent;
        
        if (code === '------' || code === 'ERROR') {
            return;
        }
        
        navigator.clipboard.writeText(code)
            .then(() => {
                App.showNotification('Code copied to clipboard', 'success');
            })
            .catch(err => {
                console.error('Failed to copy code:', err);
                App.showNotification('Failed to copy code', 'error');
            });
    }
    
    /**
     * Show the mock authenticator and generate a code
     */
    function showAuthenticator() {
        mockContainer.style.display = 'block';
        refreshCode();
    }
    
    /**
     * Hide the mock authenticator
     */
    function hideAuthenticator() {
        if (mockContainer) {
            mockContainer.style.display = 'none';
        }
        
        // Clear timer
        if (timerInterval) {
            clearInterval(timerInterval);
            timerInterval = null;
        }
    }
    
    // Public API
    return {
        init,
        storeSecret,
        showAuthenticator,
        hideAuthenticator,
        refreshCode
    };
})();
