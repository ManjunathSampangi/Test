/**
 * JavaScript functions for Google Authenticator integration
 */

// Format the verification code input field to only accept numbers
function formatVerificationInput(input) {
    // Remove any non-numeric characters
    input.value = input.value.replace(/[^0-9]/g, '');
    
    // Limit to 6 digits
    if (input.value.length > 6) {
        input.value = input.value.slice(0, 6);
    }
}

// Previously would auto-submit, now just enables the submit button when complete
function autoSubmitOnComplete(input, formId) {
    const submitButton = document.querySelector(`#${formId} button[type="submit"]`);
    if (input.value.length === 6) {
        submitButton.removeAttribute('disabled');
    } else {
        submitButton.setAttribute('disabled', 'disabled');
    }
}

// Format recovery code to uppercase and remove spaces
function formatRecoveryCode(input) {
    // Convert to uppercase and remove spaces
    input.value = input.value.replace(/\s/g, '').toUpperCase();
    
    // Limit to 10 characters
    if (input.value.length > 10) {
        input.value = input.value.slice(0, 10);
    }
}

// Copy the secret key to clipboard
function copyToClipboard(elementId) {
    const element = document.getElementById(elementId);
    const text = element.innerText;
    
    navigator.clipboard.writeText(text).then(() => {
        // Show success message
        const tooltip = document.getElementById('copy-tooltip');
        tooltip.style.display = 'block';
        
        // Hide tooltip after 2 seconds
        setTimeout(() => {
            tooltip.style.display = 'none';
        }, 2000);
    });
}

// Countdown timer for code expiration
function startCountdown(elementId, seconds) {
    const element = document.getElementById(elementId);
    let timeLeft = seconds;
    
    const countdownInterval = setInterval(() => {
        timeLeft--;
        
        if (timeLeft <= 0) {
            clearInterval(countdownInterval);
            element.innerText = "Expired";
            
            // Optional: auto-refresh the page to get a new code
            // location.reload();
        } else {
            element.innerText = timeLeft + " seconds";
        }
    }, 1000);
}
