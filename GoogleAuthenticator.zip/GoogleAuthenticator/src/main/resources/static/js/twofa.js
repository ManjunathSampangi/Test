/**
 * Two-Factor Authentication Module
 * Handles 2FA setup, verification, and management
 */
const TwoFA = (function() {
    // API Endpoints
    const API_BASE = '/api/auth';
    const ENDPOINTS = {
        ENABLE_2FA: `${API_BASE}/enable-2fa`,
        VERIFY_2FA_SETUP: `${API_BASE}/verify-2fa-setup`,
        DISABLE_2FA: `${API_BASE}/disable-2fa`
    };
    
    // DOM Elements
    const setupContainer = document.getElementById('twofa-setup-container');
    const recoveryCodesContainer = document.getElementById('recovery-codes-container');
    const qrCodeContainer = document.getElementById('qrcode-container');
    const secretKeyElement = document.getElementById('secret-key');
    const verifySetupForm = document.getElementById('verify-setup');
    const recoveryCodesList = document.getElementById('recovery-codes-list');
    const recoveryCodesDoneButton = document.getElementById('recovery-codes-done');
    
    // Current setup state
    let currentRecoveryCodes = [];
    
    /**
     * Initialize the two-factor authentication module
     */
    function init() {
        // Attach event listeners
        verifySetupForm.addEventListener('submit', handleVerifySetup);
        recoveryCodesDoneButton.addEventListener('click', handleRecoveryCodesDone);
    }
    
    /**
     * Start the 2FA setup process
     */
    async function startSetup() {
        const userId = sessionStorage.getItem(Auth.STORAGE_KEYS.USER_ID);
        
        if (!userId) {
            App.showNotification('You must be logged in to enable 2FA', 'error');
            return;
        }
        
        try {
            // Show loading state
            qrCodeContainer.innerHTML = '<div class="loading">Loading...</div>';
            secretKeyElement.textContent = 'Generating...';
            
            // Make API request to start 2FA setup
            const response = await fetch(ENDPOINTS.ENABLE_2FA, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({ userId })
            });
            
            const result = await response.json();
            
            if (result.success) {
                // Display the QR code for scanning
                const qrCodeImg = document.createElement('img');
                qrCodeImg.src = `data:image/png;base64,${result.data.qrCodeBase64}`;
                qrCodeImg.alt = 'QR Code for Google Authenticator';
                qrCodeContainer.innerHTML = '';
                qrCodeContainer.appendChild(qrCodeImg);
                
                // Display the secret key for manual entry
                secretKeyElement.textContent = result.data.secret;
                
                // Store the secret key in our mock authenticator (for POC/demo purposes)
                await MockAuth.storeSecret(userId, result.data.secret);
                
                // Store recovery codes for later display
                currentRecoveryCodes = result.data.recoveryCodes;
                
                // Set user ID for verification form
                document.getElementById('setup-user-id').value = userId;
                
                // Show the setup container
                App.hideAllContainers();
                setupContainer.classList.remove('hidden');
            } else {
                App.showNotification(result.message || '2FA setup failed', 'error');
            }
        } catch (error) {
            console.error('2FA setup error:', error);
            App.showNotification('An error occurred during 2FA setup. Please try again.', 'error');
        }
    }
    
    /**
     * Handle 2FA setup verification form submission
     * @param {Event} e - Form submit event
     */
    async function handleVerifySetup(e) {
        e.preventDefault();
        
        const userId = document.getElementById('setup-user-id').value;
        const verificationCode = document.getElementById('setup-code').value;
        
        try {
            const response = await fetch(ENDPOINTS.VERIFY_2FA_SETUP, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({ userId, verificationCode })
            });
            
            const result = await response.json();
            
            if (result.success) {
                // Show recovery codes
                showRecoveryCodes();
                
                // Update session storage
                sessionStorage.setItem(Auth.STORAGE_KEYS.IS_2FA_ENABLED, 'true');
                
                App.showNotification('2FA has been enabled successfully', 'success');
            } else {
                App.showNotification(result.message || 'Invalid verification code', 'error');
            }
        } catch (error) {
            console.error('2FA verification error:', error);
            App.showNotification('An error occurred during verification. Please try again.', 'error');
        }
    }
    
    /**
     * Display recovery codes to the user
     */
    function showRecoveryCodes() {
        // Clear previous codes
        recoveryCodesList.innerHTML = '';
        
        // Create and append recovery codes
        currentRecoveryCodes.forEach(code => {
            const codeElement = document.createElement('div');
            codeElement.className = 'code';
            codeElement.textContent = code;
            recoveryCodesList.appendChild(codeElement);
        });
        
        // Hide setup container and show recovery codes
        setupContainer.classList.add('hidden');
        recoveryCodesContainer.classList.remove('hidden');
    }
    
    /**
     * Handle recovery codes done button click
     */
    function handleRecoveryCodesDone() {
        recoveryCodesContainer.classList.add('hidden');
        App.showDashboard();
        Dashboard.updateSecurityStatus();
    }
    
    /**
     * Disable 2FA for the current user
     */
    async function disable2FA() {
        const userId = sessionStorage.getItem(Auth.STORAGE_KEYS.USER_ID);
        
        if (!userId) {
            App.showNotification('You must be logged in to disable 2FA', 'error');
            return;
        }
        
        // Confirm with user
        if (!confirm('Are you sure you want to disable two-factor authentication? This will make your account less secure.')) {
            return;
        }
        
        try {
            const response = await fetch(ENDPOINTS.DISABLE_2FA, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({ userId })
            });
            
            const result = await response.json();
            
            if (result.success) {
                // Update session storage
                sessionStorage.setItem(Auth.STORAGE_KEYS.IS_2FA_ENABLED, 'false');
                
                // Update dashboard
                Dashboard.updateSecurityStatus();
                
                App.showNotification('2FA has been disabled', 'success');
            } else {
                App.showNotification(result.message || 'Failed to disable 2FA', 'error');
            }
        } catch (error) {
            console.error('Disable 2FA error:', error);
            App.showNotification('An error occurred. Please try again.', 'error');
        }
    }
    
    // Public API
    return {
        init,
        startSetup,
        disable2FA,
        showRecoveryCodes
    };
})();
