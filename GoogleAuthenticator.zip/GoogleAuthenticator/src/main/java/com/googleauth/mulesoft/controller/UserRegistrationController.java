package com.googleauth.mulesoft.controller;

import com.googleauth.mulesoft.model.User;
import com.googleauth.mulesoft.service.UserService;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import java.util.Optional;

/**
 * Controller for handling user registration and authentication flows
 */
@Controller
public class UserRegistrationController {

    private final UserService userService;
    private final SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");

    @Autowired
    public UserRegistrationController(UserService userService) {
        this.userService = userService;
    }

    /**
     * Show registration page
     */
    @GetMapping("/register")
    public String showRegistrationPage(Model model) {
        return "register";
    }

    /**
     * Handle policy-based registration
     */
    @PostMapping("/register")
    public String registerUser(@RequestParam String policyNumber, 
                              @RequestParam String firstName, 
                              @RequestParam String lastName, 
                              @RequestParam String dateOfBirth, 
                              @RequestParam String email,
                              Model model) {
        try {
            // Parse date of birth
            Date dob = dateFormat.parse(dateOfBirth);
            
            // Register user and get temporary password
            UserService.RegistrationResult result = userService.registerWithPolicy(policyNumber, firstName, lastName, dob, email);
            User user = result.getUser();
            String tempPassword = result.getTempPassword();
            
            // Add user info and temporary password to model
            model.addAttribute("username", user.getUsername());
            model.addAttribute("tempPassword", tempPassword);
            
            return "registration-success";
        } catch (ParseException e) {
            model.addAttribute("error", "Invalid date format");
            return "register";
        } catch (Exception e) {
            model.addAttribute("error", e.getMessage());
            return "register";
        }
    }

    /**
     * Show login page
     */
    @GetMapping("/login")
    public String showLoginPage() {
        return "login";
    }

    /**
     * Show password reset page
     */
    @GetMapping("/reset-password")
    public String showResetPasswordPage() {
        return "reset-password";
    }

    /**
     * Handle password reset request
     */
    @PostMapping("/reset-password")
    public String resetPassword(@RequestParam String username, Model model) {
        try {
            Optional<User> userOpt = userService.findByUsername(username);
            if (userOpt.isPresent()) {
                String tempPassword = userService.resetPassword(userOpt.get().getId());
                // In a real application, this would be sent via email
                System.out.println("Temporary password generated: " + tempPassword + " (would be emailed to user)");
                model.addAttribute("message", "A temporary password has been sent to your email");
            } else {
                model.addAttribute("message", "If this username exists, a password reset email has been sent");
            }
            return "reset-password-confirmation";
        } catch (Exception e) {
            model.addAttribute("error", e.getMessage());
            return "reset-password";
        }
    }

    /**
     * Show password change form for users with temporary passwords
     */
    @GetMapping("/change-password")
    public String showChangePasswordPage() {
        return "change-password";
    }

    /**
     * Handle password change
     */
    @PostMapping("/change-password")
    public String changePassword(@RequestParam String username, 
                               @RequestParam String oldPassword,
                               @RequestParam String newPassword,
                               Model model) {
        try {
            Optional<User> userOpt = userService.authenticateUser(username, oldPassword);
            if (userOpt.isPresent()) {
                User user = userOpt.get();
                
                // Check if password is temporary or expired
                if (user.isTempPassword()) {
                    userService.changePassword(user.getId(), newPassword);
                    model.addAttribute("message", "Password changed successfully");
                    return "password-change-success";
                } else {
                    model.addAttribute("error", "Your password is not marked for change");
                    return "change-password";
                }
            } else {
                model.addAttribute("error", "Invalid username or password");
                return "change-password";
            }
        } catch (Exception e) {
            model.addAttribute("error", e.getMessage());
            return "change-password";
        }
    }

    /**
     * Show email OTP page
     */
    @GetMapping("/email-otp")
    public String showEmailOtpPage() {
        return "email-otp";
    }

    /**
     * Send email OTP
     */
    @PostMapping("/send-email-otp")
    public String sendEmailOTP(@RequestParam String email, Model model) {
        try {
            String otp = userService.generateEmailOTP(email);
            // In a real application, this would be sent via email
            System.out.println("OTP generated: " + otp + " (would be emailed to " + email + ")");
            model.addAttribute("message", "OTP has been sent to your email");
            model.addAttribute("email", email);
            return "verify-otp";
        } catch (Exception e) {
            model.addAttribute("error", e.getMessage());
            return "email-otp";
        }
    }

    /**
     * Verify email OTP
     */
    @PostMapping("/verify-otp")
    public String verifyEmailOTP(@RequestParam String email, 
                              @RequestParam String otp,
                              Model model) {
        try {
            boolean isValid = userService.verifyEmailOTP(email, otp);
            if (isValid) {
                model.addAttribute("message", "Email verified successfully");
                return "otp-success";
            } else {
                model.addAttribute("error", "Invalid or expired OTP");
                model.addAttribute("email", email);
                return "verify-otp";
            }
        } catch (Exception e) {
            model.addAttribute("error", e.getMessage());
            return "verify-otp";
        }
    }

    // Claim lookup functionality moved to dedicated ClaimLookupController

    /**
     * REST endpoint for OKTA temporary registration
     */
    @RestController
    @RequestMapping("/api/okta")
    public static class OktaRegistrationRestController {
        
        private final UserService userService;
        
        @Autowired
        public OktaRegistrationRestController(UserService userService) {
            this.userService = userService;
        }
        
        @PostMapping("/register-temp")
        public ResponseEntity<Map<String, Object>> registerTemporary(@RequestBody Map<String, String> payload) {
            String policyNumber = payload.get("policyNumber");
            String email = payload.get("email");
            
            if (policyNumber == null || email == null) {
                return ResponseEntity.badRequest().body(createErrorResponse("Missing required fields"));
            }
            
            try {
                // Verify that the email is not already registered
                boolean emailExists = userService.findByUsername(policyNumber).isPresent();
                if (emailExists) {
                    return ResponseEntity.badRequest().body(createErrorResponse("Policy number already registered"));
                }
                
                // In a real implementation, we would integrate with OKTA API
                Map<String, Object> response = new HashMap<>();
                response.put("success", true);
                response.put("message", "Temporary registration created with OKTA");
                return ResponseEntity.ok(response);
            } catch (Exception e) {
                return ResponseEntity.badRequest().body(createErrorResponse(e.getMessage()));
            }
        }
        
        private Map<String, Object> createErrorResponse(String message) {
            Map<String, Object> response = new HashMap<>();
            response.put("success", false);
            response.put("message", message);
            return response;
        }
    }
}
