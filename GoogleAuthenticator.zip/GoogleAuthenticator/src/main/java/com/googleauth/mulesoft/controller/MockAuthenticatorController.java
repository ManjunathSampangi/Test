package com.googleauth.mulesoft.controller;

import com.googleauth.mulesoft.service.MockAuthenticatorService;
import com.fasterxml.jackson.databind.ObjectMapper;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.Map;

/**
 * Controller for handling mock authenticator endpoint requests
 * Used for demonstration and POC purposes
 */
@RestController
@RequestMapping("/api/mock")
public class MockAuthenticatorController {

    private final MockAuthenticatorService mockService;
    private final ObjectMapper objectMapper;
    
    @Autowired
    public MockAuthenticatorController(MockAuthenticatorService mockService) {
        this.mockService = mockService;
        this.objectMapper = new ObjectMapper();
    }
    
    /**
     * Store a user's secret key for the mock authenticator
     * @param data Map containing userId and secretKey
     * @return Success response
     * @throws Exception if operation fails
     */
    @PostMapping(value = "/store-secret", produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<String> storeSecret(@RequestBody Map<String, String> data) throws Exception {
        String userId = data.get("userId");
        String secretKey = data.get("secretKey");
        
        if (userId == null || secretKey == null) {
            return ResponseEntity.badRequest().body(createErrorResponse("Missing required fields: userId, secretKey"));
        }
        
        try {
            mockService.storeUserSecret(userId, secretKey);
            return ResponseEntity.ok(createSuccessResponse("Secret stored successfully", null));
        } catch (Exception e) {
            return ResponseEntity.badRequest().body(createErrorResponse("Failed to store secret: " + e.getMessage()));
        }
    }
    
    /**
     * Generate current TOTP code for a user
     * @param data Map containing userId
     * @return Current TOTP code and seconds remaining
     * @throws Exception if operation fails
     */
    @PostMapping(value = "/generate-code", produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<String> generateCode(@RequestBody Map<String, String> data) throws Exception {
        String userId = data.get("userId");
        
        if (userId == null) {
            return ResponseEntity.badRequest().body(createErrorResponse("Missing required field: userId"));
        }
        
        try {
            String code = mockService.generateCurrentCode(userId);
            int secondsRemaining = mockService.getSecondsRemaining();
            
            return ResponseEntity.ok(createSuccessResponse("Code generated successfully", 
                    Map.of("code", code, "secondsRemaining", secondsRemaining)));
        } catch (Exception e) {
            return ResponseEntity.badRequest().body(createErrorResponse("Failed to generate code: " + e.getMessage()));
        }
    }
    
    /**
     * Get seconds remaining for the current TOTP period
     * @return Seconds remaining until the current code expires
     * @throws Exception if operation fails
     */
    @GetMapping(value = "/time-remaining", produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<String> getTimeRemaining() throws Exception {
        try {
            int secondsRemaining = mockService.getSecondsRemaining();
            return ResponseEntity.ok(createSuccessResponse("Time remaining retrieved", 
                    Map.of("secondsRemaining", secondsRemaining)));
        } catch (Exception e) {
            return ResponseEntity.badRequest().body(createErrorResponse("Failed to get time remaining: " + e.getMessage()));
        }
    }
    
    /**
     * Creates a success response in JSON format
     * @param message Success message
     * @param data Additional data (can be null)
     * @return JSON string response
     * @throws Exception if serialization fails
     */
    private String createSuccessResponse(String message, Map<String, Object> data) throws Exception {
        Map<String, Object> response = new HashMap<>();
        response.put("success", true);
        response.put("message", message);
        
        if (data != null) {
            response.put("data", data);
        }
        
        return objectMapper.writeValueAsString(response);
    }
    
    /**
     * Creates an error response in JSON format
     * @param message Error message
     * @return JSON string response
     * @throws Exception if serialization fails
     */
    private String createErrorResponse(String message) throws Exception {
        Map<String, Object> response = new HashMap<>();
        response.put("success", false);
        response.put("message", message);
        
        return objectMapper.writeValueAsString(response);
    }
}
