package com.googleauth.mulesoft.config;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Profile;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.authority.mapping.GrantedAuthoritiesMapper;
import org.springframework.security.oauth2.core.oidc.user.OidcUserAuthority;
import org.springframework.security.oauth2.core.user.OAuth2UserAuthority;
import org.springframework.security.web.SecurityFilterChain;
import org.springframework.security.web.authentication.AuthenticationSuccessHandler;
import org.springframework.web.cors.CorsConfigurationSource;

import java.util.HashSet;
import java.util.List;
import java.util.Set;

/**
 * Security configuration for OKTA OAuth2 integration
 * Handles authentication flow and user authorization
 * Only active when 'okta' profile is used
 */
@Configuration
@EnableWebSecurity
@Profile("okta")
public class OktaSecurityConfig {

    @Autowired
    private CorsConfigurationSource corsConfigurationSource;

    /**
     * Configure security filter chain for OKTA integration
     */
    @Bean
    public SecurityFilterChain filterChain(HttpSecurity http) throws Exception {
        http
            .cors(cors -> cors.configurationSource(corsConfigurationSource))
            .authorizeHttpRequests(authz -> authz
                // Public endpoints - no authentication required
                .antMatchers("/", "/index.html", "/okta-registration", "/okta-info", "/okta-login",
                            "/static/**", "/css/**", "/js/**", "/images/**",
                            "/api/mock/**", "/api/auth/**", "/test-otp", "/health").permitAll()
                
                // OAuth2 endpoints
                .antMatchers("/login/oauth2/code/okta", "/oauth2/**").permitAll()
                
                // All other requests require authentication
                .anyRequest().authenticated()
            )
            
            // OAuth2 Login configuration
            .oauth2Login(oauth2 -> oauth2
                .loginPage("/oauth2/authorization/okta")
                .successHandler(oktaAuthenticationSuccessHandler())
                .failureUrl("/okta-login-error")
                .userInfoEndpoint(userInfo -> userInfo
                    .userAuthoritiesMapper(userAuthoritiesMapper())
                )
            )
            
            // Logout configuration
            .logout(logout -> logout
                .logoutUrl("/logout")
                .logoutSuccessUrl("/okta-logout-success")
                .invalidateHttpSession(true)
                .clearAuthentication(true)
                .deleteCookies("JSESSIONID")
            )
            
            // CSRF configuration - disable for API endpoints
            .csrf(csrf -> csrf
                .ignoringAntMatchers("/api/**", "/logout")
            );

        return http.build();
    }

    /**
     * Custom authentication success handler for OKTA login
     */
    @Bean
    public AuthenticationSuccessHandler oktaAuthenticationSuccessHandler() {
        return (request, response, authentication) -> {
            // Log successful OKTA authentication
            System.out.println("\n\n==================== OKTA AUTHENTICATION SUCCESS ====================\n");
            System.out.println("   User: " + authentication.getName());
            System.out.println("   Authorities: " + authentication.getAuthorities());
            System.out.println("   Redirect: Claims Lookup Portal");
            System.out.println("\n==================================================================\n\n");
            
            // Redirect to claims lookup page after successful OKTA authentication
            response.sendRedirect("/claim-lookup?oktaAuth=success");
        };
    }

    /**
     * Map OKTA user authorities to application roles
     */
    @Bean
    public GrantedAuthoritiesMapper userAuthoritiesMapper() {
        return (authorities) -> {
            Set<GrantedAuthority> mappedAuthorities = new HashSet<>();

            authorities.forEach(authority -> {
                // Handle OIDC authorities from OKTA
                if (authority instanceof OidcUserAuthority) {
                    OidcUserAuthority oidcUserAuthority = (OidcUserAuthority) authority;
                    
                    // Add default user role
                    mappedAuthorities.add(new SimpleGrantedAuthority("ROLE_USER"));
                    
                    // Map OKTA groups to roles if available
                    if (oidcUserAuthority.getAttributes().containsKey("groups")) {
                        @SuppressWarnings("unchecked")
                        List<String> groups = (List<String>) oidcUserAuthority.getAttributes().get("groups");
                        groups.forEach(group -> {
                            if (group.contains("Admin")) {
                                mappedAuthorities.add(new SimpleGrantedAuthority("ROLE_ADMIN"));
                            }
                            if (group.contains("Claims")) {
                                mappedAuthorities.add(new SimpleGrantedAuthority("ROLE_CLAIMS_USER"));
                            }
                        });
                    }
                }
                // Handle OAuth2 authorities
                else if (authority instanceof OAuth2UserAuthority) {
                    mappedAuthorities.add(new SimpleGrantedAuthority("ROLE_USER"));
                }
                else {
                    mappedAuthorities.add(authority);
                }
            });

            return mappedAuthorities;
        };
    }
} 