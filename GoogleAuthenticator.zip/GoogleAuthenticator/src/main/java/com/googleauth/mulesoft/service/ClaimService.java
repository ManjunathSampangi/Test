package com.googleauth.mulesoft.service;

import com.googleauth.mulesoft.model.Claim;
import org.springframework.stereotype.Service;

import java.util.*;

/**
 * Service for managing claim operations
 */
@Service
public class ClaimService {

    // In-memory storage for claims (would be a database in production)
    private final Map<String, Claim> claimStore = new HashMap<>();
    
    public ClaimService() {
        // Initialize with sample claims for demonstration
        initializeSampleClaims();
    }
    
    /**
     * Find a claim by its claim number
     * @param claimNumber Claim number to search for
     * @return Optional containing the claim if found, empty otherwise
     */
    public Optional<Claim> findByClaimNumber(String claimNumber) {
        return Optional.ofNullable(claimStore.get(claimNumber));
    }
    
    /**
     * Create a new claim
     * @param claim The claim to create
     * @return The created claim
     */
    public Claim createClaim(Claim claim) {
        if (claim.getClaimNumber() == null || claim.getClaimNumber().isEmpty()) {
            claim.setClaimNumber(generateClaimNumber());
        }
        claimStore.put(claim.getClaimNumber(), claim);
        return claim;
    }
    
    /**
     * Update an existing claim
     * @param claim The claim with updated information
     * @return The updated claim
     */
    public Claim updateClaim(Claim claim) {
        if (!claimStore.containsKey(claim.getClaimNumber())) {
            throw new IllegalArgumentException("Claim not found");
        }
        
        claim.setUpdatedAt(new Date());
        claimStore.put(claim.getClaimNumber(), claim);
        return claim;
    }
    
    /**
     * Get all claims (for administrative purposes)
     * @return List of all claims
     */
    public List<Claim> getAllClaims() {
        return new ArrayList<>(claimStore.values());
    }
    
    /**
     * Generate a unique claim number
     * @return A new unique claim number
     */
    private String generateClaimNumber() {
        // Format: CL-YYYYMMDD-XXXXXX (where X is a random digit)
        Calendar cal = Calendar.getInstance();
        String datePart = String.format("%04d%02d%02d", 
                cal.get(Calendar.YEAR), 
                cal.get(Calendar.MONTH) + 1, 
                cal.get(Calendar.DAY_OF_MONTH));
        
        Random random = new Random();
        String randomPart = String.format("%06d", random.nextInt(1000000));
        
        return "CL-" + datePart + "-" + randomPart;
    }
    
    /**
     * Initialize sample claims for demonstration
     */
    private void initializeSampleClaims() {
        // Sample claim 1
        Claim claim1 = new Claim(
            "CL-20250510-123456",
            "Water damage to living room ceiling",
            "Approved",
            5000.00,
            "USR001",
            "John Doe",
            "POL-HO-567890"
        );
        claim1.setFilingDate(new Date());
        claimStore.put(claim1.getClaimNumber(), claim1);
        
        // Sample claim 2
        Claim claim2 = new Claim(
            "CL-20250505-789012",
            "Auto accident - front bumper damage",
            "Under Review",
            2750.50,
            "USR002",
            "Jane Smith",
            "POL-AU-123456"
        );
        claim2.setFilingDate(new Date());
        claimStore.put(claim2.getClaimNumber(), claim2);
        
        // Sample claim 3
        Claim claim3 = new Claim(
            "CL-20250428-345678",
            "Theft of personal property from home",
            "Pending Documentation",
            1200.00,
            "USR003",
            "Robert Johnson",
            "POL-HO-234567"
        );
        claim3.setFilingDate(new Date());
        claimStore.put(claim3.getClaimNumber(), claim3);
    }
}
