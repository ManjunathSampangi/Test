package com.googleauth.mulesoft.controller;

import com.googleauth.mulesoft.model.User;
import com.googleauth.mulesoft.service.TOTPService;
import com.googleauth.mulesoft.service.UserService;
import com.googleauth.mulesoft.service.MockAuthenticatorService;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.Map;
import java.util.Optional;

/**
 * REST controller for direct connection between authenticator components
 * This controller facilitates the proof-of-concept flow by creating simpler integration points
 */
@RestController
@RequestMapping("/api/direct-connect")
public class DirectConnectController {

    private final UserService userService;
    private final TOTPService totpService; // Used for future enhancements
    private final MockAuthenticatorService mockAuthenticatorService;

    @Autowired
    public DirectConnectController(UserService userService, TOTPService totpService, 
                                  MockAuthenticatorService mockAuthenticatorService) {
        this.userService = userService;
        this.totpService = totpService;
        this.mockAuthenticatorService = mockAuthenticatorService;
    }

    /**
     * Get the current secret key for a user
     * This simplifies integration by exposing the raw secret key directly
     */
    @GetMapping("/get-secret/{userId}")
    public ResponseEntity<Map<String, Object>> getSecret(@PathVariable String userId) {
        try {
            Optional<User> userOpt = userService.findById(userId);
            if (userOpt.isPresent()) {
                User user = userOpt.get();
                if (user.getTotpSecret() != null) {
                    Map<String, Object> responseData = new HashMap<>();
                    responseData.put("secretKey", user.getTotpSecret());
                    return ResponseEntity.ok(createSuccessResponse("Secret key retrieved", responseData));
                } else {
                    return ResponseEntity.badRequest().body(createErrorResponse("User has no secret key yet"));
                }
            } else {
                return ResponseEntity.badRequest().body(createErrorResponse("User not found"));
            }
        } catch (Exception e) {
            return ResponseEntity.badRequest().body(createErrorResponse("Error getting secret: " + e.getMessage()));
        }
    }

    /**
     * Initialize the mock authenticator with the user's secret key directly
     * This simplifies the demo flow by connecting components automatically
     */
    @PostMapping("/connect-mock/{userId}")
    public ResponseEntity<Map<String, Object>> connectMockAuthenticator(@PathVariable String userId) {
        try {
            Optional<User> userOpt = userService.findById(userId);
            if (userOpt.isPresent()) {
                User user = userOpt.get();
                if (user.getTotpSecret() != null) {
                    // Store the secret key in the mock authenticator
                    mockAuthenticatorService.storeUserSecret(userId, user.getTotpSecret());
                    
                    // Generate a code to verify it works
                    String currentCode = mockAuthenticatorService.generateCurrentCode(userId);
                    int secondsRemaining = mockAuthenticatorService.getSecondsRemaining();
                    
                    Map<String, Object> responseData = new HashMap<>();
                    responseData.put("code", currentCode);
                    responseData.put("secondsRemaining", secondsRemaining);
                    responseData.put("connected", true);
                    
                    return ResponseEntity.ok(createSuccessResponse(
                        "Mock authenticator connected successfully", responseData));
                } else {
                    return ResponseEntity.badRequest().body(createErrorResponse("User has no secret key yet"));
                }
            } else {
                return ResponseEntity.badRequest().body(createErrorResponse("User not found"));
            }
        } catch (Exception e) {
            return ResponseEntity.badRequest().body(createErrorResponse(
                "Error connecting mock authenticator: " + e.getMessage()));
        }
    }

    /**
     * Create a success response
     */
    private Map<String, Object> createSuccessResponse(String message, Map<String, Object> data) {
        Map<String, Object> response = new HashMap<>();
        response.put("success", true);
        response.put("message", message);
        
        if (data != null) {
            response.put("data", data);
        }
        
        return response;
    }

    /**
     * Create an error response
     */
    private Map<String, Object> createErrorResponse(String message) {
        Map<String, Object> response = new HashMap<>();
        response.put("success", false);
        response.put("message", message);
        return response;
    }
}
