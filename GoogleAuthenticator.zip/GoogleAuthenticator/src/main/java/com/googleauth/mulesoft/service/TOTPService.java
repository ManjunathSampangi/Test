package com.googleauth.mulesoft.service;

import com.googleauth.mulesoft.model.User;
import com.warrenstrange.googleauth.GoogleAuthenticator;
import com.warrenstrange.googleauth.GoogleAuthenticatorConfig;
import com.warrenstrange.googleauth.GoogleAuthenticatorKey;

import org.springframework.stereotype.Service;

import java.util.List;
import java.util.concurrent.TimeUnit;
import java.util.stream.Collectors;
import java.util.stream.IntStream;
import java.security.SecureRandom;

/**
 * Service to handle TOTP (Time-based One-Time Password) operations for Google Authenticator
 * Implements RFC 6238 TOTP algorithm
 */
@Service
public class TOTPService {

    private final GoogleAuthenticator gAuth;
    private static final int RECOVERY_CODE_COUNT = 10;
    private static final int RECOVERY_CODE_LENGTH = 10;
    private static final int WINDOW_SIZE = 1; // Allow 1 interval before/after for clock skew
    
    public TOTPService() {
        // Configure Google Authenticator with 30 second time window
        GoogleAuthenticatorConfig config = new GoogleAuthenticatorConfig.GoogleAuthenticatorConfigBuilder()
                .setTimeStepSizeInMillis(TimeUnit.SECONDS.toMillis(30))
                .setWindowSize(WINDOW_SIZE)
                .setCodeDigits(6) // 6-digit codes as per specification
                .build();
        this.gAuth = new GoogleAuthenticator(config);
    }
    
    /**
     * Generates a new secret key for TOTP
     * @return GoogleAuthenticatorKey containing the generated secret
     */
    public GoogleAuthenticatorKey generateSecretKey() {
        return gAuth.createCredentials();
    }
    
    /**
     * Generates recovery codes for account backup
     * @return List of recovery codes
     */
    public List<String> generateRecoveryCodes() {
        SecureRandom random = new SecureRandom();
        String chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
        
        return IntStream.range(0, RECOVERY_CODE_COUNT)
                .mapToObj(i -> IntStream.range(0, RECOVERY_CODE_LENGTH)
                        .mapToObj(j -> Character.toString(chars.charAt(random.nextInt(chars.length()))))
                        .collect(Collectors.joining()))
                .collect(Collectors.toList());
    }
    
    /**
     * Validates a TOTP code against a user's secret
     * @param user The user whose TOTP code is being validated
     * @param code The 6-digit code to validate
     * @return true if the code is valid, false otherwise
     */
    public boolean validateTOTP(User user, String code) {
        // Only check if user and secret are present, don't check if 2FA is enabled
        // This allows initial setup validation to work
        if (user == null || user.getTotpSecret() == null) {
            return false;
        }
        
        try {
            int codeInt = Integer.parseInt(code);
            
            // Use a more lenient time window for validation (handles time drift between devices)
            return gAuth.authorize(user.getTotpSecret(), codeInt);
        } catch (NumberFormatException e) {
            // Code was not an integer
            return false;
        }
    }
    
    /**
     * Validates a recovery code for a user
     * @param user The user whose recovery code is being validated
     * @param recoveryCode The recovery code to validate
     * @return true if the code is valid and has been consumed, false otherwise
     */
    public boolean validateRecoveryCode(User user, String recoveryCode) {
        if (user == null || !user.isTwoFactorEnabled()) {
            return false;
        }
        
        return user.useRecoveryCode(recoveryCode);
    }
    
    /**
     * Generates a QR code URL for Google Authenticator setup
     * @param user The user for whom to generate the QR code
     * @param appName The name of the application
     * @return The URL for the QR code
     */
    public String generateQRCodeURL(User user, String appName) {
        if (user == null || user.getTotpSecret() == null) {
            throw new IllegalArgumentException("User or TOTP secret is null");
        }
        
        // Instead of using the library's method, create a properly formatted URI manually
        // This follows the otpauth:// URI format expected by Google Authenticator
        String issuer = appName.replaceAll("\\s", "");
        String account = user.getUsername();
        String secret = user.getTotpSecret();
        
        // Format: otpauth://totp/[Issuer]:[Account]?secret=[Secret]&issuer=[Issuer]&algorithm=SHA1&digits=6&period=30
        return String.format(
            "otpauth://totp/%s:%s?secret=%s&issuer=%s&algorithm=SHA1&digits=6&period=30",
            issuer,
            account,
            secret,
            issuer
        );
    }
    
    /**
     * Generates a current TOTP code for a given secret - useful for testing
     * @param secret The secret key
     * @return The current TOTP code
     */
    public int generateCurrentTOTP(String secret) {
        return gAuth.getTotpPassword(secret);
    }
}
