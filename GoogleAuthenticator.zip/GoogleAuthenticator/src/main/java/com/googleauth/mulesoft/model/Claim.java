package com.googleauth.mulesoft.model;

import java.util.Date;

/**
 * Model class representing a claim in the system.
 */
public class Claim {
    private String claimNumber;
    private String description;
    private Date filingDate;
    private String status;
    private Double amount;
    private String claimantId;
    private String claimantName;
    private String policyNumber;
    private Date createdAt;
    private Date updatedAt;
    
    public Claim() {
        this.createdAt = new Date();
        this.updatedAt = new Date();
    }
    
    public Claim(String claimNumber, String description, String status, Double amount, 
                String claimantId, String claimantName, String policyNumber) {
        this.claimNumber = claimNumber;
        this.description = description;
        this.filingDate = new Date();
        this.status = status;
        this.amount = amount;
        this.claimantId = claimantId;
        this.claimantName = claimantName;
        this.policyNumber = policyNumber;
        this.createdAt = new Date();
        this.updatedAt = new Date();
    }
    
    // Getters and Setters
    public String getClaimNumber() {
        return claimNumber;
    }
    
    public void setClaimNumber(String claimNumber) {
        this.claimNumber = claimNumber;
    }
    
    public String getDescription() {
        return description;
    }
    
    public void setDescription(String description) {
        this.description = description;
    }
    
    public Date getFilingDate() {
        return filingDate;
    }
    
    public void setFilingDate(Date filingDate) {
        this.filingDate = filingDate;
    }
    
    public String getStatus() {
        return status;
    }
    
    public void setStatus(String status) {
        this.status = status;
    }
    
    public Double getAmount() {
        return amount;
    }
    
    public void setAmount(Double amount) {
        this.amount = amount;
    }
    
    public String getClaimantId() {
        return claimantId;
    }
    
    public void setClaimantId(String claimantId) {
        this.claimantId = claimantId;
    }
    
    public String getClaimantName() {
        return claimantName;
    }
    
    public void setClaimantName(String claimantName) {
        this.claimantName = claimantName;
    }
    
    public String getPolicyNumber() {
        return policyNumber;
    }
    
    public void setPolicyNumber(String policyNumber) {
        this.policyNumber = policyNumber;
    }
    
    public Date getCreatedAt() {
        return createdAt;
    }
    
    public void setCreatedAt(Date createdAt) {
        this.createdAt = createdAt;
    }
    
    public Date getUpdatedAt() {
        return updatedAt;
    }
    
    public void setUpdatedAt(Date updatedAt) {
        this.updatedAt = updatedAt;
    }
}
