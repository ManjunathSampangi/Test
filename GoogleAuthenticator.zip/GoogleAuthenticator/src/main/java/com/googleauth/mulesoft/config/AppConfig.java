package com.googleauth.mulesoft.config;

import com.googleauth.mulesoft.service.TOTPService;
import com.googleauth.mulesoft.service.QRCodeService;
import com.googleauth.mulesoft.service.UserService;
import com.googleauth.mulesoft.service.MockAuthenticatorService;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;

@Configuration
public class AppConfig {

    @Bean
    public TOTPService totpService() {
        return new TOTPService();
    }
    
    @Bean
    public QRCodeService qrCodeService() {
        return new QRCodeService();
    }
    
    @Bean
    public UserService userService(TOTPService totpService) {
        return new UserService(totpService);
    }
    
    @Bean
    public MockAuthenticatorService mockAuthenticatorService() {
        return new MockAuthenticatorService();
    }
    
    @Bean
    public BCryptPasswordEncoder passwordEncoder() {
        return new BCryptPasswordEncoder();
    }
}
