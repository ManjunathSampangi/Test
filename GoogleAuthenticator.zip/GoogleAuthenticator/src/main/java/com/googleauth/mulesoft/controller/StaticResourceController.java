package com.googleauth.mulesoft.controller;

import com.googleauth.mulesoft.service.StaticResourceService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import java.io.IOException;

/**
 * Controller for serving static resources
 */
@Controller
@RequestMapping("/api/static")
public class StaticResourceController {

    private final StaticResourceService staticResourceService;

    @Autowired
    public StaticResourceController(StaticResourceService staticResourceService) {
        this.staticResourceService = staticResourceService;
    }

    /**
     * Serve JavaScript files
     */
    @GetMapping(value = "/js/{filename:.+}", produces = MediaType.APPLICATION_JSON_VALUE)
    @ResponseBody
    public ResponseEntity<String> serveJavaScript(@PathVariable String filename) {
        try {
            String content = staticResourceService.getStaticResource("js/" + filename);
            return ResponseEntity.ok()
                    .contentType(MediaType.parseMediaType("application/javascript"))
                    .body(content);
        } catch (IOException e) {
            return ResponseEntity.notFound().build();
        }
    }

    /**
     * Serve CSS files
     */
    @GetMapping(value = "/css/{filename:.+}", produces = MediaType.TEXT_PLAIN_VALUE)
    @ResponseBody
    public ResponseEntity<String> serveCSS(@PathVariable String filename) {
        try {
            String content = staticResourceService.getStaticResource("css/" + filename);
            return ResponseEntity.ok()
                    .contentType(MediaType.parseMediaType("text/css"))
                    .body(content);
        } catch (IOException e) {
            return ResponseEntity.notFound().build();
        }
    }

    /**
     * Serve HTML files
     */
    @GetMapping(value = "/{filename:.+\\.html}", produces = MediaType.TEXT_HTML_VALUE)
    @ResponseBody
    public ResponseEntity<String> serveHTML(@PathVariable String filename) {
        try {
            String content = staticResourceService.getStaticResource(filename);
            return ResponseEntity.ok().body(content);
        } catch (IOException e) {
            return ResponseEntity.notFound().build();
        }
    }
}
