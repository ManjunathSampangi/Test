package com.googleauth.mulesoft.service;

import com.google.zxing.BarcodeFormat;
import com.google.zxing.EncodeHintType;
import com.google.zxing.WriterException;
import com.google.zxing.client.j2se.MatrixToImageWriter;
import com.google.zxing.common.BitMatrix;
import com.google.zxing.qrcode.QRCodeWriter;
import com.google.zxing.qrcode.decoder.ErrorCorrectionLevel;

import org.springframework.stereotype.Service;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.util.Base64;
import java.util.EnumMap;
import java.util.Map;

/**
 * Service for generating QR codes for Google Authenticator setup
 */
@Service
public class QRCodeService {
    
    private static final int QR_CODE_SIZE = 250;
    
    /**
     * Generates a QR code image for the provided TOTP URI
     * @param totpUri The URI to encode in the QR code
     * @return Base64 encoded string of the QR code image
     * @throws WriterException If encoding fails
     * @throws IOException If writing to output stream fails
     */
    public String generateQRCodeImage(String totpUri) throws WriterException, IOException {
        QRCodeWriter qrCodeWriter = new QRCodeWriter();
        
        Map<EncodeHintType, Object> hints = new EnumMap<>(EncodeHintType.class);
        hints.put(EncodeHintType.ERROR_CORRECTION, ErrorCorrectionLevel.M);
        hints.put(EncodeHintType.MARGIN, 1);
        hints.put(EncodeHintType.CHARACTER_SET, "UTF-8");
        
        BitMatrix bitMatrix = qrCodeWriter.encode(totpUri, BarcodeFormat.QR_CODE, QR_CODE_SIZE, QR_CODE_SIZE, hints);
        
        ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
        MatrixToImageWriter.writeToStream(bitMatrix, "PNG", outputStream);
        
        byte[] imageBytes = outputStream.toByteArray();
        return Base64.getEncoder().encodeToString(imageBytes);
    }
    
    /**
     * Generates an HTML img tag with the QR code embedded as a data URI
     * @param totpUri The URI to encode in the QR code
     * @return HTML img tag with embedded QR code
     * @throws WriterException If encoding fails
     * @throws IOException If writing to output stream fails
     */
    public String generateQRCodeImageTag(String totpUri) throws WriterException, IOException {
        String base64Image = generateQRCodeImage(totpUri);
        return "<img src=\"data:image/png;base64," + base64Image + "\" alt=\"QR Code\" />";
    }
    
    /**
     * Generates a data URI for the QR code image
     * @param totpUri The URI to encode in the QR code
     * @return Data URI containing the QR code image
     * @throws WriterException If encoding fails
     * @throws IOException If writing to output stream fails
     */
    public String generateQRCodeDataUri(String totpUri) throws WriterException, IOException {
        String base64Image = generateQRCodeImage(totpUri);
        return "data:image/png;base64," + base64Image;
    }
}
