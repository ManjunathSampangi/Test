package com.googleauth.mulesoft.controller;

import com.googleauth.mulesoft.model.User;
import com.googleauth.mulesoft.service.TOTPService;
import com.googleauth.mulesoft.service.QRCodeService;
import com.googleauth.mulesoft.service.UserService;
import com.warrenstrange.googleauth.GoogleAuthenticatorKey;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.Map;
import java.util.Optional;

/**
 * REST controller for handling authentication endpoints
 */
@RestController
@RequestMapping("/api/auth")
public class AuthRestController {

    private final UserService userService;
    private final TOTPService totpService;
    private final QRCodeService qrCodeService;

    @Autowired
    public AuthRestController(UserService userService, TOTPService totpService, QRCodeService qrCodeService) {
        this.userService = userService;
        this.totpService = totpService;
        this.qrCodeService = qrCodeService;
    }

    /**
     * Register a new user
     */
    @PostMapping("/register")
    public ResponseEntity<Map<String, Object>> register(@RequestBody Map<String, String> payload) {
        String username = payload.get("username");
        String password = payload.get("password");
        String email = payload.get("email");

        if (username == null || password == null || email == null) {
            return ResponseEntity.badRequest().body(createErrorResponse("Missing required fields: username, password, email"));
        }

        try {
            User user = userService.registerUser(username, password, email);
            return ResponseEntity.ok(createSuccessResponse("User registered successfully", Map.of("userId", user.getId())));
        } catch (Exception e) {
            return ResponseEntity.badRequest().body(createErrorResponse("Registration failed: " + e.getMessage()));
        }
    }

    /**
     * Login a user
     */
    @PostMapping("/login")
    public ResponseEntity<Map<String, Object>> login(@RequestBody Map<String, String> payload) {
        String username = payload.get("username");
        String password = payload.get("password");

        if (username == null || password == null) {
            return ResponseEntity.badRequest().body(createErrorResponse("Missing required fields: username, password"));
        }

        try {
            Optional<User> optionalUser = userService.authenticateUser(username, password);

            if (optionalUser.isPresent()) {
                User user = optionalUser.get();
                Map<String, Object> responseData = new HashMap<>();
                responseData.put("userId", user.getId());
                responseData.put("requires2FA", user.isTwoFactorEnabled());

                return ResponseEntity.ok(createSuccessResponse("Authentication successful", responseData));
            } else {
                return ResponseEntity.badRequest().body(createErrorResponse("Invalid username or password"));
            }
        } catch (Exception e) {
            return ResponseEntity.badRequest().body(createErrorResponse("Login failed: " + e.getMessage()));
        }
    }

    /**
     * Verify TOTP code
     */
    @PostMapping("/verify-totp")
    public ResponseEntity<Map<String, Object>> verifyTOTP(@RequestBody Map<String, String> payload) {
        String userId = payload.get("userId");
        String code = payload.get("code");

        if (userId == null || code == null) {
            return ResponseEntity.badRequest().body(createErrorResponse("Missing required fields: userId, code"));
        }

        try {
            boolean isValid = userService.validate2FACode(userId, code);

            if (isValid) {
                return ResponseEntity.ok(createSuccessResponse("TOTP verification successful", Map.of("verified", true)));
            } else {
                return ResponseEntity.badRequest().body(createErrorResponse("Invalid TOTP code"));
            }
        } catch (Exception e) {
            return ResponseEntity.badRequest().body(createErrorResponse("TOTP verification failed: " + e.getMessage()));
        }
    }

    /**
     * Verify recovery code
     */
    @PostMapping("/verify-recovery")
    public ResponseEntity<Map<String, Object>> verifyRecoveryCode(@RequestBody Map<String, String> payload) {
        String userId = payload.get("userId");
        String recoveryCode = payload.get("recoveryCode");

        if (userId == null || recoveryCode == null) {
            return ResponseEntity.badRequest().body(createErrorResponse("Missing required fields: userId, recoveryCode"));
        }

        try {
            boolean isValid = userService.validateRecoveryCode(userId, recoveryCode);

            if (isValid) {
                return ResponseEntity.ok(createSuccessResponse("Recovery code verification successful", Map.of("verified", true)));
            } else {
                return ResponseEntity.badRequest().body(createErrorResponse("Invalid recovery code"));
            }
        } catch (Exception e) {
            return ResponseEntity.badRequest().body(createErrorResponse("Recovery code verification failed: " + e.getMessage()));
        }
    }

    /**
     * Enable 2FA for a user
     */
    @PostMapping("/enable-2fa")
    public ResponseEntity<Map<String, Object>> enable2FA(@RequestBody Map<String, String> payload) {
        String userId = payload.get("userId");

        if (userId == null) {
            return ResponseEntity.badRequest().body(createErrorResponse("Missing required field: userId"));
        }

        try {
            // Generate TOTP secret and recovery codes
            GoogleAuthenticatorKey key = userService.enable2FA(userId);

            // Get user info for QR code generation
            User user = userService.findById(userId).orElseThrow();

            // Generate QR code URL
            String qrCodeUrl = totpService.generateQRCodeURL(user, "Google Auth Demo");

            // Generate QR code image as Base64
            String qrCodeBase64 = qrCodeService.generateQRCodeImage(qrCodeUrl);

            Map<String, Object> responseData = new HashMap<>();
            responseData.put("secret", key.getKey());
            responseData.put("qrCodeBase64", qrCodeBase64);
            responseData.put("recoveryCodes", user.getRecoveryCodes());

            return ResponseEntity.ok(createSuccessResponse("2FA setup initiated", responseData));
        } catch (Exception e) {
            return ResponseEntity.badRequest().body(createErrorResponse("2FA setup failed: " + e.getMessage()));
        }
    }

    /**
     * Verify and activate 2FA for a user
     */
    @PostMapping("/verify-2fa-setup")
    public ResponseEntity<Map<String, Object>> verify2FASetup(@RequestBody Map<String, String> payload) {
        String userId = payload.get("userId");
        String verificationCode = payload.get("verificationCode");

        if (userId == null || verificationCode == null) {
            return ResponseEntity.badRequest().body(createErrorResponse("Missing required fields: userId, verificationCode"));
        }

        try {
            boolean isVerified = userService.verify2FA(userId, verificationCode);

            if (isVerified) {
                return ResponseEntity.ok(createSuccessResponse("2FA has been enabled successfully", Map.of("enabled", true)));
            } else {
                return ResponseEntity.badRequest().body(createErrorResponse("Invalid verification code"));
            }
        } catch (Exception e) {
            return ResponseEntity.badRequest().body(createErrorResponse("2FA verification failed: " + e.getMessage()));
        }
    }

    /**
     * Disable 2FA for a user
     */
    @PostMapping("/disable-2fa")
    public ResponseEntity<Map<String, Object>> disable2FA(@RequestBody Map<String, String> payload) {
        String userId = payload.get("userId");

        if (userId == null) {
            return ResponseEntity.badRequest().body(createErrorResponse("Missing required field: userId"));
        }

        try {
            userService.disable2FA(userId);
            return ResponseEntity.ok(createSuccessResponse("2FA has been disabled successfully", Map.of("disabled", true)));
        } catch (Exception e) {
            return ResponseEntity.badRequest().body(createErrorResponse("Disabling 2FA failed: " + e.getMessage()));
        }
    }

    /**
     * Create a success response
     */
    private Map<String, Object> createSuccessResponse(String message, Map<String, Object> data) {
        Map<String, Object> response = new HashMap<>();
        response.put("success", true);
        response.put("message", message);
        
        if (data != null) {
            response.put("data", data);
        }
        
        return response;
    }

    /**
     * Create an error response
     */
    private Map<String, Object> createErrorResponse(String message) {
        Map<String, Object> response = new HashMap<>();
        response.put("success", false);
        response.put("message", message);
        return response;
    }
}
