package com.googleauth.mulesoft.service;

import com.googleauth.mulesoft.model.User;
import com.warrenstrange.googleauth.GoogleAuthenticatorKey;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.UUID;

/**
 * Service for managing user operations
 */
@Service
public class UserService {

    private final Map<String, User> userStore = new HashMap<>();
    private final BCryptPasswordEncoder passwordEncoder = new BCryptPasswordEncoder();
    private final TOTPService totpService;
    
    @Autowired
    public UserService(TOTPService totpService) {
        this.totpService = totpService;
    }
    
    /**
     * Registers a new user
     * @param username Username
     * @param password Plain text password
     * @param email Email address
     * @return The created user
     */
    public User registerUser(String username, String password, String email) {
        // Check if username already exists
        if (findByUsername(username).isPresent()) {
            throw new IllegalArgumentException("Username already exists");
        }
        
        // Create new user with hashed password
        User user = new User(username, passwordEncoder.encode(password), email);
        user.setId(UUID.randomUUID().toString());
        
        // Store user
        userStore.put(user.getId(), user);
        return user;
    }
    
    /**
     * Authenticates a user with username and password
     * @param username Username
     * @param password Plain text password
     * @return Optional containing the user if authenticated, empty otherwise
     */
    public Optional<User> authenticateUser(String username, String password) {
        return findByUsername(username)
                .filter(user -> passwordEncoder.matches(password, user.getPassword()));
    }
    
    /**
     * Finds a user by username
     * @param username Username to search for
     * @return Optional containing the user if found, empty otherwise
     */
    public Optional<User> findByUsername(String username) {
        return userStore.values().stream()
                .filter(user -> user.getUsername().equals(username))
                .findFirst();
    }
    
    /**
     * Finds a user by ID
     * @param id User ID
     * @return Optional containing the user if found, empty otherwise
     */
    public Optional<User> findById(String id) {
        return Optional.ofNullable(userStore.get(id));
    }
    
    /**
     * Enables 2FA for a user
     * @param userId User ID
     * @return GoogleAuthenticatorKey containing the secret key
     */
    public GoogleAuthenticatorKey enable2FA(String userId) {
        User user = findById(userId)
                .orElseThrow(() -> new IllegalArgumentException("User not found"));
        
        // Generate TOTP secret
        GoogleAuthenticatorKey key = totpService.generateSecretKey();
        user.setTotpSecret(key.getKey());
        
        // Generate recovery codes
        List<String> recoveryCodes = totpService.generateRecoveryCodes();
        user.setRecoveryCodes(recoveryCodes);
        
        // Mark 2FA as not yet verified (will be enabled after verification)
        user.setTwoFactorEnabled(false);
        
        return key;
    }
    
    /**
     * Verifies and activates 2FA for a user
     * @param userId User ID
     * @param verificationCode The verification code to validate
     * @return true if verification succeeded, false otherwise
     */
    public boolean verify2FA(String userId, String verificationCode) {
        User user = findById(userId)
                .orElseThrow(() -> new IllegalArgumentException("User not found"));
        
        // Validate the verification code
        if (totpService.validateTOTP(user, verificationCode)) {
            // Enable 2FA
            user.setTwoFactorEnabled(true);
            return true;
        }
        
        return false;
    }
    
    /**
     * Disables 2FA for a user
     * @param userId User ID
     */
    public void disable2FA(String userId) {
        User user = findById(userId)
                .orElseThrow(() -> new IllegalArgumentException("User not found"));
        
        user.setTwoFactorEnabled(false);
        user.setTotpSecret(null);
        user.setRecoveryCodes(null);
    }
    
    /**
     * Validates a 2FA code for a user
     * @param userId User ID
     * @param code The TOTP code to validate
     * @return true if the code is valid, false otherwise
     */
    public boolean validate2FACode(String userId, String code) {
        User user = findById(userId)
                .orElseThrow(() -> new IllegalArgumentException("User not found"));
        
        return totpService.validateTOTP(user, code);
    }
    
    /**
     * Validates a recovery code for a user
     * @param userId User ID
     * @param recoveryCode The recovery code to validate
     * @return true if the code is valid, false otherwise
     */
    public boolean validateRecoveryCode(String userId, String recoveryCode) {
        User user = findById(userId)
                .orElseThrow(() -> new IllegalArgumentException("User not found"));
        
        return totpService.validateRecoveryCode(user, recoveryCode);
    }
    
    /**
     * Updates a user's details
     * @param user The user with updated information
     * @return The updated user
     */
    public User updateUser(User user) {
        if (!userStore.containsKey(user.getId())) {
            throw new IllegalArgumentException("User not found");
        }
        
        userStore.put(user.getId(), user);
        return user;
    }
}
