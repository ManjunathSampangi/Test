package com.googleauth.mulesoft.service;

import com.googleauth.mulesoft.model.User;
import com.warrenstrange.googleauth.GoogleAuthenticatorKey;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;

import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.Random;
import java.util.UUID;

/**
 * Service for managing user operations
 */
@Service
public class UserService {

    private final Map<String, User> userStore = new HashMap<>();
    private final BCryptPasswordEncoder passwordEncoder = new BCryptPasswordEncoder();
    private final TOTPService totpService;
    
    @Autowired
    public UserService(TOTPService totpService) {
        this.totpService = totpService;
    }
    
    /**
     * Registers a new user
     * @param username Username
     * @param password Plain text password
     * @param email Email address
     * @return The created user
     */
    public User registerUser(String username, String password, String email) {
        // Check if username already exists
        if (findByUsername(username).isPresent()) {
            throw new IllegalArgumentException("Username already exists");
        }
        
        // Create new user with hashed password
        User user = new User(username, passwordEncoder.encode(password), email);
        user.setId(UUID.randomUUID().toString());
        
        // Store user
        userStore.put(user.getId(), user);
        return user;
    }
    
    /**
     * Authenticates a user with username and password
     * @param username Username
     * @param password Plain text password
     * @return Optional containing the user if authenticated, empty otherwise
     */
    public Optional<User> authenticateUser(String username, String password) {
        return findByUsername(username)
                .filter(user -> passwordEncoder.matches(password, user.getPassword()));
    }
    
    /**
     * Finds a user by username
     * @param username Username to search for
     * @return Optional containing the user if found, empty otherwise
     */
    public Optional<User> findByUsername(String username) {
        return userStore.values().stream()
                .filter(user -> user.getUsername().equals(username))
                .findFirst();
    }
    
    /**
     * Finds a user by ID
     * @param id User ID
     * @return Optional containing the user if found, empty otherwise
     */
    public Optional<User> findById(String id) {
        return Optional.ofNullable(userStore.get(id));
    }
    
    /**
     * Enables 2FA for a user
     * @param userId User ID
     * @return GoogleAuthenticatorKey containing the secret key
     */
    public GoogleAuthenticatorKey enable2FA(String userId) {
        User user = findById(userId)
                .orElseThrow(() -> new IllegalArgumentException("User not found"));
        
        // Generate TOTP secret
        GoogleAuthenticatorKey key = totpService.generateSecretKey();
        user.setTotpSecret(key.getKey());
        
        // Generate recovery codes
        List<String> recoveryCodes = totpService.generateRecoveryCodes();
        user.setRecoveryCodes(recoveryCodes);
        
        // Mark 2FA as not yet verified (will be enabled after verification)
        user.setTwoFactorEnabled(false);
        
        return key;
    }
    
    /**
     * Verifies and activates 2FA for a user
     * @param userId User ID
     * @param verificationCode The verification code to validate
     * @return true if verification succeeded, false otherwise
     */
    public boolean verify2FA(String userId, String verificationCode) {
        User user = findById(userId)
                .orElseThrow(() -> new IllegalArgumentException("User not found"));
        
        // Validate the verification code
        if (totpService.validateTOTP(user, verificationCode)) {
            // Enable 2FA
            user.setTwoFactorEnabled(true);
            return true;
        }
        
        return false;
    }
    
    /**
     * Disables 2FA for a user
     * @param userId User ID
     */
    public void disable2FA(String userId) {
        User user = findById(userId)
                .orElseThrow(() -> new IllegalArgumentException("User not found"));
        
        user.setTwoFactorEnabled(false);
        user.setTotpSecret(null);
        user.setRecoveryCodes(null);
    }
    
    /**
     * Validates a 2FA code for a user
     * @param userId User ID
     * @param code The TOTP code to validate
     * @return true if the code is valid, false otherwise
     */
    public boolean validate2FACode(String userId, String code) {
        User user = findById(userId)
                .orElseThrow(() -> new IllegalArgumentException("User not found"));
        
        return totpService.validateTOTP(user, code);
    }
    
    /**
     * Validates a recovery code for a user
     * @param userId User ID
     * @param recoveryCode The recovery code to validate
     * @return true if the code is valid, false otherwise
     */
    public boolean validateRecoveryCode(String userId, String recoveryCode) {
        User user = findById(userId)
                .orElseThrow(() -> new IllegalArgumentException("User not found"));
        
        return user.useRecoveryCode(recoveryCode);
    }
    
    /**
     * Class to hold user and temp password result
     */
    public static class RegistrationResult {
        private User user;
        private String tempPassword;
        
        public RegistrationResult(User user, String tempPassword) {
            this.user = user;
            this.tempPassword = tempPassword;
        }
        
        public User getUser() {
            return user;
        }
        
        public String getTempPassword() {
            return tempPassword;
        }
    }
    
    /**
     * Register a user with policy information
     * @param policyNumber Policy number
     * @param firstName First name
     * @param lastName Last name
     * @param dateOfBirth Date of birth
     * @param email Email address
     * @return RegistrationResult containing the user and temporary password
     */
    public RegistrationResult registerWithPolicy(String policyNumber, String firstName, String lastName, 
                                  Date dateOfBirth, String email) {
        // Create username from policy number
        String username = policyNumber;
        
        // Check if username/policy already exists
        if (findByUsername(username).isPresent()) {
            throw new IllegalArgumentException("Policy number already registered");
        }
        
        // Generate temporary password
        String tempPassword = generateTemporaryPassword();
        
        // Create user with encrypted temporary password
        User user = new User(username, passwordEncoder.encode(tempPassword), email);
        user.setId(UUID.randomUUID().toString());
        user.setPolicyNumber(policyNumber);
        user.setFirstName(firstName);
        user.setLastName(lastName);
        user.setDateOfBirth(dateOfBirth);
        user.setTempPassword(true);
        
        // Set password expiry (24 hours from now)
        Calendar expiry = Calendar.getInstance();
        expiry.add(Calendar.HOUR, 24);
        user.setPasswordExpiryDate(expiry.getTime());
        
        // Store user
        userStore.put(user.getId(), user);
        
        // Print OKTA registration details to console instead of sending email
        System.out.println("\n\n==================== OKTA REGISTRATION DETAILS ====================\n");
        System.out.println("   Username: " + username);
        System.out.println("   Email: " + email);
        System.out.println("   Temporary Password: " + tempPassword);
        System.out.println("\n================================================================\n\n");
        
        return new RegistrationResult(user, tempPassword);
    }
    
    /**
     * Generate a temporary password
     * @return Random temporary password
     */
    private String generateTemporaryPassword() {
        // Generate a random 8-character password
        String chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";
        StringBuilder sb = new StringBuilder();
        Random random = new Random();
        for (int i = 0; i < 8; i++) {
            sb.append(chars.charAt(random.nextInt(chars.length())));
        }
        return sb.toString();
    }
    
    /**
     * Reset a user's password
     * @param userId User ID
     * @return Temporary password
     */
    public String resetPassword(String userId) {
        User user = findById(userId)
                .orElseThrow(() -> new IllegalArgumentException("User not found"));
        
        String tempPassword = generateTemporaryPassword();
        user.setPassword(passwordEncoder.encode(tempPassword));
        user.setTempPassword(true);
        
        // Set password expiry (24 hours from now)
        Calendar expiry = Calendar.getInstance();
        expiry.add(Calendar.HOUR, 24);
        user.setPasswordExpiryDate(expiry.getTime());
        
        return tempPassword;
    }
    
    /**
     * Change password from temporary to permanent
     * @param userId User ID
     * @param newPassword New password
     */
    public void changePassword(String userId, String newPassword) {
        User user = findById(userId)
                .orElseThrow(() -> new IllegalArgumentException("User not found"));
        
        user.setPassword(passwordEncoder.encode(newPassword));
        user.setTempPassword(false);
        user.setPasswordExpiryDate(null);
    }
    
    /**
     * Find a user by policy number
     * @param policyNumber Policy number to search for
     * @return Optional containing the user if found, empty otherwise
     */
    public Optional<User> findByPolicyNumber(String policyNumber) {
        return userStore.values().stream()
                .filter(user -> policyNumber.equals(user.getPolicyNumber()))
                .findFirst();
    }
    
    /**
     * Generate and send email OTP
     * @param email User's email
     * @return The generated OTP
     */
    public String generateEmailOTP(String email) {
        Optional<User> optUser = userStore.values().stream()
                .filter(u -> email.equals(u.getEmail()))
                .findFirst();
        
        if (optUser.isEmpty()) {
            throw new IllegalArgumentException("No user found with this email");
        }
        
        User user = optUser.get();
        
        // For testing purposes, use a fixed OTP that's easy to remember
        // In a real application, this would be randomly generated
        String otp = "123456";
        
        // Store OTP with user
        user.setEmailOtp(otp);
        
        // Set OTP expiry (30 minutes from now for easier testing)
        Calendar expiry = Calendar.getInstance();
        expiry.add(Calendar.MINUTE, 30);
        user.setOtpExpiryTime(expiry.getTime());
        
        // Print a very visible message to console
        System.out.println("\n\n==================== TESTING OTP CODE ====================\n");
        System.out.println("   OTP: " + otp + " (for email: " + email + ")");
        System.out.println("   VALID UNTIL: " + expiry.getTime());
        System.out.println("\n===========================================================\n\n");
        
        // In a real application, we would send the OTP via email here
        // For this demo, we'll just return it
        
        return otp;
    }
    
    /**
     * Verify email OTP
     * @param email User's email
     * @param otp OTP to verify
     * @return true if OTP is valid, false otherwise
     */
    public boolean verifyEmailOTP(String email, String otp) {
        Optional<User> optUser = userStore.values().stream()
                .filter(u -> email.equals(u.getEmail()))
                .findFirst();
        
        if (optUser.isEmpty()) {
            return false;
        }
        
        User user = optUser.get();
        
        // Check if OTP exists and hasn't expired
        if (user.getEmailOtp() != null && user.getOtpExpiryTime() != null) {
            if (user.getEmailOtp().equals(otp) && new Date().before(user.getOtpExpiryTime())) {
                // Clear OTP after successful verification
                user.setEmailOtp(null);
                user.setOtpExpiryTime(null);
                return true;
            }
        }
        
        return false;
    }
    
    /**
     * Updates a user's details
     * @param user The user with updated information
     * @return The updated user
     */
    public User updateUser(User user) {
        if (!userStore.containsKey(user.getId())) {
            throw new IllegalArgumentException("User not found");
        }
        
        userStore.put(user.getId(), user);
        return user;
    }
    
    /**
     * Registers a user for claim access (simplified registration for MFA)
     * @param policyNumber Policy number
     * @param firstName First name
     * @param lastName Last name
     * @param email Email address
     * @return The registered user
     */
    public User registerClaimUser(String policyNumber, String firstName, String lastName, String email) {
        // Check if policy is already registered
        if (findByUsername(policyNumber).isPresent()) {
            throw new IllegalArgumentException("Policy number already registered");
        }
        
        // Generate a random password - user won't need this as they'll use MFA
        String randomPassword = generateTemporaryPassword();
        
        // Create new user with policy as username and additional fields
        User user = new User(policyNumber, passwordEncoder.encode(randomPassword), email);
        user.setId(UUID.randomUUID().toString());
        user.setPolicyNumber(policyNumber);
        user.setFirstName(firstName);
        user.setLastName(lastName);
        
        // Store user
        userStore.put(user.getId(), user);
        
        System.out.println("Claim user registered for policy number: " + policyNumber);
        return user;
    }
}
