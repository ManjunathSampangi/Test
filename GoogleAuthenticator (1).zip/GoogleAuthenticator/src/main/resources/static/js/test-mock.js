/**
 * Test script for demonstrating mock authenticator integration
 */
document.addEventListener('DOMContentLoaded', function() {
    // Add a test button to the page for quick demonstration
    const testContainer = document.createElement('div');
    testContainer.className = 'test-container';
    testContainer.innerHTML = `
        <div class="test-panel">
            <h3>Google Authenticator Mock Demo</h3>
            <p>This panel helps demonstrate the complete 2FA flow using the mock authenticator.</p>
            <div class="test-buttons">
                <button id="demo-register">1. Register Demo User</button>
                <button id="demo-login">2. Login Demo User</button>
                <button id="demo-enable-2fa">3. Enable 2FA</button>
                <button id="demo-show-mock">4. Show Mock Authenticator</button>
                <button id="demo-verify-setup">5. Verify & Complete Setup</button>
                <button id="demo-logout">6. Logout</button>
                <button id="demo-login-with-2fa">7. Login with 2FA</button>
            </div>
        </div>
    `;
    
    document.body.appendChild(testContainer);
    
    // Add styles for the test panel
    const style = document.createElement('style');
    style.textContent = `
        .test-container {
            position: fixed;
            top: 10px;
            right: 10px;
            z-index: 1000;
        }
        
        .test-panel {
            background-color: #f8f9fa;
            border: 1px solid #ddd;
            border-radius: 4px;
            padding: 15px;
            width: 300px;
            box-shadow: 0 2px 5px rgba(0,0,0,0.1);
        }
        
        .test-panel h3 {
            margin-top: 0;
            color: #4285F4;
        }
        
        .test-buttons {
            display: flex;
            flex-direction: column;
            gap: 8px;
        }
        
        .test-buttons button {
            padding: 8px;
            background-color: #4285F4;
            color: white;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            text-align: left;
        }
        
        .test-buttons button:hover {
            background-color: #3367D6;
        }
    `;
    document.head.appendChild(style);
    
    // Demo user credentials
    const demoUser = {
        username: 'demouser',
        password: 'Password123',
        email: 'demo@example.com',
        userId: null
    };
    
    // Event handlers for demonstration
    document.getElementById('demo-register').addEventListener('click', function() {
        // Simulate registration
        fetch('/api/auth/register', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
                username: demoUser.username,
                password: demoUser.password,
                email: demoUser.email
            })
        })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                demoUser.userId = data.data.userId;
                alert('Demo user registered successfully! User ID: ' + demoUser.userId);
            } else {
                alert('Registration failed: ' + data.message);
            }
        })
        .catch(err => {
            console.error('Registration error:', err);
            alert('Registration error. Check console for details.');
        });
    });
    
    document.getElementById('demo-login').addEventListener('click', function() {
        // Simulate login
        fetch('/api/auth/login', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
                username: demoUser.username,
                password: demoUser.password
            })
        })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                demoUser.userId = data.data.userId;
                sessionStorage.setItem('auth_user_id', demoUser.userId);
                sessionStorage.setItem('auth_username', demoUser.username);
                sessionStorage.setItem('auth_2fa_enabled', data.data.requires2FA ? 'true' : 'false');
                
                alert('Demo user logged in! 2FA Enabled: ' + data.data.requires2FA);
            } else {
                alert('Login failed: ' + data.message);
            }
        })
        .catch(err => {
            console.error('Login error:', err);
            alert('Login error. Check console for details.');
        });
    });
    
    document.getElementById('demo-enable-2fa').addEventListener('click', function() {
        // Enable 2FA
        const userId = sessionStorage.getItem('auth_user_id');
        if (!userId) {
            alert('Please login first');
            return;
        }
        
        fetch('/api/auth/enable-2fa', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ userId })
        })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                // Store secret in mock authenticator
                fetch('/api/mock/store-secret', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({
                        userId: userId,
                        secretKey: data.data.secret
                    })
                });
                
                alert('2FA setup initiated! Secret: ' + data.data.secret);
                
                // Display QR code
                const qrImage = document.createElement('img');
                qrImage.src = 'data:image/png;base64,' + data.data.qrCodeBase64;
                qrImage.style.width = '200px';
                qrImage.style.height = '200px';
                qrImage.style.display = 'block';
                qrImage.style.margin = '10px auto';
                
                const qrContainer = document.createElement('div');
                qrContainer.appendChild(qrImage);
                qrContainer.innerHTML += '<p style="text-align:center">Scan this QR code with Google Authenticator</p>';
                
                document.querySelector('.test-panel').appendChild(qrContainer);
            } else {
                alert('2FA setup failed: ' + data.message);
            }
        })
        .catch(err => {
            console.error('2FA setup error:', err);
            alert('2FA setup error. Check console for details.');
        });
    });
    
    document.getElementById('demo-show-mock').addEventListener('click', function() {
        // Show mock authenticator
        if (typeof MockAuth !== 'undefined') {
            MockAuth.showAuthenticator();
        } else {
            alert('Mock authenticator not initialized. Please ensure mockAuth.js is loaded.');
        }
    });
    
    document.getElementById('demo-verify-setup').addEventListener('click', function() {
        // Verify 2FA setup
        const userId = sessionStorage.getItem('auth_user_id');
        if (!userId) {
            alert('Please login first');
            return;
        }
        
        // Get code from mock authenticator
        fetch('/api/mock/generate-code', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ userId })
        })
        .then(response => response.json())
        .then(mockData => {
            if (mockData.success) {
                const code = mockData.data.code;
                
                // Verify setup
                fetch('/api/auth/verify-2fa-setup', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({
                        userId: userId,
                        verificationCode: code
                    })
                })
                .then(response => response.json())
                .then(data => {
                    if (data.success) {
                        sessionStorage.setItem('auth_2fa_enabled', 'true');
                        alert('2FA verified and enabled successfully!');
                    } else {
                        alert('2FA verification failed: ' + data.message);
                    }
                });
            } else {
                alert('Failed to generate code: ' + mockData.message);
            }
        })
        .catch(err => {
            console.error('Verification error:', err);
            alert('Verification error. Check console for details.');
        });
    });
    
    document.getElementById('demo-logout').addEventListener('click', function() {
        // Logout
        sessionStorage.removeItem('auth_user_id');
        sessionStorage.removeItem('auth_username');
        sessionStorage.removeItem('auth_2fa_enabled');
        alert('Logged out successfully');
    });
    
    document.getElementById('demo-login-with-2fa').addEventListener('click', function() {
        // Login with 2FA verification
        fetch('/api/auth/login', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
                username: demoUser.username,
                password: demoUser.password
            })
        })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                demoUser.userId = data.data.userId;
                
                if (data.data.requires2FA) {
                    // Get code from mock authenticator
                    fetch('/api/mock/generate-code', {
                        method: 'POST',
                        headers: { 'Content-Type': 'application/json' },
                        body: JSON.stringify({ userId: demoUser.userId })
                    })
                    .then(response => response.json())
                    .then(mockData => {
                        if (mockData.success) {
                            const code = mockData.data.code;
                            
                            // Verify TOTP
                            fetch('/api/auth/verify-totp', {
                                method: 'POST',
                                headers: { 'Content-Type': 'application/json' },
                                body: JSON.stringify({
                                    userId: demoUser.userId,
                                    code: code
                                })
                            })
                            .then(response => response.json())
                            .then(verifyData => {
                                if (verifyData.success) {
                                    sessionStorage.setItem('auth_user_id', demoUser.userId);
                                    sessionStorage.setItem('auth_username', demoUser.username);
                                    sessionStorage.setItem('auth_2fa_enabled', 'true');
                                    alert('Logged in with 2FA verification!');
                                } else {
                                    alert('2FA verification failed: ' + verifyData.message);
                                }
                            });
                        }
                    });
                } else {
                    alert('2FA is not enabled for this user');
                }
            } else {
                alert('Login failed: ' + data.message);
            }
        })
        .catch(err => {
            console.error('Login error:', err);
            alert('Login error. Check console for details.');
        });
    });
});
