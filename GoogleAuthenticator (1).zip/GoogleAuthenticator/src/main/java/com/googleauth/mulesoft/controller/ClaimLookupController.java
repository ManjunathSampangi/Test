package com.googleauth.mulesoft.controller;

import com.googleauth.mulesoft.model.Claim;
import com.googleauth.mulesoft.model.User;
import com.googleauth.mulesoft.service.ClaimService;
import com.googleauth.mulesoft.service.UserService;
import com.googleauth.mulesoft.service.TOTPService;
import com.warrenstrange.googleauth.GoogleAuthenticatorKey;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import java.util.Optional;

/**
 * Controller for claim lookup web interface
 */
@Controller
public class ClaimLookupController {

    private final ClaimService claimService;
    private final UserService userService;
    private final TOTPService totpService;

    @Autowired
    public ClaimLookupController(ClaimService claimService, UserService userService, TOTPService totpService) {
        this.claimService = claimService;
        this.userService = userService;
        this.totpService = totpService;
    }

    /**
     * Show claim lookup form
     */
    @GetMapping("/claim-lookup")
    public String showClaimLookupForm() {
        return "claim-lookup";
    }

    /**
     * Process claim lookup request - initial verification
     */
    @PostMapping("/claim-lookup")
    public String processClaim(@RequestParam String claimNumber, Model model) {
        Optional<Claim> claimOpt = claimService.findByClaimNumber(claimNumber);
        
        if (claimOpt.isPresent()) {
            Claim claim = claimOpt.get();
            // Store claim in session attribute for retrieval after MFA verification
            model.addAttribute("claimNumber", claimNumber);
            model.addAttribute("policyNumber", claim.getPolicyNumber());
            
            // Check if user exists with this policy number
            Optional<User> userOpt = userService.findByUsername(claim.getPolicyNumber());
            
            if (userOpt.isPresent()) {
                User user = userOpt.get();
                
                // Check if user has Google Authenticator enabled
                if (user.isTwoFactorEnabled() && user.getTotpSecret() != null) {
                    // Use Google Authenticator
                    model.addAttribute("userId", user.getId());
                    model.addAttribute("claimNumber", claimNumber);
                    model.addAttribute("useGoogleAuth", true);
                    model.addAttribute("message", "Please enter the code from your Google Authenticator app");
                    return "verify-claim-otp";
                } else {
                    // User exists but doesn't have Google Auth, use email OTP
                    String otp = userService.generateEmailOTP(user.getEmail());
                    // In a real app, send email. For testing, log to console
                    System.out.println("\n\n===================================================================");
                    System.out.println("OTP CODE FOR VERIFICATION: " + otp);
                    System.out.println("TO EMAIL: " + user.getEmail());
                    System.out.println("==================================================================\n\n");
                    
                    model.addAttribute("email", user.getEmail());
                    model.addAttribute("claimNumber", claimNumber);
                    model.addAttribute("message", "Please enter the OTP sent to your email to verify your identity");
                    return "verify-claim-otp";
                }
            } else {
                // User not registered, ask to register for MFA
                model.addAttribute("message", "You need to register for multi-factor authentication to access claim details");
                model.addAttribute("claimantName", claim.getClaimantName());
                return "register-for-claim";
            }
        } else {
            model.addAttribute("error", "Claim not found. Please check the claim number and try again.");
            return "claim-lookup";
        }
    }
    
    /**
     * Verify OTP for claim access
     */
    @PostMapping("/verify-claim-otp")
    public String verifyClaimOTP(
            @RequestParam(required = false) String email,
            @RequestParam String otp,
            @RequestParam String claimNumber,
            @RequestParam(required = false) String userId,
            @RequestParam(required = false, defaultValue = "false") boolean useGoogleAuth,
            Model model) {
        
        boolean isValid = false;
        
        if (useGoogleAuth && userId != null) {
            // Verify using Google Authenticator
            Optional<User> userOpt = userService.findById(userId);
            if (userOpt.isPresent()) {
                User user = userOpt.get();
                isValid = totpService.validateTOTP(user, otp);
            }
        } else if (email != null) {
            // Verify using email OTP
            isValid = userService.verifyEmailOTP(email, otp);
        }
        
        if (isValid) {
            // OTP verified, show claim details
            Optional<Claim> claimOpt = claimService.findByClaimNumber(claimNumber);
            if (claimOpt.isPresent()) {
                Claim claim = claimOpt.get();
                model.addAttribute("claim", claim);
                return "claim-details";
            } else {
                model.addAttribute("error", "Claim not found");
                return "claim-lookup";
            }
        } else {
            model.addAttribute("error", "Invalid or expired code");
            if (email != null) {
                model.addAttribute("email", email);
            }
            if (userId != null) {
                model.addAttribute("userId", userId);
                model.addAttribute("useGoogleAuth", true);
            }
            model.addAttribute("claimNumber", claimNumber);
            return "verify-claim-otp";
        }
    }
    
    /**
     * Register for MFA to access claims
     */
    @PostMapping("/register-for-claim")
    public String registerForClaim(@RequestParam String policyNumber,
                                @RequestParam String firstName,
                                @RequestParam String lastName,
                                @RequestParam String email,
                                @RequestParam String claimNumber,
                                Model model) {
        try {
            // Create user with the provided details and set up Google Authenticator if needed
            User user = userService.registerClaimUser(policyNumber, firstName, lastName, email);
            
            // Option to set up Google Authenticator
            if (totpService.isGoogleAuthenticatorAvailable()) {
                // For demo purposes, offering Google Auth setup when appropriate
                GoogleAuthenticatorKey key = totpService.generateSecretKey();
                user.setTotpSecret(key.getKey());
                System.out.println("\n\n===================================================================");
                System.out.println("GOOGLE AUTHENTICATOR SECRET KEY: " + key.getKey());
                System.out.println("TO EMAIL: " + email);
                System.out.println("==================================================================\n\n");
                model.addAttribute("secretKey", key.getKey());
                model.addAttribute("setupGoogleAuth", true);
            }
            
            // Generate and send OTP
            String otp = userService.generateEmailOTP(email);
            System.out.println("\n\n===================================================================");
            System.out.println("OTP CODE FOR NEW CLAIM USER: " + otp);
            System.out.println("TO EMAIL: " + email);
            System.out.println("==================================================================\n\n");
            
            model.addAttribute("email", email);
            model.addAttribute("claimNumber", claimNumber);
            model.addAttribute("message", "Please enter the OTP sent to your email to verify your identity");
            return "verify-claim-otp";
        } catch (Exception e) {
            model.addAttribute("error", e.getMessage());
            model.addAttribute("claimNumber", claimNumber);
            return "register-for-claim";
        }
    }
}
