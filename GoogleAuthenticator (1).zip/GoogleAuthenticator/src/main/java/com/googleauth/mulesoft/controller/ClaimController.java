package com.googleauth.mulesoft.controller;

import com.googleauth.mulesoft.model.Claim;
import com.googleauth.mulesoft.model.User;
import com.googleauth.mulesoft.service.ClaimService;
import com.googleauth.mulesoft.service.UserService;
import com.googleauth.mulesoft.service.TOTPService;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.Map;
import java.util.Optional;

/**
 * REST controller for claim operations with authentication checks
 */
@RestController
@RequestMapping("/api/claims")
public class ClaimController {

    private final ClaimService claimService;
    private final UserService userService;
    private final TOTPService totpService;

    @Autowired
    public ClaimController(ClaimService claimService, UserService userService, TOTPService totpService) {
        this.claimService = claimService;
        this.userService = userService;
        this.totpService = totpService;
    }

    /**
     * Lookup a claim by claim number
     * This endpoint doesn't require authentication yet, just checks if the claim exists
     */
    @GetMapping("/lookup/{claimNumber}")
    public ResponseEntity<Map<String, Object>> lookupClaim(@PathVariable String claimNumber) {
        Optional<Claim> claimOpt = claimService.findByClaimNumber(claimNumber);
        
        if (claimOpt.isPresent()) {
            Map<String, Object> responseData = new HashMap<>();
            responseData.put("exists", true);
            responseData.put("claimNumber", claimNumber);
            return ResponseEntity.ok(createSuccessResponse("Claim found", responseData));
        } else {
            return ResponseEntity.ok(createErrorResponse("Claim not found"));
        }
    }

    /**
     * Get details of a claim after authenticating the user
     */
    @PostMapping("/details")
    public ResponseEntity<Map<String, Object>> getClaimDetails(
            @RequestBody Map<String, String> request) {
        
        String claimNumber = request.get("claimNumber");
        String userId = request.get("userId");
        String code = request.get("code");
        
        // Validate parameters
        if (claimNumber == null || userId == null) {
            return ResponseEntity.badRequest().body(createErrorResponse("Missing required parameters"));
        }
        
        // First check if claim exists
        Optional<Claim> claimOpt = claimService.findByClaimNumber(claimNumber);
        if (!claimOpt.isPresent()) {
            return ResponseEntity.badRequest().body(createErrorResponse("Claim not found"));
        }
        
        // Find the user
        Optional<User> userOpt = userService.findById(userId);
        if (!userOpt.isPresent()) {
            return ResponseEntity.badRequest().body(createErrorResponse("User not found"));
        }
        
        User user = userOpt.get();
        
        // Check if user has 2FA enabled and verify the code if needed
        if (user.isTwoFactorEnabled()) {
            // If code is null, we need to request 2FA verification
            if (code == null) {
                Map<String, Object> responseData = new HashMap<>();
                responseData.put("requires2FA", true);
                responseData.put("userId", userId);
                return ResponseEntity.ok(createSuccessResponse("2FA verification required", responseData));
            }
            
            // Verify provided 2FA code
            boolean isValid = totpService.validateTOTP(user, code);
            if (!isValid) {
                return ResponseEntity.badRequest().body(createErrorResponse("Invalid authentication code"));
            }
        }
        
        // If we get here, user is properly authenticated
        Claim claim = claimOpt.get();
        
        // Return the claim details
        Map<String, Object> responseData = new HashMap<>();
        responseData.put("claimNumber", claim.getClaimNumber());
        responseData.put("description", claim.getDescription());
        responseData.put("filingDate", claim.getFilingDate());
        responseData.put("status", claim.getStatus());
        responseData.put("amount", claim.getAmount());
        responseData.put("claimantName", claim.getClaimantName());
        responseData.put("policyNumber", claim.getPolicyNumber());
        
        return ResponseEntity.ok(createSuccessResponse("Claim details retrieved successfully", responseData));
    }

    /**
     * Create a success response
     */
    private Map<String, Object> createSuccessResponse(String message, Map<String, Object> data) {
        Map<String, Object> response = new HashMap<>();
        response.put("success", true);
        response.put("message", message);
        
        if (data != null) {
            response.put("data", data);
        }
        
        return response;
    }

    /**
     * Create an error response
     */
    private Map<String, Object> createErrorResponse(String message) {
        Map<String, Object> response = new HashMap<>();
        response.put("success", false);
        response.put("message", message);
        return response;
    }
}
