package com.googleauth.mulesoft;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.ComponentScan;

/**
 * Main application class for Google Authenticator POC with Mock Authenticator
 * Demonstrates end-to-end two-factor authentication flow
 */
@SpringBootApplication
@ComponentScan(basePackages = {"com.googleauth.mulesoft"})
public class GoogleAuthenticatorApplication {

    public static void main(String[] args) {
        SpringApplication.run(GoogleAuthenticatorApplication.class, args);
        System.out.println("\n\n===========================================================");
        System.out.println("Google Authenticator with Mock Authenticator POC is running");
        System.out.println("Access the web interface at: http://localhost:8084");
        System.out.println("==========================================================\n");
    }
}
