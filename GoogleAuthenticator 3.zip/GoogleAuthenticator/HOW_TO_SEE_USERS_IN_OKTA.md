# How to See Users in Okta Dashboard

## Why You Can't See Your Registered Users

The `/okta-registration` endpoint is a **DEMO** that creates users locally, not in Okta.

```
Demo Registration → Local Memory → NOT visible in Okta Dashboard
Real Okta → Okta Directory → Visible in Okta Dashboard
```

## Where to Check for Real Okta Users

1. **Login to Okta Admin Console**
   - URL: https://aig-trial-7695213.okta.com/admin
   - Use your admin credentials

2. **Navigate to Users**
   - Go to: **Directory** → **People**
   - You'll see all users created in Okta

3. **What You'll See**
   - Users created through Okta's registration
   - Users created via Okta API
   - Users imported from other systems
   - **NOT** users from demo registration

## How to Create Users That Show in Okta

### Option 1: Manual Creation
1. In Okta Admin: **Directory** → **People** → **Add Person**
2. Fill in user details
3. User immediately visible in dashboard

### Option 2: Use Real Okta Integration
```bash
# Set API Token
export OKTA_API_TOKEN="00abcd..."  # Get from Security → API → Tokens

# Run with Okta profile
java -jar -Dspring.profiles.active=okta target/googleauth-demo-1.0-SNAPSHOT.jar
```

Then the OktaApiService can create real users.

### Option 3: Okta Self-Service Registration
1. Enable self-service registration in Okta
2. Users register through Okta's page
3. Automatically appear in dashboard

## Quick Check: Are My Users in Okta?

### Demo Users (Local)
- Created at: `/okta-registration`
- Stored in: Application memory
- Visible in: Console logs only
- In Okta Dashboard: ❌ NO

### Real Okta Users
- Created through: Okta login/API
- Stored in: Okta Universal Directory
- Visible in: Okta Admin Console
- In Okta Dashboard: ✅ YES

## To Test Real User Creation

1. Get API Token from Okta
2. Set environment variable
3. Modify OktaController to use OktaApiService
4. Users will then appear in Okta Dashboard

Remember: The current demo is designed to show the flow without requiring Okta setup! 