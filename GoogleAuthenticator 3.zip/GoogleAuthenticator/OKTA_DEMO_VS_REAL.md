# OKTA Demo Mode vs Real OKTA Integration

## Current Setup (Demo Mode)

What you're seeing at `/okta-registration` is a **demo/simulation** that:
- Creates users locally in the application
- Generates OTPs locally
- Simulates the OKTA flow without actually using OKTA

**Why?** This allows testing the user flow without needing OKTA credentials.

## Real OKTA Integration

In a real OKTA integration, users would:

1. **Never see a local registration form**
2. **Be redirected to OKTA's login page** (https://aig-trial-7695213.okta.com)
3. **Authenticate directly with OKTA**
4. **Set up MFA through OKTA's interface**

## How to Use Real OKTA

### Option 1: Quick Test (Current Application)
```bash
# Just click "Use Real OKTA Login" button on the registration page
# Or go directly to: http://localhost:8084/okta-login
```

### Option 2: Full OKTA Mode
```bash
# Set your OKTA API token
export OKTA_API_TOKEN="your-token-here"

# Run with OKTA profile
java -jar -Dspring.profiles.active=okta target/googleauth-demo-1.0-SNAPSHOT.jar

# Now /okta-login will redirect to real OKTA
```

## What Happens in Each Mode

### Demo Mode (Default)
```
User → Local Registration Form → Local OTP → Local Auth → Claims Page
```

### Real OKTA Mode
```
User → Redirect to OKTA → OKTA Login → OKTA MFA → Return to App → Claims Page
```

## Key Differences

| Feature | Demo Mode | Real OKTA |
|---------|-----------|-----------|
| User Creation | Local (in-memory) | OKTA Directory |
| Authentication | Local password check | OKTA SSO |
| MFA Setup | Local Google Auth | OKTA MFA Policies |
| Email OTP | Console output | Real email from OKTA |
| Session Management | Local | OKTA Session |
| User Directory | Application | OKTA Universal Directory |

## Why Not Always Use Real OKTA?

1. **Development/Testing**: Easier to test without OKTA setup
2. **Demo Purposes**: Show the flow without OKTA account
3. **API Limits**: Avoid hitting OKTA API rate limits during development
4. **Offline Development**: Work without internet/OKTA access

## For Production

Always use real OKTA integration for:
- Enterprise SSO
- Centralized user management
- Real MFA enforcement
- Compliance requirements
- Audit trails 