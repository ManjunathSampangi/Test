# Real Okta MFA Integration Guide

## Prerequisites

1. **Okta Developer Account**: You already have a sandbox at `aig-trial-7695213.okta.com`
2. **API Token**: You need to create an API token in your Okta Admin Console

## Step 1: Create Okta API Token

1. Log in to your Okta Admin Console: https://aig-trial-7695213.okta.com/admin
2. Navigate to **Security** → **API** → **Tokens**
3. Click **Create Token**
4. Give it a name like "Google Auth POC"
5. Copy the token value (you won't see it again!)

## Step 2: Set Environment Variable

```bash
export OKTA_API_TOKEN="your-token-here"
```

Or add it to your `.env` file:
```
OKTA_API_TOKEN=your-token-here
```

## Step 3: Enable Okta MFA Features

1. In Okta Admin Console, go to **Security** → **Multifactor**
2. Enable these factors:
   - **Google Authenticator**
   - **Email Authentication**
3. Set up an enrollment policy if needed

## Step 4: Update Application Configuration

The application now has `OktaApiService` that can:
- Create users in Okta
- Send real email OTPs through Okta
- Enroll users in Google Authenticator
- Get real TOTP codes from Okta
- Verify TOTP codes through Okta

## Step 5: Test the Real Okta Flow

1. Start the application with Okta profile:
   ```bash
   export OKTA_API_TOKEN="your-token-here"
   java -jar -Dspring.profiles.active=okta target/googleauth-demo-1.0-SNAPSHOT.jar
   ```

2. Go to http://localhost:8084/okta-registration

3. Register a new user - this will:
   - Create a real user in Okta
   - Send a real email OTP from Okta (check your email!)
   - Set up real Google Authenticator through Okta

## How It Works

### Email OTP Flow
1. User registers → Creates user in Okta
2. Okta sends real email with OTP code
3. User enters OTP → Verified by Okta API

### Google Authenticator Flow
1. After email verification → Enrolls Google Authenticator in Okta
2. Okta provides QR code
3. User scans with Google Authenticator app
4. User enters TOTP code → Verified by Okta API

## API Endpoints Used

- Create User: `POST /api/v1/users`
- Enroll Factor: `POST /api/v1/users/{userId}/factors`
- Verify Factor: `POST /api/v1/users/{userId}/factors/{factorId}/verify`
- Activate Factor: `POST /api/v1/users/{userId}/factors/{factorId}/lifecycle/activate`

## Troubleshooting

1. **401 Unauthorized**: Check your API token
2. **404 Not Found**: Check the org URL is correct
3. **400 Bad Request**: User might already exist in Okta

## Benefits of Real Okta Integration

1. **Real Email Delivery**: Okta sends actual emails
2. **Real TOTP**: Uses Okta's TOTP implementation
3. **Audit Trail**: All MFA events logged in Okta
4. **Production Ready**: Same flow works in production
5. **Policy Control**: Use Okta policies for MFA rules 