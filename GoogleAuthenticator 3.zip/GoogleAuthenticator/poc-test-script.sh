#!/bin/bash

# OKTA Integration with Google Authenticator - POC Test Script
# Tests all key endpoints to verify the application is working

GREEN="\033[0;32m"
BLUE="\033[0;34m"
RED="\033[0;31m"
NC="\033[0m" # No Color

echo -e "${BLUE}🚀 OKTA + Google Authenticator POC - Endpoint Tests${NC}"
echo "=================================================================="

# Test 1: Application Health
echo -e "${BLUE}Test 1: Application Health Check${NC}"
response=$(curl -s -o /dev/null -w "%{http_code}" http://localhost:8084)
if [ "$response" = "302" ]; then
    echo -e "${GREEN}✅ Application is running (HTTP $response)${NC}"
else
    echo -e "${RED}❌ Application health check failed (HTTP $response)${NC}"
fi
echo

# Test 2: OKTA Registration Page
echo -e "${BLUE}Test 2: OKTA Registration Page${NC}"
response=$(curl -s -o /dev/null -w "%{http_code}" http://localhost:8084/okta-registration)
if [ "$response" = "200" ]; then
    echo -e "${GREEN}✅ OKTA Registration page accessible (HTTP $response)${NC}"
else
    echo -e "${RED}❌ OKTA Registration page failed (HTTP $response)${NC}"
fi
echo

# Test 3: Login Page
echo -e "${BLUE}Test 3: Login Page${NC}"
response=$(curl -s -o /dev/null -w "%{http_code}" http://localhost:8084/login)
if [ "$response" = "200" ]; then
    echo -e "${GREEN}✅ Login page accessible (HTTP $response)${NC}"
else
    echo -e "${RED}❌ Login page failed (HTTP $response)${NC}"
fi
echo

# Test 4: Mock Authenticator API
echo -e "${BLUE}Test 4: Mock Authenticator API${NC}"
response=$(curl -s http://localhost:8084/api/mock/time-remaining)
if echo "$response" | grep -q "success.*true"; then
    seconds=$(echo "$response" | grep -o '"secondsRemaining":[0-9]*' | cut -d':' -f2)
    echo -e "${GREEN}✅ Mock Authenticator API working${NC}"
    echo -e "   Time remaining: ${seconds} seconds until next TOTP code"
else
    echo -e "${RED}❌ Mock Authenticator API failed${NC}"
fi
echo

# Test 5: Static Resources
echo -e "${BLUE}Test 5: Static Resources${NC}"
response=$(curl -s -o /dev/null -w "%{http_code}" http://localhost:8084/css/style.css)
if [ "$response" = "200" ]; then
    echo -e "${GREEN}✅ Static resources accessible (HTTP $response)${NC}"
else
    echo -e "${GREEN}ℹ️  Static resources may not be available (HTTP $response)${NC}"
fi
echo

echo "=================================================================="
echo -e "${GREEN}🎉 POC Testing Complete!${NC}"
echo
echo -e "${BLUE}📋 Ready for demonstration:${NC}"
echo "   • OKTA Registration: http://localhost:8084/okta-registration"
echo "   • Login Portal: http://localhost:8084/login" 
echo "   • Application Root: http://localhost:8084"
echo
echo -e "${BLUE}Demo Credentials (after registration):${NC}"
echo "   • Policy Number: POL123456789"
echo "   • Email: demo.user@company.com"
echo "   • Check console for auto-generated password"
echo
echo -e "${BLUE}🔧 Mock Authenticator for Testing:${NC}"
echo "   • No mobile app required"
echo "   • TOTP codes displayed in console"
echo "   • API: http://localhost:8084/api/mock/time-remaining" 