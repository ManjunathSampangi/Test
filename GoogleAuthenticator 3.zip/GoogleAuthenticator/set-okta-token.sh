#!/bin/bash

# Replace YOUR_TOKEN_HERE with your actual Okta API token
export OKTA_API_TOKEN="YOUR_TOKEN_HERE"

echo "✅ OKTA_API_TOKEN has been set!"
echo ""
echo "Now run: ./start-with-okta.sh" 