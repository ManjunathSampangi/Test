/**
 * Authentication Module
 * Handles user registration, login, and verification flows
 */
const Auth = (function() {
    // API Endpoints
    const API_BASE = '/api/auth';
    const ENDPOINTS = {
        REGISTER: `${API_BASE}/register`,
        LOGIN: `${API_BASE}/login`,
        VERIFY_TOTP: `${API_BASE}/verify-totp`,
        VERIFY_RECOVERY: `${API_BASE}/verify-recovery`
    };
    
    // DOM Elements
    const loginForm = document.getElementById('login');
    const registerForm = document.getElementById('register');
    const totpVerificationForm = document.getElementById('verify-totp');
    const recoveryVerificationForm = document.getElementById('verify-recovery');
    const showRegisterLink = document.getElementById('show-register');
    const showLoginLink = document.getElementById('show-login');
    const useRecoveryLink = document.getElementById('use-recovery-code');
    const useTotpLink = document.getElementById('use-totp-code');
    
    // Form containers
    const loginFormContainer = document.getElementById('login-form');
    const registerFormContainer = document.getElementById('register-form');
    const totpVerificationContainer = document.getElementById('totp-verification');
    const recoveryVerificationContainer = document.getElementById('recovery-verification');
    
    // Session Storage Keys
    const STORAGE_KEYS = {
        USER_ID: 'auth_user_id',
        USERNAME: 'auth_username',
        IS_2FA_ENABLED: 'auth_2fa_enabled'
    };
    
    /**
     * Initialize the authentication module
     */
    function init() {
        // Attach event listeners
        loginForm.addEventListener('submit', handleLogin);
        registerForm.addEventListener('submit', handleRegister);
        totpVerificationForm.addEventListener('submit', handleTotpVerification);
        recoveryVerificationForm.addEventListener('submit', handleRecoveryVerification);
        
        // Form toggling
        showRegisterLink.addEventListener('click', showRegisterForm);
        showLoginLink.addEventListener('click', showLoginForm);
        useRecoveryLink.addEventListener('click', showRecoveryVerification);
        useTotpLink.addEventListener('click', showTotpVerification);
        
        // Check if user is already logged in
        checkLoginStatus();
    }
    
    /**
     * Check if user is already logged in
     */
    function checkLoginStatus() {
        const userId = sessionStorage.getItem(STORAGE_KEYS.USER_ID);
        if (userId) {
            // User is logged in, show dashboard
            App.showDashboard();
        }
    }
    
    /**
     * Handle login form submission
     * @param {Event} e - Form submit event
     */
    async function handleLogin(e) {
        e.preventDefault();
        
        const username = document.getElementById('login-username').value;
        const password = document.getElementById('login-password').value;
        
        try {
            const response = await fetch(ENDPOINTS.LOGIN, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({ username, password })
            });
            
            const result = await response.json();
            
            if (result.success) {
                const { userId, requires2FA } = result.data;
                
                // Store userId for 2FA verification if needed
                sessionStorage.setItem(STORAGE_KEYS.USER_ID, userId);
                sessionStorage.setItem(STORAGE_KEYS.USERNAME, username);
                
                if (requires2FA) {
                    // User has 2FA enabled, show verification form
                    document.getElementById('totp-user-id').value = userId;
                    document.getElementById('recovery-user-id').value = userId;
                    showTotpVerification();
                } else {
                    // User doesn't have 2FA, proceed to dashboard
                    sessionStorage.setItem(STORAGE_KEYS.IS_2FA_ENABLED, 'false');
                    App.showNotification('Login successful', 'success');
                    App.showDashboard();
                }
            } else {
                App.showNotification(result.message || 'Login failed', 'error');
            }
        } catch (error) {
            console.error('Login error:', error);
            App.showNotification('An error occurred during login. Please try again.', 'error');
        }
    }
    
    /**
     * Handle register form submission
     * @param {Event} e - Form submit event
     */
    async function handleRegister(e) {
        e.preventDefault();
        
        const username = document.getElementById('register-username').value;
        const email = document.getElementById('register-email').value;
        const password = document.getElementById('register-password').value;
        
        try {
            const response = await fetch(ENDPOINTS.REGISTER, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({ username, email, password })
            });
            
            const result = await response.json();
            
            if (result.success) {
                App.showNotification('Registration successful! You can now log in.', 'success');
                showLoginForm();
                loginForm.reset();
                document.getElementById('login-username').value = username;
            } else {
                App.showNotification(result.message || 'Registration failed', 'error');
            }
        } catch (error) {
            console.error('Registration error:', error);
            App.showNotification('An error occurred during registration. Please try again.', 'error');
        }
    }
    
    /**
     * Handle TOTP verification form submission
     * @param {Event} e - Form submit event
     */
    async function handleTotpVerification(e) {
        e.preventDefault();
        
        const userId = document.getElementById('totp-user-id').value;
        const code = document.getElementById('totp-code').value;
        
        try {
            const response = await fetch(ENDPOINTS.VERIFY_TOTP, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({ userId, code })
            });
            
            const result = await response.json();
            
            if (result.success) {
                sessionStorage.setItem(STORAGE_KEYS.IS_2FA_ENABLED, 'true');
                App.showNotification('Verification successful', 'success');
                App.showDashboard();
            } else {
                App.showNotification(result.message || 'Invalid verification code', 'error');
            }
        } catch (error) {
            console.error('TOTP verification error:', error);
            App.showNotification('An error occurred during verification. Please try again.', 'error');
        }
    }
    
    /**
     * Handle recovery code verification form submission
     * @param {Event} e - Form submit event
     */
    async function handleRecoveryVerification(e) {
        e.preventDefault();
        
        const userId = document.getElementById('recovery-user-id').value;
        const recoveryCode = document.getElementById('recovery-code').value;
        
        try {
            const response = await fetch(ENDPOINTS.VERIFY_RECOVERY, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({ userId, recoveryCode })
            });
            
            const result = await response.json();
            
            if (result.success) {
                sessionStorage.setItem(STORAGE_KEYS.IS_2FA_ENABLED, 'true');
                App.showNotification('Recovery code verification successful', 'success');
                App.showDashboard();
            } else {
                App.showNotification(result.message || 'Invalid recovery code', 'error');
            }
        } catch (error) {
            console.error('Recovery verification error:', error);
            App.showNotification('An error occurred during verification. Please try again.', 'error');
        }
    }
    
    /**
     * Show the login form
     */
    function showLoginForm() {
        loginFormContainer.classList.remove('hidden');
        registerFormContainer.classList.add('hidden');
        totpVerificationContainer.classList.add('hidden');
        recoveryVerificationContainer.classList.add('hidden');
    }
    
    /**
     * Show the register form
     */
    function showRegisterForm() {
        loginFormContainer.classList.add('hidden');
        registerFormContainer.classList.remove('hidden');
        totpVerificationContainer.classList.add('hidden');
        recoveryVerificationContainer.classList.add('hidden');
    }
    
    /**
     * Show the TOTP verification form
     */
    function showTotpVerification() {
        loginFormContainer.classList.add('hidden');
        registerFormContainer.classList.add('hidden');
        totpVerificationContainer.classList.remove('hidden');
        recoveryVerificationContainer.classList.add('hidden');
    }
    
    /**
     * Show the recovery code verification form
     */
    function showRecoveryVerification() {
        loginFormContainer.classList.add('hidden');
        registerFormContainer.classList.add('hidden');
        totpVerificationContainer.classList.add('hidden');
        recoveryVerificationContainer.classList.remove('hidden');
    }
    
    /**
     * Log out the current user
     */
    function logout() {
        // Clear session storage
        Object.values(STORAGE_KEYS).forEach(key => {
            sessionStorage.removeItem(key);
        });
        
        // Reset forms
        loginForm.reset();
        registerForm.reset();
        totpVerificationForm.reset();
        recoveryVerificationForm.reset();
        
        // Show login form
        showLoginForm();
        
        // Hide dashboard
        App.hideAllContainers();
        loginFormContainer.classList.remove('hidden');
        
        App.showNotification('You have been logged out', 'success');
    }
    
    // Public API
    return {
        init,
        logout,
        showLoginForm,
        STORAGE_KEYS
    };
})();
