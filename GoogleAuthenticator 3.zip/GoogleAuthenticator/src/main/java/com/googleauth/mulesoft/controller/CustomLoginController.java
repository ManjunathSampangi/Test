package com.googleauth.mulesoft.controller;

import com.googleauth.mulesoft.model.User;
import com.googleauth.mulesoft.service.UserService;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import java.util.Optional;

/**
 * Controller for handling custom login
 */
@Controller
public class CustomLoginController {

    private final UserService userService;

    @Autowired
    public CustomLoginController(UserService userService) {
        this.userService = userService;
    }

    /**
     * Show login page
     */
    @GetMapping("/custom-login")
    public String showLoginPage() {
        return "login";
    }
    
    /**
     * Show login page with mfaEnabled parameter
     */
    @GetMapping("/auth-login")
    public String showLoginPage(@RequestParam(value = "mfaEnabled", required = false) Boolean mfaEnabled,
                               Model model) {
        if (Boolean.TRUE.equals(mfaEnabled)) {
            model.addAttribute("message", "Google Authenticator has been successfully set up. Please log in with your credentials.");
        }
        return "login";
    }

    /**
     * Handle login
     */
    @PostMapping("/login")
    public String login(@RequestParam String username, 
                      @RequestParam String password,
                      Model model,
                      RedirectAttributes redirectAttributes) {
        try {
            Optional<User> userOpt = userService.authenticateUser(username, password);
            
            if (userOpt.isPresent()) {
                User user = userOpt.get();
                
                // Check if user needs to change temporary password
                if (user.isTempPassword()) {
                    return "redirect:/change-temp-password?username=" + username;
                }
                
                // Check if 2FA is enabled
                if (user.isTwoFactorEnabled()) {
                    return "redirect:/verify-totp?userId=" + user.getId();
                }
                
                // If this is an Okta user without 2FA yet, redirect to set up Google Auth
                if (user.getPolicyNumber() != null && user.getTotpSecret() == null) {
                    // This is likely an Okta user that hasn't set up 2FA yet
                    return "redirect:/setup-google-auth?userId=" + user.getId();
                }
                
                // Successful login without 2FA, redirect to home
                redirectAttributes.addFlashAttribute("message", "Login successful");
                return "redirect:/";
            } else {
                model.addAttribute("error", "Invalid username or password");
                return "login";
            }
        } catch (Exception e) {
            model.addAttribute("error", e.getMessage());
            return "login";
        }
    }
    
    /**
     * Handle password change
     */
    @GetMapping("/change-temp-password")
    public String showChangePasswordPage(@RequestParam String username, Model model) {
        model.addAttribute("username", username);
        return "change-password";
    }
    
    /**
     * Process password change
     */
    @PostMapping("/process-password-change")
    public String processChangePassword(@RequestParam String username,
                                      @RequestParam String password,
                                      @RequestParam String confirmPassword,
                                      Model model) {
        if (!password.equals(confirmPassword)) {
            model.addAttribute("error", "Passwords do not match");
            model.addAttribute("username", username);
            return "change-password";
        }
        
        try {
            Optional<User> userOpt = userService.findByUsername(username);
            
            if (userOpt.isEmpty()) {
                model.addAttribute("error", "User not found");
                return "change-password";
            }
            
            User user = userOpt.get();
            userService.changePassword(user.getId(), password);
            
            // Redirect to Google Authenticator setup after password change
            return "redirect:/setup-google-auth?userId=" + user.getId();
        } catch (Exception e) {
            model.addAttribute("error", e.getMessage());
            model.addAttribute("username", username);
            return "change-password";
        }
    }
    
    /**
     * Show password change success page
     */
    @GetMapping("/password-change-success")
    public String showPasswordChangeSuccessPage() {
        return "password-change-success";
    }
}
