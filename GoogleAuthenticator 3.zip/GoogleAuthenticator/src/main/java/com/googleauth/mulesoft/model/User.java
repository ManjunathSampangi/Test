package com.googleauth.mulesoft.model;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

/**
 * Model class representing a user in the system.
 */
public class User {
    private String id;
    private String username;
    private String password; // This would be stored hashed and salted in a real application
    private String email;
    private boolean twoFactorEnabled;
    private String totpSecret;
    private List<String> recoveryCodes;
    private Date createdAt;
    private Date updatedAt;
    
    // Added fields based on requirements
    private String policyNumber;
    private String firstName;
    private String lastName;
    private Date dateOfBirth;
    private boolean tempPassword;
    private Date passwordExpiryDate;
    private String emailOtp;
    private Date otpExpiryTime;
    
    public User() {
        this.recoveryCodes = new ArrayList<>();
        this.createdAt = new Date();
        this.updatedAt = new Date();
    }
    
    public User(String username, String password, String email) {
        this.username = username;
        this.password = password;
        this.email = email;
        this.twoFactorEnabled = false;
        this.recoveryCodes = new ArrayList<>();
        this.createdAt = new Date();
        this.updatedAt = new Date();
    }
    
    // Getters and Setters
    public String getId() {
        return id;
    }
    
    public void setId(String id) {
        this.id = id;
    }
    
    public String getUsername() {
        return username;
    }
    
    public void setUsername(String username) {
        this.username = username;
    }
    
    public String getPassword() {
        return password;
    }
    
    public void setPassword(String password) {
        this.password = password;
    }
    
    public String getEmail() {
        return email;
    }
    
    public void setEmail(String email) {
        this.email = email;
    }
    
    public boolean isTwoFactorEnabled() {
        return twoFactorEnabled;
    }
    
    public void setTwoFactorEnabled(boolean twoFactorEnabled) {
        this.twoFactorEnabled = twoFactorEnabled;
        this.updatedAt = new Date();
    }
    
    public String getTotpSecret() {
        return totpSecret;
    }
    
    public void setTotpSecret(String totpSecret) {
        this.totpSecret = totpSecret;
        this.updatedAt = new Date();
    }
    
    public List<String> getRecoveryCodes() {
        return recoveryCodes;
    }
    
    public void setRecoveryCodes(List<String> recoveryCodes) {
        this.recoveryCodes = recoveryCodes;
        this.updatedAt = new Date();
    }
    
    public void addRecoveryCode(String code) {
        this.recoveryCodes.add(code);
        this.updatedAt = new Date();
    }
    
    public boolean useRecoveryCode(String code) {
        boolean removed = this.recoveryCodes.remove(code);
        if (removed) {
            this.updatedAt = new Date();
        }
        return removed;
    }
    
    public Date getCreatedAt() {
        return createdAt;
    }
    
    public void setCreatedAt(Date createdAt) {
        this.createdAt = createdAt;
    }
    
    public Date getUpdatedAt() {
        return updatedAt;
    }
    
    public void setUpdatedAt(Date updatedAt) {
        this.updatedAt = updatedAt;
    }
    
    public String getPolicyNumber() {
        return policyNumber;
    }
    
    public void setPolicyNumber(String policyNumber) {
        this.policyNumber = policyNumber;
    }
    
    public String getFirstName() {
        return firstName;
    }
    
    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }
    
    public String getLastName() {
        return lastName;
    }
    
    public void setLastName(String lastName) {
        this.lastName = lastName;
    }
    
    public Date getDateOfBirth() {
        return dateOfBirth;
    }
    
    public void setDateOfBirth(Date dateOfBirth) {
        this.dateOfBirth = dateOfBirth;
    }
    
    public boolean isTempPassword() {
        return tempPassword;
    }
    
    public void setTempPassword(boolean tempPassword) {
        this.tempPassword = tempPassword;
    }
    
    public Date getPasswordExpiryDate() {
        return passwordExpiryDate;
    }
    
    public void setPasswordExpiryDate(Date passwordExpiryDate) {
        this.passwordExpiryDate = passwordExpiryDate;
    }
    
    public String getEmailOtp() {
        return emailOtp;
    }
    
    public void setEmailOtp(String emailOtp) {
        this.emailOtp = emailOtp;
    }
    
    public Date getOtpExpiryTime() {
        return otpExpiryTime;
    }
    
    public void setOtpExpiryTime(Date otpExpiryTime) {
        this.otpExpiryTime = otpExpiryTime;
    }
}
