package com.googleauth.mulesoft.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

/**
 * Controller for testing OTP functionality
 * This would be removed in a production environment
 */
@Controller
public class TestOtpController {

    /**
     * Shows test instructions
     */
    @GetMapping("/test-otp")
    public String showTestOtpPage(Model model) {
        // Add test information to the model
        model.addAttribute("testOtp", "123456");
        model.addAttribute("testNote", "This is a test OTP for demo purposes only. In a production environment, OTPs would be sent via email.");
        
        return "test-otp";
    }
}
