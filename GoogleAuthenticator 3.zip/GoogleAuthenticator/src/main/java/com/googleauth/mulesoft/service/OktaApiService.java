package com.googleauth.mulesoft.service;

import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.http.*;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import java.util.HashMap;
import java.util.Map;

/**
 * Service for direct Okta API integration
 * Uses REST API calls for MFA operations
 */
@Service
@ConditionalOnProperty(name = "spring.profiles.active", havingValue = "okta")
public class OktaApiService {
    
    @Value("${okta.client.org-url:}")
    private String oktaOrgUrl;
    
    @Value("${okta.client.token:}")
    private String oktaApiToken;
    
    private final RestTemplate restTemplate;
    private final ObjectMapper objectMapper;
    
    public OktaApiService() {
        this.restTemplate = new RestTemplate();
        this.objectMapper = new ObjectMapper();
    }
    
    /**
     * Create headers with Okta API token
     */
    private HttpHeaders createHeaders() {
        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_JSON);
        headers.set("Authorization", "SSWS " + oktaApiToken);
        return headers;
    }
    
    /**
     * Create a new Okta user
     */
    public Map<String, Object> createUser(String email, String firstName, String lastName, String login) {
        if (oktaApiToken == null || oktaApiToken.isEmpty()) {
            throw new IllegalStateException("Okta API token not configured");
        }
        
        String url = oktaOrgUrl + "/api/v1/users?activate=true";
        
        Map<String, Object> profile = new HashMap<>();
        profile.put("firstName", firstName);
        profile.put("lastName", lastName);
        profile.put("email", email);
        profile.put("login", login);
        
        Map<String, Object> credentials = new HashMap<>();
        Map<String, Object> password = new HashMap<>();
        password.put("value", generateTempPassword());
        credentials.put("password", password);
        
        Map<String, Object> user = new HashMap<>();
        user.put("profile", profile);
        user.put("credentials", credentials);
        
        HttpEntity<Map<String, Object>> request = new HttpEntity<>(user, createHeaders());
        
        try {
            ResponseEntity<Map> response = restTemplate.exchange(url, HttpMethod.POST, request, Map.class);
            Map<String, Object> createdUser = response.getBody();
            
            System.out.println("\n==================== OKTA USER CREATED ====================");
            System.out.println("User ID: " + createdUser.get("id"));
            System.out.println("Login: " + login);
            System.out.println("Email: " + email);
            System.out.println("==========================================================\n");
            
            return createdUser;
        } catch (Exception e) {
            System.err.println("Failed to create Okta user: " + e.getMessage());
            throw new RuntimeException("Failed to create Okta user", e);
        }
    }
    
    /**
     * Enroll Google Authenticator for a user
     */
    public Map<String, Object> enrollGoogleAuthenticator(String userId) {
        String url = oktaOrgUrl + "/api/v1/users/" + userId + "/factors";
        
        Map<String, Object> factor = new HashMap<>();
        factor.put("factorType", "token:software:totp");
        factor.put("provider", "GOOGLE");
        
        HttpEntity<Map<String, Object>> request = new HttpEntity<>(factor, createHeaders());
        
        try {
            ResponseEntity<Map> response = restTemplate.exchange(url, HttpMethod.POST, request, Map.class);
            Map<String, Object> enrolledFactor = response.getBody();
            
            // Extract QR code
            Map<String, Object> embedded = (Map<String, Object>) enrolledFactor.get("_embedded");
            Map<String, Object> activation = (Map<String, Object>) embedded.get("activation");
            Map<String, Object> qrcode = (Map<String, Object>) activation.get("qrcode");
            
            System.out.println("\n==================== OKTA TOTP ENROLLMENT ====================");
            System.out.println("Factor ID: " + enrolledFactor.get("id"));
            System.out.println("Status: " + enrolledFactor.get("status"));
            System.out.println("QR Code URL: " + qrcode.get("href"));
            System.out.println("Shared Secret: " + activation.get("sharedSecret"));
            System.out.println("=============================================================\n");
            
            return enrolledFactor;
        } catch (Exception e) {
            System.err.println("Failed to enroll Google Authenticator: " + e.getMessage());
            throw new RuntimeException("Failed to enroll Google Authenticator", e);
        }
    }
    
    /**
     * Activate TOTP factor with verification code
     */
    public boolean activateTotpFactor(String userId, String factorId, String passCode) {
        String url = oktaOrgUrl + "/api/v1/users/" + userId + "/factors/" + factorId + "/lifecycle/activate";
        
        Map<String, Object> activation = new HashMap<>();
        activation.put("passCode", passCode);
        
        HttpEntity<Map<String, Object>> request = new HttpEntity<>(activation, createHeaders());
        
        try {
            ResponseEntity<Map> response = restTemplate.exchange(url, HttpMethod.POST, request, Map.class);
            Map<String, Object> result = response.getBody();
            
            System.out.println("\n==================== TOTP ACTIVATED ====================");
            System.out.println("Factor ID: " + factorId);
            System.out.println("Status: " + result.get("status"));
            System.out.println("=======================================================\n");
            
            return "ACTIVE".equals(result.get("status"));
        } catch (Exception e) {
            System.err.println("Failed to activate TOTP: " + e.getMessage());
            return false;
        }
    }
    
    /**
     * Verify TOTP code
     */
    public boolean verifyTotp(String userId, String factorId, String passCode) {
        String url = oktaOrgUrl + "/api/v1/users/" + userId + "/factors/" + factorId + "/verify";
        
        Map<String, Object> verification = new HashMap<>();
        verification.put("passCode", passCode);
        
        HttpEntity<Map<String, Object>> request = new HttpEntity<>(verification, createHeaders());
        
        try {
            ResponseEntity<Map> response = restTemplate.exchange(url, HttpMethod.POST, request, Map.class);
            Map<String, Object> result = response.getBody();
            
            String factorResult = (String) result.get("factorResult");
            
            System.out.println("\n==================== TOTP VERIFICATION ====================");
            System.out.println("Result: " + factorResult);
            System.out.println("=========================================================\n");
            
            return "SUCCESS".equals(factorResult);
        } catch (Exception e) {
            System.err.println("Failed to verify TOTP: " + e.getMessage());
            return false;
        }
    }
    
    /**
     * Get user by email/login
     */
    public Map<String, Object> getUserByLogin(String login) {
        String url = oktaOrgUrl + "/api/v1/users/" + login;
        
        HttpEntity<Void> request = new HttpEntity<>(createHeaders());
        
        try {
            ResponseEntity<Map> response = restTemplate.exchange(url, HttpMethod.GET, request, Map.class);
            return response.getBody();
        } catch (Exception e) {
            // User not found
            return null;
        }
    }
    
    /**
     * Send email factor (Okta Email OTP)
     */
    public String sendEmailFactor(String userId) {
        // First, check if email factor exists, if not enroll it
        String enrollUrl = oktaOrgUrl + "/api/v1/users/" + userId + "/factors";
        
        Map<String, Object> factor = new HashMap<>();
        factor.put("factorType", "email");
        factor.put("provider", "OKTA");
        
        HttpEntity<Map<String, Object>> enrollRequest = new HttpEntity<>(factor, createHeaders());
        
        try {
            ResponseEntity<Map> enrollResponse = restTemplate.exchange(enrollUrl, HttpMethod.POST, enrollRequest, Map.class);
            Map<String, Object> enrolledFactor = enrollResponse.getBody();
            String factorId = (String) enrolledFactor.get("id");
            
            // Now trigger the email
            String verifyUrl = oktaOrgUrl + "/api/v1/users/" + userId + "/factors/" + factorId + "/verify";
            HttpEntity<Map<String, Object>> verifyRequest = new HttpEntity<>(new HashMap<>(), createHeaders());
            
            ResponseEntity<Map> verifyResponse = restTemplate.exchange(verifyUrl, HttpMethod.POST, verifyRequest, Map.class);
            
            System.out.println("\n==================== OKTA EMAIL OTP SENT ====================");
            System.out.println("Factor ID: " + factorId);
            System.out.println("Check your email for the OTP code from Okta");
            System.out.println("============================================================\n");
            
            return factorId;
        } catch (Exception e) {
            System.err.println("Failed to send email OTP: " + e.getMessage());
            throw new RuntimeException("Failed to send email OTP", e);
        }
    }
    
    /**
     * Verify email OTP
     */
    public boolean verifyEmailOtp(String userId, String factorId, String passCode) {
        String url = oktaOrgUrl + "/api/v1/users/" + userId + "/factors/" + factorId + "/verify";
        
        Map<String, Object> verification = new HashMap<>();
        verification.put("passCode", passCode);
        
        HttpEntity<Map<String, Object>> request = new HttpEntity<>(verification, createHeaders());
        
        try {
            ResponseEntity<Map> response = restTemplate.exchange(url, HttpMethod.POST, request, Map.class);
            Map<String, Object> result = response.getBody();
            
            String factorResult = (String) result.get("factorResult");
            return "SUCCESS".equals(factorResult);
        } catch (Exception e) {
            System.err.println("Failed to verify email OTP: " + e.getMessage());
            return false;
        }
    }
    
    private String generateTempPassword() {
        // Generate a strong temporary password
        String chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789!@#$%";
        StringBuilder sb = new StringBuilder();
        java.util.Random random = new java.util.Random();
        for (int i = 0; i < 12; i++) {
            sb.append(chars.charAt(random.nextInt(chars.length())));
        }
        return sb.toString();
    }
} 