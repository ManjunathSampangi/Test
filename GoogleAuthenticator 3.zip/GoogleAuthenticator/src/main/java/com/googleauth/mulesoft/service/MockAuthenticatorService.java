package com.googleauth.mulesoft.service;

import com.warrenstrange.googleauth.GoogleAuthenticator;
import com.warrenstrange.googleauth.GoogleAuthenticatorConfig;

import org.springframework.stereotype.Service;

import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.TimeUnit;

/**
 * Service that provides a mock Google Authenticator for POC and demonstration purposes
 * Allows generating valid TOTP codes for testing without requiring the actual Google Authenticator app
 */
@Service
public class MockAuthenticatorService {

    private final GoogleAuthenticator gAuth;
    private static final Map<String, String> userSecrets = new HashMap<>();
    
    public MockAuthenticatorService() {
        // Configure Google Authenticator with the same settings as the real service
        GoogleAuthenticatorConfig config = new GoogleAuthenticatorConfig.GoogleAuthenticatorConfigBuilder()
                .setTimeStepSizeInMillis(TimeUnit.SECONDS.toMillis(30))
                .setWindowSize(1)
                .setCodeDigits(6)
                .build();
        this.gAuth = new GoogleAuthenticator(config);
    }
    
    /**
     * Store a user's secret key for later code generation
     * @param userId The user ID
     * @param secretKey The TOTP secret key
     */
    public void storeUserSecret(String userId, String secretKey) {
        userSecrets.put(userId, secretKey);
    }
    
    /**
     * Get a user's stored secret key
     * @param userId The user ID
     * @return The stored secret key, or null if not found
     */
    public String getUserSecret(String userId) {
        return userSecrets.get(userId);
    }
    
    /**
     * Generate the current valid TOTP code for a user
     * @param userId The user ID
     * @return The 6-digit TOTP code as a String, padded with leading zeros if necessary
     */
    public String generateCurrentCode(String userId) {
        String secretKey = userSecrets.get(userId);
        if (secretKey == null) {
            throw new IllegalArgumentException("No secret key found for user ID: " + userId);
        }
        
        int code = gAuth.getTotpPassword(secretKey);
        // Ensure the code is 6 digits with leading zeros if needed
        return String.format("%06d", code);
    }
    
    /**
     * Calculate the remaining seconds until the current code expires
     * @return Seconds remaining until next code generation
     */
    public int getSecondsRemaining() {
        long currentTimeMillis = System.currentTimeMillis();
        long timeStepMillis = TimeUnit.SECONDS.toMillis(30);
        return 30 - (int)((currentTimeMillis / timeStepMillis) % 30);
    }
    
    /**
     * Clear all stored user secrets
     * Useful for cleanup and testing
     */
    public void clearAllSecrets() {
        userSecrets.clear();
    }
}
