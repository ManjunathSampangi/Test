package com.googleauth.mulesoft.controller;

import com.googleauth.mulesoft.model.User;
import com.googleauth.mulesoft.service.TOTPService;
import com.googleauth.mulesoft.service.UserService;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import java.util.Optional;

/**
 * Controller for handling Google Authenticator operations
 */
@Controller
public class GoogleAuthController {

    private final UserService userService;
    private final TOTPService totpService;

    @Autowired
    public GoogleAuthController(UserService userService, TOTPService totpService) {
        this.userService = userService;
        this.totpService = totpService;
    }

    /**
     * Show TOTP verification page
     */
    @GetMapping("/verify-totp")
    public String showTotpVerificationPage(@RequestParam String userId, Model model) {
        Optional<User> userOpt = userService.findById(userId);
        if (userOpt.isEmpty()) {
            model.addAttribute("error", "User not found");
            return "login";
        }
        
        User user = userOpt.get();
        model.addAttribute("userId", user.getId());
        model.addAttribute("username", user.getUsername());
        
        // Generate and print current TOTP code to console for login verification
        if (user.getTotpSecret() != null) {
            int currentCode = totpService.generateCurrentTOTP(user.getTotpSecret());
            System.out.println("\n\n==================== LOGIN MFA VERIFICATION CODE ====================\n");
            System.out.println("   User: " + user.getUsername());
            System.out.println("   Current TOTP Code: " + currentCode + " (valid for 30 seconds)");
            System.out.println("\n==================================================================\n\n");
        }
        
        return "verify-totp";
    }

    /**
     * Verify TOTP code
     */
    @PostMapping("/verify-totp")
    public String verifyTotp(@RequestParam String userId, 
                           @RequestParam String code,
                           Model model,
                           RedirectAttributes redirectAttributes) {
        try {
            boolean isValid = userService.validate2FACode(userId, code);
            
            if (isValid) {
                User user = userService.findById(userId)
                    .orElseThrow(() -> new IllegalArgumentException("User not found"));
                
                // Add success message
                redirectAttributes.addFlashAttribute("message", "Two-factor authentication successful");
                
                // In a real implementation, you would establish a session here
                
                return "redirect:/";
            } else {
                model.addAttribute("error", "Invalid verification code. Please try again.");
                model.addAttribute("userId", userId);
                return "verify-totp";
            }
        } catch (Exception e) {
            model.addAttribute("error", e.getMessage());
            return "verify-totp";
        }
    }
    
    /**
     * Show recovery code entry page
     */
    @GetMapping("/recovery-code")
    public String showRecoveryCodePage(@RequestParam String userId, Model model) {
        model.addAttribute("userId", userId);
        return "recovery-code";
    }
    
    /**
     * Verify recovery code
     */
    @PostMapping("/recovery-code")
    public String verifyRecoveryCode(@RequestParam String userId,
                                   @RequestParam String recoveryCode,
                                   Model model,
                                   RedirectAttributes redirectAttributes) {
        try {
            boolean isValid = userService.validateRecoveryCode(userId, recoveryCode);
            
            if (isValid) {
                User user = userService.findById(userId)
                    .orElseThrow(() -> new IllegalArgumentException("User not found"));
                
                // Add success message
                redirectAttributes.addFlashAttribute("message", 
                    "Recovery successful. Please set up Google Authenticator again for future logins.");
                    
                // In a real implementation, you would establish a session here
                
                return "redirect:/";
            } else {
                model.addAttribute("error", "Invalid recovery code. Please try again.");
                model.addAttribute("userId", userId);
                return "recovery-code";
            }
        } catch (Exception e) {
            model.addAttribute("error", e.getMessage());
            return "recovery-code";
        }
    }
}
