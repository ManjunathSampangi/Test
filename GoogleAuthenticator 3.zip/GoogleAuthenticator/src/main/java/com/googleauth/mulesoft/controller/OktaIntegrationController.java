package com.googleauth.mulesoft.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.security.oauth2.core.oidc.user.OidcUser;
import org.springframework.security.oauth2.core.user.OAuth2User;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;
import java.util.Arrays;

/**
 * Controller for OKTA Sandbox Integration
 * Handles real OKTA OAuth2 authentication flow
 */
@Controller
public class OktaIntegrationController {

    @Autowired
    private Environment environment;

    /**
     * Show OKTA integration information and setup instructions
     */
    @GetMapping("/okta-info")
    public String showOktaInfo(Model model) {
        model.addAttribute("message", "OKTA Sandbox Integration is available for enterprise-grade authentication.");
        return "okta-info";
    }

    /**
     * Handle OKTA authentication success
     * This is called after successful OAuth2 login
     */
    @GetMapping("/okta-success")
    public String oktaAuthSuccess(@AuthenticationPrincipal OidcUser oidcUser,
                                  @AuthenticationPrincipal OAuth2User oauth2User,
                                  Model model,
                                  RedirectAttributes redirectAttributes) {
        
        // Determine which user type we have
        String username = null;
        String email = null;
        String fullName = null;
        
        if (oidcUser != null) {
            // OIDC User (preferred for OKTA)
            username = oidcUser.getPreferredUsername();
            email = oidcUser.getEmail();
            fullName = oidcUser.getFullName();
            
            System.out.println("\n\n==================== OKTA OIDC USER INFO ====================\n");
            System.out.println("   Username: " + username);
            System.out.println("   Email: " + email);
            System.out.println("   Full Name: " + fullName);
            System.out.println("   Claims: " + oidcUser.getClaims());
            System.out.println("   Authorities: " + oidcUser.getAuthorities());
            System.out.println("\n============================================================\n\n");
            
        } else if (oauth2User != null) {
            // OAuth2 User (fallback)
            username = oauth2User.getAttribute("preferred_username");
            email = oauth2User.getAttribute("email");
            fullName = oauth2User.getAttribute("name");
            
            System.out.println("\n\n==================== OKTA OAUTH2 USER INFO ====================\n");
            System.out.println("   Username: " + username);
            System.out.println("   Email: " + email);
            System.out.println("   Attributes: " + oauth2User.getAttributes());
            System.out.println("   Authorities: " + oauth2User.getAuthorities());
            System.out.println("\n==============================================================\n\n");
        }
        
        // Add user information to redirect attributes
        redirectAttributes.addFlashAttribute("message", 
            "🎉 OKTA authentication successful! Welcome to the secure claims portal.");
        redirectAttributes.addFlashAttribute("username", username != null ? username : "OKTA User");
        redirectAttributes.addFlashAttribute("email", email != null ? email : "Not provided");
        redirectAttributes.addFlashAttribute("fullName", fullName != null ? fullName : "Not provided");
        
        // Redirect to claims lookup with OKTA authentication success
        return "redirect:/claim-lookup?oktaAuth=success&mfa=pending";
    }

    /**
     * Handle OKTA login error
     */
    @GetMapping("/okta-login-error")
    public String oktaLoginError(@RequestParam(required = false) String error, Model model) {
        System.out.println("\n\n==================== OKTA LOGIN ERROR ====================\n");
        System.out.println("   Error: " + (error != null ? error : "Unknown error"));
        System.out.println("   Recommendation: Check OKTA configuration");
        System.out.println("\n==========================================================\n\n");
        
        model.addAttribute("error", "OKTA authentication failed. Please try again or contact your administrator.");
        model.addAttribute("errorDetails", error);
        return "okta-error";
    }

    /**
     * Handle OKTA logout success
     */
    @GetMapping("/okta-logout-success")
    public String oktaLogoutSuccess(Model model) {
        System.out.println("\n\n==================== OKTA LOGOUT SUCCESS ====================\n");
        System.out.println("   User successfully logged out from OKTA");
        System.out.println("   Session terminated");
        System.out.println("\n=============================================================\n\n");
        
        model.addAttribute("message", "You have been successfully logged out from OKTA.");
        return "okta-logout";
    }

    /**
     * Initiate OKTA login flow
     */
    @GetMapping("/okta-login")
    public String initiateOktaLogin(Model model) {
        System.out.println("\n\n==================== INITIATING OKTA LOGIN ====================\n");
        
        // Check if we're running in OKTA profile mode
        boolean isOktaProfile = Arrays.asList(environment.getActiveProfiles()).contains("okta");
        
        if (isOktaProfile) {
            System.out.println("   OKTA Profile Active: Redirecting to real OKTA OAuth2 authorization");
            System.out.println("   URL: /oauth2/authorization/okta");
            System.out.println("\n===============================================================\n\n");
            
            // Redirect to OKTA OAuth2 authorization endpoint (only works in OKTA mode)
            return "redirect:/oauth2/authorization/okta";
        } else {
            System.out.println("   Default Profile Active: Showing OKTA integration information");
            System.out.println("   Redirecting to: /okta-info");
            System.out.println("\n===============================================================\n\n");
            
            // In default mode, redirect to OKTA info page
            model.addAttribute("message", "OKTA Login is available in OKTA integration mode. Currently running in demo mode.");
            model.addAttribute("demoMode", true);
            return "redirect:/okta-info?mode=demo";
        }
    }

    /**
     * Show OKTA configuration help
     */
    @GetMapping("/okta-config-help")
    public String showOktaConfigHelp(Model model) {
        model.addAttribute("clientIdSet", System.getenv("OKTA_CLIENT_ID") != null);
        model.addAttribute("clientSecretSet", System.getenv("OKTA_CLIENT_SECRET") != null);
        model.addAttribute("domainSet", System.getenv("OKTA_DOMAIN") != null);
        model.addAttribute("apiTokenSet", System.getenv("OKTA_API_TOKEN") != null);
        
        return "okta-config-help";
    }
} 