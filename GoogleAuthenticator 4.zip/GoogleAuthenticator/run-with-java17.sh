#!/bin/bash

# Script to run the application with Java 17

echo "Starting Google Authenticator Demo with Java 17"
echo "================================================"

# Set Java 17
export JAVA_HOME=/opt/homebrew/Cellar/openjdk@17/17.0.15/libexec/openjdk.jdk/Contents/Home
export PATH=$JAVA_HOME/bin:$PATH

# Verify Java version
echo "Java version:"
java -version
echo ""

# Run the application
echo "Starting application..."
java -jar target/googleauth-demo-1.0-SNAPSHOT.jar 