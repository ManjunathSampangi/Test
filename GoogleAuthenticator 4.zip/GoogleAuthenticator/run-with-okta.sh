#!/bin/bash

# AIG OKTA Integration Launcher
# Manjunath Sampangi - AIG POC Demo

# Set Java 17 if available
if [ -d "/opt/homebrew/Cellar/openjdk@17" ]; then
    export JAVA_HOME=/opt/homebrew/Cellar/openjdk@17/17.0.15/libexec/openjdk.jdk/Contents/Home
    echo "☕ Using Java 17"
fi

echo "🚀 Starting AIG OKTA Google Authenticator POC..."
echo "   OKTA Domain: aig-trial-7695213.okta.com"
echo "   Client ID: 0oelng46KTYyKc4697"
echo "   Demo URLs:"
echo "     • OKTA Info: http://localhost:8084/okta-info"
echo "     • OKTA Login: http://localhost:8084/okta-login"
echo "     • Mock Demo: http://localhost:8084/okta-registration"
echo

java -Dspring.profiles.active=okta -jar target/googleauth-demo-1.0-SNAPSHOT.jar 