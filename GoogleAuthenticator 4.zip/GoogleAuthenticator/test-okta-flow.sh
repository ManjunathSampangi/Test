#!/bin/bash

echo "=== OKTA Registration Flow Test Script ==="
echo ""
echo "This script will help you test the OKTA registration flow with OKTA TOTP"
echo ""

# Colors for output
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
RED='\033[0;31m'
NC='\033[0m' # No Color

echo -e "${BLUE}Step 1: Starting the application...${NC}"
echo "The application should already be running on port 8084"
echo ""

echo -e "${GREEN}Step 2: Access OKTA Registration${NC}"
echo "Open your browser and go to: http://localhost:8084/okta-registration"
echo ""

echo -e "${YELLOW}Step 3: Register with test data:${NC}"
echo "Policy Number: TEST123456"
echo "Email: test@example.com"
echo ""

echo -e "${BLUE}Step 4: Watch the console for important information:${NC}"
echo ""
echo "After registration, you should see in the console:"
echo "==================== OKTA TEST ACCOUNT ===================="
echo "   Username: TEST123456"
echo "   Password: [temporary password]"
echo "   Email: test@example.com"
echo "==========================================================="
echo ""
echo "==================== OKTA EMAIL OTP ===================="
echo "   OKTA Email OTP: [6-digit code]"
echo "   Sent to: test@example.com"
echo "========================================================"
echo ""

echo -e "${GREEN}Step 5: Change Password${NC}"
echo "You'll be redirected to change your temporary password"
echo "Enter a new password (min 8 characters with letters and numbers)"
echo ""

echo -e "${YELLOW}Step 6: Enter Email OTP${NC}"
echo "After password change, you'll see in console:"
echo "==================== OKTA EMAIL OTP ===================="
echo "   OKTA Email OTP: [6-digit code]"
echo "========================================================"
echo "Use the OTP from console"
echo ""

echo -e "${BLUE}Step 7: Login with New Password${NC}"
echo "After email OTP verification, login again with:"
echo "- Username: Your policy number"
echo "- Password: Your NEW password (not the temporary one)"
echo ""

echo -e "${YELLOW}Step 8: OKTA TOTP Setup${NC}"
echo "After email OTP verification, you'll see:"
echo "==================== OKTA TOTP VERIFICATION CODE ===================="
echo "   User: TEST123456"
echo "   Current OKTA TOTP Code: [6-digit code] (valid for 30 seconds)"
echo "   OKTA Secret Key: [base32 secret]"
echo "   Use OKTA Verify app to scan QR code"
echo "===================================================================="
echo ""

echo -e "${BLUE}Step 9: Complete Setup${NC}"
echo "1. Scan the QR code with OKTA Verify app"
echo "2. Enter the TOTP code from OKTA Verify (or use the one from console for testing)"
echo "3. You'll be redirected to the claims page"
echo ""

echo -e "${GREEN}IMPORTANT: The REAL TOTP code is printed in the console!${NC}"
echo "Look for 'Current OKTA TOTP Code:' in the console output"
echo ""

echo -e "${YELLOW}Troubleshooting 403 errors:${NC}"
echo "If you get a 403 error, check that:"
echo "1. All endpoints are in SecurityConfig.java permitAll() list"
echo "2. CSRF is disabled for the endpoints"
echo "3. The application is running without the 'okta' profile"
echo "4. /setup-okta-totp and /verify-okta-totp endpoints are accessible"
echo ""

echo "Press Enter to open the registration page in your browser..."
read

# Try to open in browser (works on macOS)
open http://localhost:8084/okta-registration 2>/dev/null || echo "Please open http://localhost:8084/okta-registration in your browser" 