# How to Use Your Okta Sandbox for Real User Creation

## Your Okta Sandbox Details
- **Org URL**: https://aig-trial-7695213.okta.com
- **Admin Console**: https://aig-trial-7695213.okta.com/admin
- **Client ID**: 0oelng46KTYyKc4697

## Quick Start

### 1. Get Your API Token
```bash
# Login to Okta Admin Console
https://aig-trial-7695213.okta.com/admin

# Navigate to: Security → API → Tokens
# Click "Create Token"
# Name it: "Google Auth POC"
# Copy the token immediately!
```

### 2. Set the Token
```bash
export OKTA_API_TOKEN="00your-actual-token-here..."
```

### 3. Start with Okta Mode
```bash
./start-with-okta.sh
```

Or manually:
```bash
java -jar -Dspring.profiles.active=okta target/googleauth-demo-1.0-SNAPSHOT.jar
```

## What Happens with Real Okta

When you register a user at `/okta-registration`:

1. **User is created in Okta**: The user will appear in your Okta dashboard
2. **Real email is sent**: Okta sends a real OTP to the user's email
3. **Visible in Dashboard**: Go to Directory → People to see the user
4. **Real authentication**: User can login with Okta credentials

## Verify Users in Okta Dashboard

1. Login to: https://aig-trial-7695213.okta.com/admin
2. Go to: **Directory** → **People**
3. You'll see all users created through the API

## Demo Mode vs Real Okta

| Feature | Demo Mode | Real Okta (with API Token) |
|---------|-----------|---------------------------|
| User Storage | Local Memory | Okta Directory |
| Email OTP | Console Only | Real Email from Okta |
| Dashboard Visibility | ❌ No | ✅ Yes |
| MFA | Local TOTP | Okta MFA |
| User Persistence | Until Restart | Permanent |

## Testing Flow

1. Set API Token: `export OKTA_API_TOKEN="..."`
2. Start app: `./start-with-okta.sh`
3. Register at: http://localhost:8084/okta-registration
4. Check Okta Dashboard for the new user
5. User receives real email with OTP from Okta

## Troubleshooting

### "OKTA_API_TOKEN not set"
- You need to create and set an API token first

### Users not appearing in Okta
- Check console output for "CREATING REAL OKTA USER"
- Verify API token is valid
- Check Okta profile is active (look for "okta" in startup logs)

### 401 Unauthorized from Okta API
- Your API token may be expired or invalid
- Create a new token in Okta Admin Console

## Security Note
Never commit your API token to git! Keep it as an environment variable. 