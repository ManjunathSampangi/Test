package com.googleauth.mulesoft.controller;

import com.googleauth.mulesoft.model.User;
import com.googleauth.mulesoft.service.OktaApiService;
import com.googleauth.mulesoft.service.QRCodeService;
import com.googleauth.mulesoft.service.TOTPService;
import com.googleauth.mulesoft.service.UserService;
import com.warrenstrange.googleauth.GoogleAuthenticatorKey;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import java.io.IOException;


/**
 * Controller for OKTA registration and Google Authenticator integration
 */
@Controller
public class OktaController {

    private final UserService userService;
    private final TOTPService totpService;
    private final QRCodeService qrCodeService;
    private final OktaApiService oktaApiService;

    @Autowired
    public OktaController(UserService userService, TOTPService totpService, QRCodeService qrCodeService,
                          @Autowired(required = false) OktaApiService oktaApiService) {
        this.userService = userService;
        this.totpService = totpService;
        this.qrCodeService = qrCodeService;
        this.oktaApiService = oktaApiService;
    }

    /**
     * Show OKTA registration page
     */
    @GetMapping("/okta-registration")
    public String showOktaRegistrationPage() {
        return "okta-registration";
    }

    /**
     * Process OKTA registration
     */
    @PostMapping("/okta-registration")
    public String processOktaRegistration(@RequestParam String policyNumber, 
                                         @RequestParam String email,
                                         Model model,
                                         RedirectAttributes redirectAttributes) {
        try {
            User user;
            String tempPassword;
            
            // Check if we have Okta API service available (running with Okta profile)
            if (oktaApiService != null) {
                // REAL OKTA: Create user in Okta
                System.out.println("\n==================== CREATING REAL OKTA USER ====================");
                System.out.println("Using Okta API to create user in: aig-trial-7695213.okta.com");
                System.out.println("================================================================\n");
                
                java.util.Map<String, Object> oktaUser = oktaApiService.createUser(email, "Policy", "Holder", policyNumber);
                String oktaUserId = (String) oktaUser.get("id");
                
                // Create local user record to track
                UserService.RegistrationResult result = userService.registerWithPolicy(policyNumber, "OKTA", "User", null, email);
                user = result.getUser();
                tempPassword = "Check Okta Email";
                
                // Send real Okta email OTP
                String factorId = oktaApiService.sendEmailFactor(oktaUserId);
                
                redirectAttributes.addFlashAttribute("oktaMode", true);
                redirectAttributes.addFlashAttribute("registrationSuccess", true);
                redirectAttributes.addFlashAttribute("message", "Real Okta user created! Please login with your credentials.");
            } else {
                // DEMO MODE: Create local user
                System.out.println("\n==================== DEMO MODE (Local User) ====================");
                System.out.println("Creating local user - NOT in real Okta");
                System.out.println("To use real Okta, set OKTA_API_TOKEN and run with -Dspring.profiles.active=okta");
                System.out.println("================================================================\n");
                
                UserService.RegistrationResult result = userService.registerWithPolicy(policyNumber, "OKTA", "User", null, email);
                user = result.getUser();
                tempPassword = result.getTempPassword();
                
                redirectAttributes.addFlashAttribute("demoMode", true);
                redirectAttributes.addFlashAttribute("registrationSuccess", true);
                redirectAttributes.addFlashAttribute("message", "Demo user created locally (not in real Okta). Please login with your credentials below.");
            }
            
            // Print to console for testing purposes
            System.out.println("\n\n==================== OKTA TEST ACCOUNT ====================\n");
            System.out.println("   Username: " + policyNumber);
            System.out.println("   Password: " + tempPassword);
            System.out.println("   Email: " + email);
            System.out.println("   Next Step: LOGIN with these credentials");
            System.out.println("\n===========================================================\n\n");
            
            // Add registration details to flash attributes for login page
            redirectAttributes.addFlashAttribute("username", policyNumber);
            redirectAttributes.addFlashAttribute("tempPassword", tempPassword);
            redirectAttributes.addFlashAttribute("email", email);
            redirectAttributes.addFlashAttribute("userType", "OKTA");
            
            // Redirect to login page instead of directly to OTP verification
            return "redirect:/login?oktaRegistration=true";
        } catch (Exception e) {
            System.err.println("Registration error: " + e.getMessage());
            e.printStackTrace();
            model.addAttribute("error", "Registration failed. Please try again.");
            return "okta-registration";
        }
    }
    
    /**
     * Show OKTA Email OTP verification page
     */
    @GetMapping("/okta-email-otp")
    public String showOktaEmailOtp(@RequestParam String userId, 
                                  @RequestParam String email, 
                                  Model model) {
        try {
            // Verify user exists
            User user = userService.findById(userId)
                .orElseThrow(() -> new IllegalArgumentException("User not found"));
            
            model.addAttribute("userId", userId);
            model.addAttribute("email", email);
            model.addAttribute("message", "OKTA OKTA Email Verification code has been sent to your registered email address.");
            
            return "okta-email-otp";
        } catch (Exception e) {
            model.addAttribute("error", "Failed to load OKTA OKTA Email Verification: " + e.getMessage());
            return "okta-registration";
        }
    }
    
    /**
     * Verify OKTA Email OTP
     */
    @PostMapping("/verify-okta-email-otp")
    public String verifyOktaEmailOtp(@RequestParam String userId,
                                    @RequestParam String email,
                                    @RequestParam String otp,
                                    Model model,
                                    RedirectAttributes redirectAttributes) {
        try {
            // Verify the email OTP
            boolean isOtpValid = userService.verifyEmailOTP(email, otp);
            
            if (isOtpValid) {
                User user = userService.findById(userId)
                    .orElseThrow(() -> new IllegalArgumentException("User not found"));
                
                System.out.println("\n\n==================== OKTA EMAIL OTP VERIFIED ====================\n");
                System.out.println("   User: " + user.getUsername());
                System.out.println("   Email: " + email);
                System.out.println("   OKTA OKTA Email Verification: COMPLETE");
                System.out.println("   Next: Login again with new password, then setup OKTA TOTP");
                System.out.println("\n==============================================================\n\n");
                
                // Mark email as verified and redirect to login for the complete flow
                redirectAttributes.addFlashAttribute("message", 
                    "✅ OKTA OKTA Email Verification completed! Please login again with your new password to continue with OKTA TOTP setup.");
                redirectAttributes.addFlashAttribute("emailVerified", true);
                redirectAttributes.addFlashAttribute("username", user.getUsername());
                redirectAttributes.addFlashAttribute("nextStep", "mfa_setup");
                
                return "redirect:/login?emailVerified=true";
            } else {
                model.addAttribute("error", "Invalid or expired OKTA OKTA Email Verification code. Please try again.");
                model.addAttribute("userId", userId);
                model.addAttribute("email", email);
                return "okta-email-otp";
            }
        } catch (Exception e) {
            model.addAttribute("error", "Failed to verify OKTA email OTP: " + e.getMessage());
            model.addAttribute("userId", userId);
            model.addAttribute("email", email);
            return "okta-email-otp";
        }
    }
    
    /**
     * Show Google Authenticator setup page
     */
    @GetMapping("/setup-google-auth")
    public String showGoogleAuthSetup(@RequestParam String userId, Model model) {
        try {
            // Get the user
            User user = userService.findById(userId)
                .orElseThrow(() -> new IllegalArgumentException("User not found"));
                
            // If this is an OKTA user, redirect to OKTA TOTP setup
            if (user.getPolicyNumber() != null) {
                return "redirect:/setup-okta-totp?userId=" + userId;
            }
                
            // Generate TOTP secret if not already done
            GoogleAuthenticatorKey key;
            if (user.getTotpSecret() == null) {
                key = userService.enable2FA(userId);
            } else {
                key = new GoogleAuthenticatorKey.Builder(user.getTotpSecret()).build();
            }
            
            // Generate QR code URL
            String qrCodeUrl = totpService.generateQRCodeURL(user, "Google Auth Demo");
            
            // Generate QR code image as data URI
            String qrCodeDataUri = qrCodeService.generateQRCodeDataUri(qrCodeUrl);
            
            // Generate current TOTP code and print to console for testing
            int currentCode = totpService.generateCurrentTOTP(key.getKey());
            System.out.println("\n\n==================== MFA VERIFICATION CODE ====================\n");
            System.out.println("   User: " + user.getUsername());
            System.out.println("   Current TOTP Code: " + String.format("%06d", currentCode) + " (valid for 30 seconds)");
            System.out.println("   Secret Key: " + key.getKey());
            System.out.println("\n============================================================\n\n");
            
            // Add data to the model
            model.addAttribute("userId", userId);
            model.addAttribute("secret", key.getKey());
            model.addAttribute("qrCodeDataUri", qrCodeDataUri);
            
            return "setup-google-auth";
        } catch (Exception e) {
            model.addAttribute("error", "Failed to set up Google Authenticator: " + e.getMessage());
            return "login";
        }
    }
    
    /**
     * Show OKTA TOTP setup page
     */
    @GetMapping("/setup-okta-totp")
    public String showOktaTotpSetup(@RequestParam String userId, Model model) {
        try {
            // Get the user
            User user = userService.findById(userId)
                .orElseThrow(() -> new IllegalArgumentException("User not found"));
                
            // Generate TOTP secret if not already done
            GoogleAuthenticatorKey key;
            if (user.getTotpSecret() == null) {
                key = userService.enable2FA(userId);
            } else {
                key = new GoogleAuthenticatorKey.Builder(user.getTotpSecret()).build();
            }
            
            // Generate QR code URL with OKTA branding
            String qrCodeUrl = totpService.generateQRCodeURL(user, "OKTA MFA");
            
            // Generate QR code image as data URI
            String qrCodeDataUri = qrCodeService.generateQRCodeDataUri(qrCodeUrl);
            
            // Generate current TOTP code and print to console for testing
            int currentCode = totpService.generateCurrentTOTP(key.getKey());
            System.out.println("\n\n==================== OKTA TOTP VERIFICATION CODE ====================\n");
            System.out.println("   User: " + user.getUsername());
            System.out.println("   Current OKTA TOTP Code: " + String.format("%06d", currentCode) + " (valid for 30 seconds)");
            System.out.println("   OKTA Secret Key: " + key.getKey());
            System.out.println("   Use OKTA Verify app to scan QR code");
            System.out.println("\n==================================================================\n\n");
            
            // Add data to the model
            model.addAttribute("userId", userId);
            model.addAttribute("secret", key.getKey());
            model.addAttribute("qrCodeDataUri", qrCodeDataUri);
            
            return "setup-okta-totp";
        } catch (Exception e) {
            model.addAttribute("error", "Failed to set up OKTA TOTP: " + e.getMessage());
            return "login";
        }
    }
    
    /**
     * Verify OKTA TOTP setup
     */
    @PostMapping("/verify-okta-totp")
    public String verifyOktaTotp(@RequestParam String userId,
                                @RequestParam String verificationCode,
                                Model model,
                                RedirectAttributes redirectAttributes) {
        try {
            // Add debugging
            System.out.println("\n\n==================== VERIFYING OKTA TOTP ====================");
            System.out.println("   User ID: " + userId);
            System.out.println("   Entered Code: " + verificationCode);
            
            // Get user and generate current code for comparison
            User user = userService.findById(userId)
                .orElseThrow(() -> new IllegalArgumentException("User not found"));
            
            if (user.getTotpSecret() != null) {
                int currentCode = totpService.generateCurrentTOTP(user.getTotpSecret());
                System.out.println("   Current Valid Code: " + String.format("%06d", currentCode));
                System.out.println("   Secret Key: " + user.getTotpSecret());
            }
            System.out.println("==============================================================\n\n");
            
            boolean isVerified = userService.verify2FA(userId, verificationCode);
            
            if (isVerified) {
                System.out.println("\n\n==================== OKTA MFA SETUP COMPLETE ====================\n");
                System.out.println("   User: " + user.getUsername());
                System.out.println("   Email: " + user.getEmail());
                System.out.println("   OKTA Registration Flow: COMPLETE");
                System.out.println("   OKTA TOTP: ENABLED");
                System.out.println("   Redirecting to: Policy Dashboard");
                System.out.println("\n================================================================\n\n");
                
                // Add success message for claims page
                redirectAttributes.addFlashAttribute("message", 
                    "🎉 Complete! OKTA TOTP setup successful. Welcome to your secure policy dashboard!");
                redirectAttributes.addFlashAttribute("username", user.getUsername());
                redirectAttributes.addFlashAttribute("email", user.getEmail());
                redirectAttributes.addFlashAttribute("mfaSetupComplete", true);
                
                // Redirect to claims lookup page - the final step
                return "redirect:/claim-lookup?mfaSetupComplete=true";
            } else {
                model.addAttribute("error", "Invalid verification code. Please try again.");
                model.addAttribute("userId", userId);
                
                // Re-generate QR code
                String qrCodeUrl = totpService.generateQRCodeURL(user, "OKTA MFA");
                String qrCodeDataUri = qrCodeService.generateQRCodeDataUri(qrCodeUrl);
                
                model.addAttribute("secret", user.getTotpSecret());
                model.addAttribute("qrCodeDataUri", qrCodeDataUri);
                
                return "setup-okta-totp";
            }
        } catch (Exception e) {
            model.addAttribute("error", "Failed to verify: " + e.getMessage());
            return "login";
        }
    }
    
    /**
     * Verify Google Authenticator setup (for non-OKTA users)
     */
    @PostMapping("/verify-google-auth")
    public String verifyGoogleAuth(@RequestParam String userId,
                                  @RequestParam String verificationCode,
                                  Model model,
                                  RedirectAttributes redirectAttributes) {
        try {
            boolean isVerified = userService.verify2FA(userId, verificationCode);
            
            if (isVerified) {
                User user = userService.findById(userId)
                    .orElseThrow(() -> new IllegalArgumentException("User not found"));
                
                System.out.println("\n\n==================== MFA SETUP COMPLETE ====================\n");
                System.out.println("   User: " + user.getUsername());
                System.out.println("   Email: " + user.getEmail());
                System.out.println("   Registration Flow: COMPLETE");
                System.out.println("   Google Authenticator: ENABLED");
                System.out.println("   Redirecting to: Policy Dashboard");
                System.out.println("\n==============================================================\n\n");
                
                // Add success message for claims page
                redirectAttributes.addFlashAttribute("message", 
                    "🎉 Complete! Google Authenticator setup successful. Welcome to your secure policy dashboard!");
                redirectAttributes.addFlashAttribute("username", user.getUsername());
                redirectAttributes.addFlashAttribute("email", user.getEmail());
                redirectAttributes.addFlashAttribute("mfaSetupComplete", true);
                
                // Redirect to claims lookup page - the final step
                return "redirect:/claim-lookup?mfaSetupComplete=true";
            } else {
                model.addAttribute("error", "Invalid verification code. Please try again.");
                model.addAttribute("userId", userId);
                
                // Re-generate QR code
                User user = userService.findById(userId)
                    .orElseThrow(() -> new IllegalArgumentException("User not found"));
                String qrCodeUrl = totpService.generateQRCodeURL(user, "Google Auth Demo");
                String qrCodeDataUri = qrCodeService.generateQRCodeDataUri(qrCodeUrl);
                
                model.addAttribute("secret", user.getTotpSecret());
                model.addAttribute("qrCodeDataUri", qrCodeDataUri);
                
                return "setup-google-auth";
            }
        } catch (Exception e) {
            model.addAttribute("error", "Failed to verify: " + e.getMessage());
            return "login";
        }
    }
}
