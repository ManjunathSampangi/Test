package com.googleauth.mulesoft.controller;

import org.springframework.boot.web.servlet.error.ErrorController;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

import javax.servlet.http.HttpServletRequest;

/**
 * Controller for handling application errors
 */
@Controller
public class CustomErrorController implements ErrorController {

    @RequestMapping("/error")
    public String handleError(HttpServletRequest request, Model model) {
        Integer statusCode = (Integer) request.getAttribute("javax.servlet.error.status_code");
        Exception exception = (Exception) request.getAttribute("javax.servlet.error.exception");
        String errorMessage = (String) request.getAttribute("javax.servlet.error.message");
        
        System.out.println("\n==================== ERROR OCCURRED ====================");
        System.out.println("Status Code: " + statusCode);
        System.out.println("Error Message: " + errorMessage);
        if (exception != null) {
            System.out.println("Exception: " + exception.getClass().getSimpleName() + " - " + exception.getMessage());
        }
        System.out.println("======================================================\n");
        
        model.addAttribute("statusCode", statusCode);
        model.addAttribute("errorMessage", errorMessage != null ? errorMessage : "An unexpected error occurred");
        
        if (statusCode != null) {
            if (statusCode == 404) {
                model.addAttribute("title", "Page Not Found");
                model.addAttribute("description", "The page you're looking for doesn't exist.");
            } else if (statusCode == 500) {
                model.addAttribute("title", "Internal Server Error");
                model.addAttribute("description", "Something went wrong on our end. Please try again.");
            } else {
                model.addAttribute("title", "Error " + statusCode);
                model.addAttribute("description", "An error occurred while processing your request.");
            }
        } else {
            model.addAttribute("title", "Error");
            model.addAttribute("description", "An unexpected error occurred.");
        }
        
        return "error";
    }

    public String getErrorPath() {
        return "/error";
    }
} 