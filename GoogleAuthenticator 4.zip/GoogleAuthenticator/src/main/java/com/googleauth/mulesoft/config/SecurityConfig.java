package com.googleauth.mulesoft.config;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.web.SecurityFilterChain;
import org.springframework.web.cors.CorsConfigurationSource;

@Configuration
@EnableWebSecurity
public class SecurityConfig {

    @Autowired
    private CorsConfigurationSource corsConfigurationSource;

    @Bean
    public SecurityFilterChain securityFilterChain(HttpSecurity http) throws Exception {
        http
            .cors(cors -> cors.configurationSource(corsConfigurationSource))
            .csrf().disable()
            .authorizeRequests()
                .antMatchers(
                    "/", "/index.html", "/css/**", "/js/**", "/api/**", "/error",
                    "/login", "/custom-login", "/auth-login", "/register", "/reset-password", "/claim-lookup", "/email-otp", "/okta-registration",
                    "/okta-login", "/okta-info", "/okta-email-otp", "/verify-okta-email-otp", "/okta-success", "/okta-login-error", "/okta-logout-success",
                    "/oauth2/**", "/login/oauth2/code/**",
                    "/send-email-otp", "/verify-otp", "/verify-claim-otp", "/change-password", "/change-temp-password",
                    "/process-password-change", "/registration-success", "/reset-password-confirmation", "/password-change-success", 
                    "/otp-success", "/claim-details", "/test-otp", "/setup-google-auth", "/verify-google-auth", "/verify-totp", "/recovery-code",
                    "/setup-okta-totp", "/verify-okta-totp"
                ).permitAll()
                .anyRequest().authenticated()
            .and()
            // Disable default Spring Security form login
            .formLogin().disable()
            .logout().permitAll();
            
        return http.build();
    }
}
