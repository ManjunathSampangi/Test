package com.googleauth.mulesoft.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;

/**
 * Controller for the main landing page
 */
@Controller
public class HomeController {

    /**
     * Serves the main landing page
     */
    @GetMapping("/")
    public String home() {
        return "redirect:/index.html";
    }
}
