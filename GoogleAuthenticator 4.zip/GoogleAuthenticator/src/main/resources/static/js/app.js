/**
 * Main Application Module
 * Initializes and coordinates all modules
 */
const App = (function() {
    // DOM Elements
    const authContainer = document.getElementById('auth-container');
    const setupContainer = document.getElementById('twofa-setup-container');
    const recoveryCodesContainer = document.getElementById('recovery-codes-container');
    const dashboardContainer = document.getElementById('dashboard-container');
    const claimLookupContainer = document.getElementById('claim-lookup-container');
    const claimVerificationContainer = document.getElementById('claim-verification-container');
    const claimDetailsContainer = document.getElementById('claim-details-container');
    const notificationElement = document.getElementById('notification');
    
    /**
     * Initialize the application
     */
    function init() {
        // Initialize all modules
        Auth.init();
        TwoFA.init();
        Dashboard.init();
        Claims.init();
        
        // Handle notification clicks (to dismiss)
        notificationElement.addEventListener('click', function() {
            hideNotification();
        });
        
        // Lookup Claim buttons
        document.getElementById('lookup-claim-button').addEventListener('click', function() {
            Claims.showClaimLookup();
        });
        
        // Header lookup button
        document.getElementById('header-lookup-claim').addEventListener('click', function() {
            Claims.showClaimLookup();
        });
        
        // After login, check if we need to show a claim that was requested before login
        const authState = checkAuthState();
        if (authState.isLoggedIn && Claims.checkPendingClaim()) {
            // Claims.checkPendingClaim will handle showing the correct screens
        } else if (authState.isLoggedIn) {
            showDashboard();
        }
    }
    
    /**
     * Hide all main containers
     */
    function hideAllContainers() {
        authContainer.classList.add('hidden');
        setupContainer.classList.add('hidden');
        recoveryCodesContainer.classList.add('hidden');
        dashboardContainer.classList.add('hidden');
        claimLookupContainer.classList.add('hidden');
        claimVerificationContainer.classList.add('hidden');
        claimDetailsContainer.classList.add('hidden');
    }
    
    /**
     * Show the dashboard
     */
    function showDashboard() {
        hideAllContainers();
        dashboardContainer.classList.remove('hidden');
        Dashboard.loadDashboard();
    }
    
    /**
     * Check authentication state from session storage
     * @returns {Object} Authentication state with isLoggedIn and userId
     */
    function checkAuthState() {
        const userId = sessionStorage.getItem(Auth.STORAGE_KEYS.USER_ID);
        return {
            isLoggedIn: !!userId,
            userId: userId
        };
    }
    
    /**
     * Show a notification to the user
     * @param {string} message - The message to display
     * @param {string} type - The type of notification (success, error, info)
     */
    function showNotification(message, type = 'info') {
        notificationElement.textContent = message;
        notificationElement.className = `notification ${type} show`;
        
        // Auto-hide after 5 seconds
        setTimeout(hideNotification, 5000);
    }
    
    /**
     * Hide the notification
     */
    function hideNotification() {
        notificationElement.className = 'notification hidden';
    }
    
    // Initialize the application when the DOM is fully loaded
    document.addEventListener('DOMContentLoaded', init);
    
    // Public API
    return {
        hideAllContainers,
        showDashboard,
        showNotification
    };
})();
