#!/bin/bash

# Script to start the application with real Okta integration

echo "Starting Google Authenticator Demo with REAL Okta Integration"
echo "============================================================="
echo ""

# Check if OKTA_API_TOKEN is set
if [ -z "$OKTA_API_TOKEN" ]; then
    echo "❌ OKTA_API_TOKEN not set!"
    echo ""
    echo "To get your API token:"
    echo "1. Login to: https://aig-trial-7695213.okta.com/admin"
    echo "2. Go to: Security → API → Tokens"
    echo "3. Create a new token"
    echo "4. Run: export OKTA_API_TOKEN='your-token-here'"
    echo ""
    echo "Then run this script again."
    exit 1
fi

echo "✅ OKTA_API_TOKEN is set"
echo ""
echo "Starting application with:"
echo "- Okta Profile: Active"
echo "- Okta Org: aig-trial-7695213.okta.com"
echo "- Real user creation in Okta"
echo "- Real email OTPs from Okta"
echo ""

# Set Java home
export JAVA_HOME=/opt/homebrew/Cellar/openjdk@17/17.0.15/libexec/openjdk.jdk/Contents/Home

# Run with Okta profile
java -jar -Dspring.profiles.active=okta target/googleauth-demo-1.0-SNAPSHOT.jar 