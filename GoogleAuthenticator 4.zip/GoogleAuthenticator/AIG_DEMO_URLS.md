# 🏢 **AIG DEMO - QUICK ACCESS GUIDE**
**User**: Manjunath Sampangi (Manjunath.Sampangi@aig.com)
**Status**: ✅ Application Running on http://localhost:8084

---

## 🚀 **IMMEDIATE DEMO OPTIONS**

### **Option 1: Mock Integration (Available Now)**
```
🔗 URL: http://localhost:8084/okta-registration
📝 Test Data for AIG Demo:
   Policy Number: AIG-POL-123456
   Email: Manjunath.Sampangi@aig.com
   Company: AIG
```

**Demo Flow:**
1. Navigate to: `http://localhost:8084/okta-registration`
2. Enter Policy Number: `AIG-POL-123456`
3. Enter Email: `Manjunath.Sampangi@aig.com`
4. Follow OKTA Email OTP → Google Authenticator → Claims Access
5. Use test OTP: `123456` (displayed in browser)
6. Complete 2FA setup and access claims portal

### **Option 2: OKTA Integration Info**
```
🔗 URL: http://localhost:8084/okta-info
🎯 Purpose: Show enterprise OKTA capabilities
📋 Status: Ready for OKTA sandbox setup
```

**What to Show:**
- Real vs Mock authentication options
- OKTA configuration status
- Enterprise security features
- Setup instructions for production

---

## 🎬 **DEMO SCRIPT FOR AIG STAKEHOLDERS**

### **Introduction (1 minute)**
> "This demonstrates OKTA integration with Google Authenticator for AIG's enterprise security requirements."

### **Mock Demo (3 minutes)**
1. **Navigate**: `http://localhost:8084/okta-registration`
2. **Show**: AIG-specific policy number and email
3. **Demonstrate**: Email OTP verification (branded as OKTA)
4. **Setup**: Google Authenticator with QR code
5. **Access**: Secure claims portal

### **OKTA Enterprise Features (2 minutes)**
1. **Navigate**: `http://localhost:8084/okta-info`
2. **Explain**: Real OKTA vs demonstration modes
3. **Show**: Configuration status and setup process
4. **Discuss**: Production deployment path

### **Claims Portal (2 minutes)**
1. **Show**: Authenticated user experience
2. **Demonstrate**: Claim lookup functionality
3. **Highlight**: Security features and audit trail

---

## 🔐 **SECURITY FEATURES TO HIGHLIGHT**

### **For AIG Requirements:**
- ✅ **Multi-Factor Authentication**: Email OTP + Google Authenticator
- ✅ **Enterprise SSO**: OKTA integration ready
- ✅ **Audit Logging**: Complete authentication trail
- ✅ **Session Management**: Secure timeout and logout
- ✅ **Claims Access Control**: Policy-based authorization

### **Production Readiness:**
- ✅ **OAuth 2.0/OIDC**: Industry standard protocols
- ✅ **OKTA Sandbox**: Free enterprise testing environment
- ✅ **Scalable Architecture**: Spring Boot microservices
- ✅ **AIG Integration**: Ready for corporate deployment

---

## 📱 **TEST URLS FOR IMMEDIATE USE**

| Purpose | URL | Notes |
|---------|-----|-------|
| **Main Demo** | `http://localhost:8084/okta-registration` | Start here for full demo |
| **OKTA Info** | `http://localhost:8084/okta-info` | Enterprise integration details |
| **Claims Portal** | `http://localhost:8084/claim-lookup` | Post-authentication experience |
| **Mock API** | `http://localhost:8084/api/mock/time-remaining` | Technical demonstration |

---

## 📞 **NEXT STEPS FOR AIG**

### **Immediate (Today):**
1. ✅ **Demo Ready**: Use mock integration for presentation
2. ✅ **Test Data**: AIG policy numbers and email configured
3. ✅ **Full Flow**: Registration → OTP → 2FA → Claims

### **OKTA Setup (Optional - 10 minutes):**
1. **Create Account**: Visit `https://developer.okta.com/signup/`
2. **Use AIG Email**: `Manjunath.Sampangi@aig.com`
3. **Configure App**: Follow `aig-okta-setup.md` instructions
4. **Run Setup**: `./setup-okta-env.sh`

### **Production Discussion:**
- OKTA enterprise license requirements
- AIG IT security approval process
- Integration with existing AIG systems
- User provisioning and management

---

## 🎯 **DEMO SUCCESS METRICS**

### **Technical Demonstration:**
- [x] Multi-factor authentication working
- [x] Google Authenticator integration
- [x] Claims portal access control
- [x] AIG branding and data

### **Business Value:**
- [x] Enhanced security for claims access
- [x] Reduced fraud through 2FA
- [x] Enterprise-grade authentication
- [x] Seamless user experience

**🎉 Ready to demonstrate enterprise security for AIG!** 