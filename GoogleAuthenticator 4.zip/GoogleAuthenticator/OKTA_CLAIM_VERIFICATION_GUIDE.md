# OKTA TOTP Claim Verification Guide

## What's Fixed

1. **OKTA users now use OKTA TOTP** - No more Google Authenticator prompts for OKTA users
2. **Proper user detection** - The system now correctly identifies OKTA users by their policy number
3. **Better error messages** - Clear indication of which authentication method is being used

## How It Works

### For OKTA Users (have policy number):
- When accessing claims, you'll see **"OKTA Verification"**
- You'll be asked for a code from your **OKTA Verify app**
- The console will show the current OKTA TOTP code for testing

### For Google Auth Users (no policy number):
- When accessing claims, you'll see **"Google Authenticator"** verification
- You'll be asked for a code from your **Google Authenticator app**
- The console will show the current Google Auth code for testing

## Testing Steps

### 1. Complete OKTA Registration First
```
1. Go to /okta-registration
2. Register with a policy number (e.g., POL123456)
3. Complete the full flow including OKTA TOTP setup
4. Make note of your policy number
```

### 2. Access Your Claim
```
1. Go to /claim-lookup
2. Enter a claim number (e.g., CL-2025-000001)
3. You should see "OKTA Verification" page (not Google Authenticator)
```

### 3. Enter OKTA TOTP Code
```
1. Look in the console for:
   ==================== OKTA TOTP CODE FOR CLAIM ACCESS ====================
   User: POL123456
   Current OKTA TOTP Code: 012345 (valid for 30 seconds)
   =====================================================================

2. Enter this 6-digit code in the verification form
3. Submit to access your claim details
```

## Console Debug Output

When verifying, you'll see:
```
==================== VERIFYING CLAIM OTP ====================
   User: POL123456
   Entered Code: 012345
   Using OKTA TOTP: true
   Using Google Auth: false
   Current Valid Code: 012345
===========================================================
```

## Common Issues Resolved

1. **No more Google Authenticator for OKTA users** - OKTA users will only see OKTA TOTP verification
2. **OTP generation works** - Console shows the current valid code with proper formatting
3. **Clear authentication method** - The page clearly shows if it's OKTA or Google Auth verification

## Quick Test

1. **Register as OKTA user**: `/okta-registration` with policy `TEST123`
2. **Complete OKTA TOTP setup**
3. **Try claim lookup**: Use claim `CL-2025-000001`
4. **Enter OKTA TOTP code** from console
5. **Success!** You should see claim details

The application now properly separates OKTA TOTP and Google Authenticator flows! 