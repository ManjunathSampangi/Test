# OKTA TOTP Implementation

## Overview

The OKTA registration flow now uses **OKTA TOTP** (Time-based One-Time Password) instead of Google Authenticator for multi-factor authentication. This provides a fully integrated OKTA experience using OKTA Verify app.

## Key Changes

### 1. Separate TOTP Flows
- **OKTA Users**: Use OKTA TOTP with OKTA Verify app
- **Non-OKTA Users**: Continue using Google Authenticator

### 2. New Endpoints
- `/setup-okta-totp` - OKTA TOTP setup page
- `/verify-okta-totp` - OKTA TOTP verification

### 3. Automatic Routing
When a user reaches the MFA setup step:
- OKTA users (with policy number) → Redirected to OKTA TOTP setup
- Regular users → Continue to Google Authenticator setup

## OKTA Registration Flow

1. **OKTA Registration** (`/okta-registration`)
2. **Login with Temporary Password** (`/login`)
3. **Password Change** (`/change-temp-password`)
4. **OKTA Email OTP** (`/okta-email-otp`)
5. **Login with New Password** (`/login`)
6. **OKTA TOTP Setup** (`/setup-okta-totp`)
7. **Claims Dashboard** (`/claim-lookup`)

## Technical Implementation

### Controller Logic
```java
// In OktaController.java
@GetMapping("/setup-google-auth")
public String showGoogleAuthSetup(@RequestParam String userId, Model model) {
    User user = userService.findById(userId).orElseThrow(...);
    
    // Redirect OKTA users to OKTA TOTP setup
    if (user.getPolicyNumber() != null) {
        return "redirect:/setup-okta-totp?userId=" + userId;
    }
    
    // Continue with Google Authenticator for non-OKTA users
    // ...
}
```

### OKTA TOTP Setup Page
- New template: `setup-okta-totp.html`
- Branded for OKTA Verify app
- Clear instructions for OKTA Verify setup
- QR code generation with "OKTA MFA" label

### Console Output
```
==================== OKTA TOTP VERIFICATION CODE ====================
   User: [policy_number]
   Current OKTA TOTP Code: [6-digit code] (valid for 30 seconds)
   OKTA Secret Key: [base32_secret]
   Use OKTA Verify app to scan QR code
==================================================================
```

## User Experience

### For OKTA Users:
1. Complete OKTA registration
2. Go through email verification
3. Set up OKTA TOTP using OKTA Verify app
4. Use OKTA Verify for all future logins

### For Non-OKTA Users:
1. Standard registration
2. Set up Google Authenticator
3. Use Google Authenticator for future logins

## Testing

1. **OKTA Flow Test**:
   ```bash
   ./test-okta-flow.sh
   ```

2. **Console Verification**:
   - All TOTP codes are printed to console
   - Look for "OKTA TOTP VERIFICATION CODE" section

3. **App Requirements**:
   - OKTA users: Install OKTA Verify app
   - Non-OKTA users: Install Google Authenticator app

## Security Benefits

✅ **Unified OKTA Experience**: OKTA users stay within OKTA ecosystem  
✅ **Enterprise Integration**: OKTA Verify integrates with OKTA policies  
✅ **Backward Compatible**: Non-OKTA users continue with Google Auth  
✅ **Same Security Level**: Both use industry-standard TOTP algorithm 