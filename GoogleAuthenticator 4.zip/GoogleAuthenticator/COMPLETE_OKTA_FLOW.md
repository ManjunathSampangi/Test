# Complete OKTA Registration and Authentication Flow

## Flow Overview

The OKTA registration flow includes all security steps: password change, email OTP verification, and OKTA TOTP setup.

## Step-by-Step Flow

### 1. OKTA Registration
- **URL**: `/okta-registration`
- **Action**: Enter policy number and email
- **Result**: User created with temporary password
- **Console Output**:
  ```
  ==================== OKTA TEST ACCOUNT ====================
     Username: [policy_number]
     Password: [temp_password]
     Email: [email]
  ===========================================================
  ```

### 2. First Login (Temporary Password)
- **URL**: `/login` 
- **Action**: Login with policy number and temporary password
- **Result**: Redirected to password change page

### 3. Password Update
- **URL**: `/change-temp-password`
- **Action**: Set new password
- **Result**: Password updated and email OTP generated
- **Console Output**:
  ```
  ==================== OKTA EMAIL OTP ====================
     OKTA Email OTP: [6-digit code]
     Sent to: [email]
  ========================================================
  ```

### 4. Email OTP Verification
- **URL**: `/okta-email-otp`
- **Action**: Enter the 6-digit OTP from console/email
- **Result**: Email verified, redirected to login

### 5. Second Login (New Password)
- **URL**: `/login`
- **Action**: Login with policy number and NEW password
- **Result**: Redirected to OKTA TOTP setup

### 6. OKTA TOTP Setup
- **URL**: `/setup-okta-totp`
- **Action**: 
  - Scan QR code with OKTA Verify app
  - Enter TOTP code from OKTA Verify
- **Console Output**:
  ```
  ==================== OKTA TOTP VERIFICATION CODE ====================
     User: [policy_number]
     Current OKTA TOTP Code: [6-digit code] (valid for 30 seconds)
     OKTA Secret Key: [base32_secret]
     Use OKTA Verify app to scan QR code
  ==================================================================
  ```
- **Result**: 2FA enabled with OKTA TOTP, redirected to claims page

### 7. Claims Dashboard
- **URL**: `/claim-lookup`
- **Access**: Full access to policy and claims information
- **Features**: 
  - View policy details
  - Look up claim status
  - Secure authenticated session

## Returning User Flow

After initial setup, returning users follow this flow:

1. **Login** (`/login`)
   - Enter policy number and password

2. **OKTA TOTP Verification** (`/verify-totp`)
   - Enter 6-digit code from OKTA Verify app

3. **Claims Dashboard** (`/claim-lookup`)
   - Access granted to secure content

## Key Security Features

✅ **Temporary Password**: Must be changed on first login  
✅ **Password Policy**: Enforced during password change  
✅ **Email Verification**: OTP sent to registered email  
✅ **Two-Factor Authentication**: OKTA TOTP using OKTA Verify  
✅ **Session Management**: Secure session handling  

## Testing Tips

1. **Watch the Console**: All OTP codes are printed for testing
2. **Use Test Data**: 
   - Policy: `TEST123456`
   - Email: `test@example.com`
3. **OKTA Verify**: Install the OKTA Verify app or use console codes
4. **Demo Claims**: Use `CL-2024-001234` for testing claim lookup

## Common Issues

- **403 Error**: Check SecurityConfig for endpoint permissions
- **OTP Expired**: OTPs are valid for 30 minutes
- **TOTP Mismatch**: Ensure device time is synchronized
- **Password Requirements**: Minimum 8 characters with letters and numbers 