# Claim Lookup Troubleshooting Guide

## Issue: "Invalid or expired code" when accessing claims

### What's happening?
When you try to look up a claim, you're seeing a "Verify Identity" page asking for a Google Authenticator code, but you haven't set up Google Authenticator yet.

### Why does this happen?
The system found a user account with your policy number, but the account has an incomplete setup:
- The user exists in the system
- But 2FA (Two-Factor Authentication) is not properly configured
- The system is asking for a verification code that you can't provide

## Solutions

### Option 1: Complete Your Registration
If you see the verification page but don't have Google Authenticator set up:

1. Click on one of these links on the verification page:
   - **Complete OKTA Registration** - For OKTA TOTP authentication
   - **Complete Google Auth Registration** - For Google Authenticator

2. Go through the full registration flow to set up 2FA properly

### Option 2: Use a Different Claim Number
Try testing with a claim number that doesn't have an associated user:
- `CL-2025-999999` (example of an unregistered claim)

### Option 3: Complete Registration First
Before looking up claims:
1. Go to `/okta-registration` or `/register`
2. Complete the full registration flow
3. Set up OKTA TOTP or Google Authenticator
4. Then access your claims

## Debug Information Added

The application now includes:
- **Debug logging** - Shows user status when looking up claims
- **Better error handling** - Detects incomplete setups
- **Registration links** - Provided on the verification page

## Console Output to Watch For

```
==================== CLAIM LOOKUP DEBUG ====================
   User found: POL123456
   Has TOTP Secret: false
   2FA Enabled: false
   Email: user@example.com
==========================================================
```

This shows you the user's 2FA status when they try to access claims.

## Best Practice

Always complete the full registration flow before trying to access claims:
1. Register (OKTA or Google Auth)
2. Set up 2FA completely
3. Verify it's working
4. Then access claims

This ensures you have proper authentication set up for secure claim access. 