# Removed Register-for-Claim Functionality

## Summary

The "register-for-claim" functionality has been removed from the application. Users who are not registered will now be directed to use the existing registration flows (OKTA or Google Authenticator).

## Changes Made

### 1. **ClaimLookupController.java**
- ✅ **Modified** the claim lookup logic to redirect unregistered users back to claim-lookup page with registration options
- ✅ **Removed** the `@PostMapping("/register-for-claim")` method entirely

### 2. **SecurityConfig.java**
- ✅ **Removed** `/register-for-claim` from the permitAll endpoints list

### 3. **Templates**
- ✅ **Deleted** `register-for-claim.html` template
- ✅ **Updated** `claim-lookup.html` to show registration options when `showRegistrationLinks` is true

### 4. **New User Flow**

**Before:** 
- Unregistered user → Claim lookup → Register-for-claim page → Create account → Access claim

**After:**
- Unregistered user → Claim lookup → Error message with registration options → Choose OKTA or Google Auth → Complete full registration flow → Access claim

## How It Works Now

When an unregistered user tries to look up a claim:

1. They enter a claim number on the claim-lookup page
2. System checks if a user exists with the policy number
3. If no user exists:
   - Shows error: "You need to register first to access claim details. Please register using OKTA or Google Authenticator."
   - Displays two prominent buttons:
     - **Register with OKTA** → Full OKTA flow with OKTA TOTP
     - **Register with Google Auth** → Standard flow with Google Authenticator

## Benefits

- ✅ **Simplified codebase** - Removed duplicate registration logic
- ✅ **Consistent user experience** - All users go through the same registration flows
- ✅ **Better security** - Users complete full MFA setup before accessing claims
- ✅ **Clearer options** - Users explicitly choose between OKTA and Google Auth

## Testing

1. Try to look up a claim without being registered
2. You should see the registration options
3. Choose either OKTA or Google Auth registration
4. Complete the full flow
5. Then access your claims 