# Authentication Flows Implementation Guide

## Overview

This application now implements fully orchestrated authentication flows for both **Okta** and **Google Authenticator** integrations. The flows follow security best practices with proper temporary password management, OKTA Email Verification, and multi-factor authentication setup.

## 🏢 OKTA Authentication Flow

### Complete Flow: Registration → Login → Password Change → Email OTP → Login → OKTA TOTP Setup → Policy Access

```
1. OKTA Registration (/okta-registration)
   ↓
2. Login Page (with temp credentials displayed)
   ↓
3. Temporary Password Login
   ↓
4. Password Change Required (/change-temp-password)
   ↓
5. Email OTP Verification (/okta-email-otp)
   ↓
6. Login Again (with new password)
   ↓
7. OKTA TOTP Setup (/setup-okta-totp)
   ↓
8. Policy Dashboard Access (/claim-lookup)
```

### Step-by-Step OKTA Flow

#### Step 1: OKTA Registration
- **URL**: `/okta-registration`
- **Input**: Policy Number, Email
- **Process**: Creates OKTA user (real or demo)
- **Output**: Temporary credentials
- **Redirect**: Login page with credentials displayed

#### Step 2: First Login (Temporary Password)
- **URL**: `/login`
- **Input**: Policy Number (username), Temporary Password
- **Process**: Authenticates with temp password
- **Redirect**: Password change page (`/change-temp-password`)

#### Step 3: Password Change
- **URL**: `/change-temp-password`
- **Input**: New password, Confirm password
- **Process**: Updates password, generates email OTP
- **Redirect**: OKTA Email OTP verification (`/okta-email-otp`)

#### Step 4: Email OTP Verification
- **URL**: `/okta-email-otp`
- **Input**: 6-digit OKTA Email Verification code
- **Process**: Verifies email OTP
- **Redirect**: Login page for second login

#### Step 5: Second Login (New Password)
- **URL**: `/login`
- **Input**: Policy Number, New Password
- **Process**: Authenticates with new password
- **Redirect**: OKTA TOTP setup (`/setup-okta-totp`)

#### Step 6: OKTA TOTP Setup
- **URL**: `/setup-okta-totp`
- **Input**: TOTP verification code from OKTA Verify app
- **Process**: Enables 2FA with OKTA TOTP, saves TOTP secret
- **Redirect**: Policy dashboard (`/claim-lookup`)

#### Step 7: Policy Dashboard Access
- **URL**: `/claim-lookup`
- **Display**: Success message, user account summary, claim lookup form
- **Features**: Secure access to policy and claims information

## 📱 Google Authenticator Flow

### Complete Flow: Registration → Login → Password Reset → Google Auth Setup → Policy Access

```
1. Google Auth Registration (/register)
   ↓
2. Login Page (with temp credentials displayed)
   ↓
3. Temporary Password Login
   ↓
4. Password Change Required (/change-temp-password)
   ↓
5. Google Authenticator Setup (/setup-google-auth)
   ↓
6. Policy Dashboard Access (/claim-lookup)
```

### Step-by-Step Google Auth Flow

#### Step 1: Google Auth Registration
- **URL**: `/register`
- **Input**: Policy Number, First Name, Last Name, Date of Birth, Email
- **Process**: Creates local user with policy information
- **Output**: Temporary credentials
- **Redirect**: Login page with credentials displayed

#### Steps 2-3: Login and Password Change
- Same as OKTA flow (Steps 2-3)

#### Step 4: Google Authenticator Setup
- **URL**: `/setup-google-auth`
- **Process**: Direct setup after password change (no email OTP needed)
- **Input**: TOTP verification code
- **Redirect**: Policy dashboard (`/claim-lookup`)

## 🔐 Returning User Login Flow

### For Users with Complete Setup

```
1. Login (/login)
   ↓
2. TOTP Verification (/verify-totp)
   - OKTA users: Use OKTA Verify app
   - Google Auth users: Use Google Authenticator app
   ↓
3. Policy Dashboard Access (/claim-lookup)
```

#### Step 1: Login
- **URL**: `/login`
- **Input**: Username (Policy Number), Password
- **Process**: Authenticates user credentials

#### Step 2: 2FA Verification
- **URL**: `/verify-totp`
- **Input**: 6-digit TOTP code
  - **OKTA Users**: Code from OKTA Verify app
  - **Google Auth Users**: Code from Google Authenticator app
- **Process**: Validates TOTP code
- **Redirect**: Policy dashboard for policy users, home for regular users

## 🎯 Key Features Implemented

### Security Features
- ✅ Temporary password enforcement
- ✅ Mandatory password change on first login
- ✅ Email OTP verification (OKTA flow)
- ✅ Google Authenticator 2FA setup
- ✅ TOTP verification for returning users
- ✅ Session management and redirects

### User Experience Features
- ✅ Clear step-by-step guidance
- ✅ Temporary credentials display
- ✅ Real-time TOTP codes in console (for testing)
- ✅ Success messages and flow completion status
- ✅ Comprehensive error handling
- ✅ Responsive UI with Bootstrap

### Testing Features
- ✅ Console logging for all OTP codes
- ✅ Demo claim numbers for testing
- ✅ Real Okta integration capability (when configured)
- ✅ Proper flow state management

## 📋 Testing the Flows

### OKTA Flow Test
1. Navigate to: `http://localhost:8080/okta-registration`
2. Enter: Policy Number: `POL123456`, Email: `test@company.com`
3. Follow redirects through complete flow
4. Check console for OTP codes during testing

### Google Auth Flow Test
1. Navigate to: `http://localhost:8080/register`
2. Enter policy details and email
3. Follow redirects through complete flow
4. Use Google Authenticator app or console codes

### Returning User Test
1. Navigate to: `http://localhost:8080/login`
2. Enter existing user credentials
3. Complete 2FA verification
4. Access policy dashboard

## 🔧 Configuration

### Standard Mode (Default)
- Demo users created locally
- Email OTPs logged to console
- Google Authenticator QR codes generated

### OKTA Integration Mode
```bash
# Set environment variables
export OKTA_CLIENT_ID=your_client_id
export OKTA_CLIENT_SECRET=your_client_secret
export OKTA_DOMAIN=your-domain.okta.com
export OKTA_API_TOKEN=your_api_token

# Run with OKTA profile
mvn spring-boot:run -Dspring.profiles.active=okta
```

## 📊 Flow Completion States

The application tracks different completion states:

- **`mfaSetupComplete`**: Full OKTA flow completed
- **`authenticated`**: Returning user with 2FA verification
- **`loginComplete`**: Standard login without 2FA
- **`registrationSuccess`**: Registration completed, needs login

These states determine the appropriate messages and next steps shown to users.

## 🎉 Success Criteria

Both flows successfully demonstrate:

1. **Complete Security Chain**: Temp password → Password change → OKTA Email Verification (OKTA) → 2FA setup → Secure access
2. **Proper State Management**: Users cannot skip steps or access secure areas without completing authentication
3. **User Guidance**: Clear instructions and feedback at each step
4. **Testing Capability**: Console outputs for all verification codes
5. **Production Ready**: Real OKTA integration capability with proper configuration

## 🚀 Access Points

- **Login**: `http://localhost:8080/login`
- **OKTA Registration**: `http://localhost:8080/okta-registration`
- **Google Auth Registration**: `http://localhost:8080/register`
- **Claims Dashboard**: `http://localhost:8080/claim-lookup`

The orchestrated flows ensure users go through proper security verification before accessing policy and claims information, following enterprise-grade authentication patterns. 