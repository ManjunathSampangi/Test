# Quick Steps to Get Your Okta API Token

## 1. Open Your Okta Admin Console
Click this link: https://aig-trial-7695213.okta.com/admin

## 2. Navigate to API Tokens
- Click **Security** in the left menu
- Click **API**
- Click **Tokens** tab

## 3. Create New Token
- Click **Create Token** button
- Name it: "Google Auth Demo"
- Click **Create Token**

## 4. IMPORTANT: Copy the Token
⚠️ **The token is shown only ONCE!**
- Copy the entire token (starts with "00...")
- Save it somewhere safe

## 5. Set the Token in Terminal
Run this command with YOUR token:
```bash
export OKTA_API_TOKEN="00YOUR-ACTUAL-TOKEN-HERE"
```

## 6. Start the App with Real Okta
```bash
./start-with-okta.sh
```

## That's it! 
Your app will now create REAL users in Okta that you can see in the dashboard. 