# OKTA TOTP Testing Guide

## Application is Running!

The application has been built and is now running on **http://localhost:8084**

## Test the Complete OKTA Flow with OKTA TOTP

### Step 1: Access OKTA Registration
Open your browser and navigate to:
```
http://localhost:8084/okta-registration
```

### Step 2: Register a Test OKTA User
Enter the following test data:
- **Policy Number**: `TEST123456`
- **Email**: `test@example.com`

After registration, check your console for:
```
==================== OKTA TEST ACCOUNT ====================
   Username: TEST123456
   Password: [temporary password will be shown here]
   Email: test@example.com
===========================================================
```

### Step 3: Login with Temporary Password
1. You'll be redirected to the login page
2. Use the temporary password from the console
3. Login with:
   - Username: `TEST123456`
   - Password: `[temporary password from console]`

### Step 4: Change Password
1. You'll be redirected to change password page
2. Set a new password (e.g., `Test1234`)
3. After password change, check console for:
```
==================== OKTA EMAIL OTP ====================
   OKTA Email OTP: [6-digit code]
   Sent to: test@example.com
========================================================
```

### Step 5: Verify Email OTP
1. Enter the 6-digit OTP from console
2. After verification, you'll be redirected to login again

### Step 6: Login with New Password
Login again with:
- Username: `TEST123456`
- Password: `Test1234` (your new password)

### Step 7: OKTA TOTP Setup
1. You'll be redirected to OKTA TOTP setup page
2. You'll see a QR code for OKTA Verify
3. Check console for:
```
==================== OKTA TOTP VERIFICATION CODE ====================
   User: TEST123456
   Current OKTA TOTP Code: [6-digit code]
   OKTA Secret Key: [base32 secret]
   Use OKTA Verify app to scan QR code
==================================================================
```

### Step 8: Complete TOTP Setup
**Option A: Use OKTA Verify App**
1. Install OKTA Verify from app store
2. Scan the QR code
3. Enter the code from OKTA Verify

**Option B: Use Console Code (for testing)**
1. Use the 6-digit code from console
2. Enter it in the verification field

### Step 9: Access Claims Dashboard
After successful TOTP setup, you'll be redirected to the claims dashboard where you can:
- View your policy information
- Look up claim details
- Test claim number: `CL-2024-001234`

## Testing Returning User Flow

### After Initial Setup:
1. Logout or open a new browser session
2. Go to: http://localhost:8084/login
3. Login with:
   - Username: `TEST123456`
   - Password: `Test1234`
4. Enter TOTP code from OKTA Verify (or console)
5. Access granted to claims dashboard

## Quick Test URLs

- **Home**: http://localhost:8084/
- **OKTA Registration**: http://localhost:8084/okta-registration
- **Login**: http://localhost:8084/login
- **Claims Lookup**: http://localhost:8084/claim-lookup
- **Test OTP Info**: http://localhost:8084/test-otp

## Console Monitoring

Keep an eye on the console for:
- Temporary passwords
- Email OTP codes
- OKTA TOTP codes
- Flow status messages

## Troubleshooting

1. **403 Forbidden Error**: All endpoints should be accessible
2. **TOTP Code Invalid**: Wait for a new code (refreshes every 30 seconds)
3. **Can't Access Claims**: Ensure you completed the full registration flow

## Key Differences: OKTA TOTP vs Google Authenticator

- **OKTA Users**: Automatically use OKTA TOTP with OKTA Verify
- **Non-OKTA Users**: Continue with Google Authenticator
- **Same TOTP Algorithm**: Both use standard TOTP, just different apps

Happy Testing! 🚀 